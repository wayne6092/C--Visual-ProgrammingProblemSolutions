﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sentence_Capitalizer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private string Capitalizer(string text)
        {
            string newString = "";
            if (text != "")
            {
                char[] delim = { '!', '?', '.' };

                text = text.Trim();
                char letter;
                char firstLetter;
                string firstWord;
                string word;
                
                string[] tokens = text.Split(delim);

                //int period = text.IndexOf(".");
                //int ePoint = text.IndexOf("!");
                //int qMark = text.IndexOf("?");

                //string mark = ". ";
                //string mark2 = ". ";
                //string mark3 = ". ";
                //if (period > 0 && ePoint > 0 && qMark > 0)

                //{
                //    if (period < ePoint && ePoint < qMark)
                //    {
                //        mark = ". ";
                //        mark2 = "! ";
                //        mark3 = "? ";
                //    }
                //    else if (qMark < ePoint && ePoint < period)
                //    {
                //        mark = "? ";
                //        mark2 = "! ";
                //        mark3 = ". ";
                //    }
                //    else if (period < qMark && qMark < ePoint)
                //    {
                //        mark = ". ";
                //        mark2 = "? ";
                //        mark3 = "! ";
                //    }
                //    else if (ePoint < qMark && qMark < period)
                //    {
                //        mark = "! ";
                //        mark2 = "? ";
                //        mark3 = ". ";
                //    }
                //    else if (ePoint < period && period < qMark)
                //    {
                //        mark = "! ";
                //        mark2 = ". ";
                //        mark3 = "? ";

                //    }
                //    else if (qMark < period && period < ePoint)
                //    {
                //        mark = "? ";
                //        mark2 = ". ";
                //        mark3 = "! ";

                //    }


                //}
                //else if (period > 0 && ePoint > 0)
                //{
                //    if (period < ePoint)
                //    {
                //        mark = ". ";
                //        mark2 = "! ";
                //    }
                //    else if(ePoint < period)
                //    {
                //        mark = "! ";
                //        mark2 = ". ";
                //    }
                //}
                //else if (period > 0 && qMark > 0)
                //{
                //    if (qMark < period)
                //    {
                //        mark = "? ";
                //        mark2 = ". ";
                //    }
                //    else if (period < qMark)
                //    {
                //        mark = ". ";
                //    }
                //}
                //else if (ePoint > 0 && qMark > 0)
                //{
                //    if (qMark < ePoint)
                //    {
                //        mark = "? ";
                //        mark2 = "! ";
                //    }
                //    else if (ePoint < qMark)
                //    {
                //        mark = "! ";
                //        mark2 = "? ";
                //    }
                //}
                //else if(qMark > 0)
                //{
                //    mark = "?";
                //}
                //else if (ePoint > 0)
                //{
                //    mark = "!";
                //}
                //else if(period > 0)
                //{
                //    mark = ". ";
                //}
                //else
                //{
                //    mark = ". ";
                //    mark2 = ". ";
                //    mark3 = ". ";
                //}


                for (int i = 0; i < tokens.Length - 1; i++)
                {
                    if (i == 0)
                    {
                        firstLetter = char.ToUpper(tokens[i].ToString()[0]);
                        //Add following letters to first word
                        firstWord = tokens[i].Substring(1).ToLower();

                        //newString += firstLetter + firstWord + ". " + mark + mark2;
                        newString += firstLetter + firstWord + ". ";
                    }
                    else if (i > 0)
                    {
                        //Capitalizes first char of each string, start at 2nd word
                        letter = char.ToUpper(tokens[i].ToString()[1]); //After ". " capitalize first letter
                                                                        
                        word = tokens[i].ToString().Substring(2).ToLower(); //Start at 3rd letter in token
                        newString += letter.ToString() + word + ". ";
                    }
                    

                }
                return newString;
            }
            else
            {
                return newString;
            }
        }


            private void buttonCapitalize_Click(object sender, EventArgs e)
        {
            try
            {
                string sentence = textBoxWords.Text;
                labelResult.Text = Capitalizer(sentence);
            }
            catch (Exception)
            {
                MessageBox.Show("Sorry, something went wrong.");
            }
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBoxWords.Text = "";
            labelResult.Text = "";
            textBoxWords.Focus();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
