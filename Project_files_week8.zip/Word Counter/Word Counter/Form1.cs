﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Word_Counter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private string Counter(string text)
        {
            int wordCount = 0;
            string[] tokens = text.Split(null);
            foreach(string s in tokens)
            {
                wordCount++;
            }
            return wordCount.ToString();
            
        }

        
        private void buttonCount_Click(object sender, EventArgs e)
        {
            try
            {
                string sentence = textBoxWords.Text;
                labelCountResult.Text = Counter(sentence);
                textBoxWords.Focus();
            }
            catch (Exception)
            {
                MessageBox.Show("Sorry, something went wrong.");
            }
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBoxWords.Text = "";
            labelCountResult.Text = "0";
            textBoxWords.Focus();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
