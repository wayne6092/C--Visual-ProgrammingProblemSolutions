﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Most_Frequent_Character
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private const int ASCII_SIZE = 256;

        private char MaxChar(string text)
        {
            int[] count = new int[ASCII_SIZE]; //Array keeps count of chars in string
            int len = text.Length;             //Length of string used for loops
            int max = 0;                       //Max, used to test for highest count of char
            char result = ' ';                 //Variable to hold result

            //Iterate through string
            //Count occurrences of each character, 
            //Place count inside count array for each
            //corresponding ASCII character (256)
            for (int j = 0; j < len; j++)
            {
                count[text[j]]++; // Add one to each occurrence of char in count array
            }

            //Iterate through string
            //check number of char occurrences in count array
            //set max to # of char occurrences in count array 
            //return char with highest # of occurrences as result
            for (int i = 0; i < len; i++)
            {
                if (max < count[text[i]])
                {
                    max = count[text[i]];
                    result = text[i];
                }
            }
            return result;
        }

        private void buttonCheck_Click(object sender, EventArgs e)
        {
            try
            {
                string sentence = textBoxWords.Text;
                labelResult.Text = MaxChar(sentence).ToString();
                textBoxWords.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Something went wrong: " + ex.ToString());
            }
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBoxWords.Text = "";
            labelResult.Text = "";
            textBoxWords.Focus();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
