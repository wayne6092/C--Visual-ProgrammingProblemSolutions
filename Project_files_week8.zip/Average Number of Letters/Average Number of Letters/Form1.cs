﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Average_Number_of_Letters
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private string Counter(string text)
        {
            int wordCount = 0;
            if (text != "")
            {
                string[] tokens = text.Split(null);
                foreach (string s in tokens)
                {
                    if (char.IsLetter(s[0])) { wordCount++; }

                }
                return wordCount.ToString();
            }
            else
            {
                return wordCount.ToString().Trim();
            }

        }

        private string Average(string text)
        {
            int charCount = 0;
            
            foreach (char letter in text)
            {
                if (char.IsLetter(letter))
                {
                    charCount++;
                }
            }
            return charCount.ToString();
        }


        private void buttonCount_Click(object sender, EventArgs e)
        {
            
            double average;
            double words;
            double chars;
            try
            {
                string sentence = textBoxWords.Text;
                labelCountResult.Text = Counter(sentence);

                words = int.Parse(Counter(sentence));
                chars = int.Parse(Average(sentence));
            
                average = chars / words;

                labelLetterCount.Text = chars.ToString();
                labelAverageResult.Text = average.ToString();
                textBoxWords.Focus();
            }
            catch (Exception)
            {
                MessageBox.Show("Something went wrong.");
            }
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBoxWords.Text = "";
            labelAverageResult.Text = "0.0";
            labelCountResult.Text = "0";
            labelLetterCount.Text = "0";
            textBoxWords.Focus();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
