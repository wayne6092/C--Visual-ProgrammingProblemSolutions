﻿namespace Average_Number_of_Letters
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonExit = new System.Windows.Forms.Button();
            this.textBoxWords = new System.Windows.Forms.TextBox();
            this.labelCountResult = new System.Windows.Forms.Label();
            this.labelCount = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonClear = new System.Windows.Forms.Button();
            this.buttonCount = new System.Windows.Forms.Button();
            this.labelAverageResult = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.labelLetterCount = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonExit
            // 
            this.buttonExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonExit.Location = new System.Drawing.Point(19, 179);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(91, 40);
            this.buttonExit.TabIndex = 3;
            this.buttonExit.Text = "&Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // textBoxWords
            // 
            this.textBoxWords.Location = new System.Drawing.Point(116, 12);
            this.textBoxWords.Name = "textBoxWords";
            this.textBoxWords.Size = new System.Drawing.Size(324, 26);
            this.textBoxWords.TabIndex = 0;
            // 
            // labelCountResult
            // 
            this.labelCountResult.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelCountResult.Location = new System.Drawing.Point(361, 70);
            this.labelCountResult.Name = "labelCountResult";
            this.labelCountResult.Size = new System.Drawing.Size(79, 21);
            this.labelCountResult.TabIndex = 12;
            this.labelCountResult.Text = "0";
            // 
            // labelCount
            // 
            this.labelCount.AutoSize = true;
            this.labelCount.Location = new System.Drawing.Point(261, 70);
            this.labelCount.Name = "labelCount";
            this.labelCount.Size = new System.Drawing.Size(94, 20);
            this.labelCount.TabIndex = 11;
            this.labelCount.Text = "Word Count";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 20);
            this.label1.TabIndex = 10;
            this.label1.Text = "Enter Words";
            // 
            // buttonClear
            // 
            this.buttonClear.Location = new System.Drawing.Point(178, 179);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(91, 40);
            this.buttonClear.TabIndex = 2;
            this.buttonClear.Text = "Clear";
            this.buttonClear.UseVisualStyleBackColor = true;
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // buttonCount
            // 
            this.buttonCount.Location = new System.Drawing.Point(349, 179);
            this.buttonCount.Name = "buttonCount";
            this.buttonCount.Size = new System.Drawing.Size(91, 40);
            this.buttonCount.TabIndex = 1;
            this.buttonCount.Text = "Count";
            this.buttonCount.UseVisualStyleBackColor = true;
            this.buttonCount.Click += new System.EventHandler(this.buttonCount_Click);
            // 
            // labelAverageResult
            // 
            this.labelAverageResult.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelAverageResult.Location = new System.Drawing.Point(361, 136);
            this.labelAverageResult.Name = "labelAverageResult";
            this.labelAverageResult.Size = new System.Drawing.Size(79, 20);
            this.labelAverageResult.TabIndex = 16;
            this.labelAverageResult.Text = "0.0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(160, 137);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(195, 20);
            this.label3.TabIndex = 15;
            this.label3.Text = "Average # of Letters/Word";
            // 
            // labelLetterCount
            // 
            this.labelLetterCount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelLetterCount.Location = new System.Drawing.Point(361, 104);
            this.labelLetterCount.Name = "labelLetterCount";
            this.labelLetterCount.Size = new System.Drawing.Size(79, 21);
            this.labelLetterCount.TabIndex = 18;
            this.labelLetterCount.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(261, 104);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(98, 20);
            this.label4.TabIndex = 17;
            this.label4.Text = "Letter Count";
            // 
            // Form1
            // 
            this.AcceptButton = this.buttonCount;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.buttonExit;
            this.ClientSize = new System.Drawing.Size(458, 231);
            this.Controls.Add(this.labelLetterCount);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.labelAverageResult);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.textBoxWords);
            this.Controls.Add(this.labelCountResult);
            this.Controls.Add(this.labelCount);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonClear);
            this.Controls.Add(this.buttonCount);
            this.Name = "Form1";
            this.Text = "Average Number Of Letters";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.TextBox textBoxWords;
        private System.Windows.Forms.Label labelCountResult;
        private System.Windows.Forms.Label labelCount;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonClear;
        private System.Windows.Forms.Button buttonCount;
        private System.Windows.Forms.Label labelAverageResult;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label labelLetterCount;
        private System.Windows.Forms.Label label4;
    }
}

