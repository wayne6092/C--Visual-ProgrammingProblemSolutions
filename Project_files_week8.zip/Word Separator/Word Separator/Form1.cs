﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Word_Separator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private string wordSeparator(string str)
        {
            string result = "";

            for (int i = 0; i < str.Length; i++)
            {
                if (char.IsUpper(str[i]))
                {
                    result += ' ';
                }
                if(i == 0)
                {
                    result += str[0];
                }
                
                if(i > 0)
                {
                    result += str[i].ToString().ToLower();
                }
            }
            
            return result.Trim();
        }

        private void buttonConvert_Click(object sender, EventArgs e)
        {
            try
            {
                string text = textBoxWords.Text;
                labelResult.Text = wordSeparator(text);
                textBoxWords.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Something went wrong: " + ex.ToString());
            }
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBoxWords.Text = "";
            labelResult.Text = "";
            textBoxWords.Focus();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
