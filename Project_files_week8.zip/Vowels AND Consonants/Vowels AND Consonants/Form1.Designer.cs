﻿namespace Vowels_AND_Consonants
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonExit = new System.Windows.Forms.Button();
            this.textBoxWords = new System.Windows.Forms.TextBox();
            this.labelVowels = new System.Windows.Forms.Label();
            this.labelCount = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonClear = new System.Windows.Forms.Button();
            this.buttonCount = new System.Windows.Forms.Button();
            this.labelConsonants = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonExit
            // 
            this.buttonExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonExit.Location = new System.Drawing.Point(12, 176);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(91, 40);
            this.buttonExit.TabIndex = 3;
            this.buttonExit.Text = "&Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // textBoxWords
            // 
            this.textBoxWords.Location = new System.Drawing.Point(142, 46);
            this.textBoxWords.Name = "textBoxWords";
            this.textBoxWords.Size = new System.Drawing.Size(181, 26);
            this.textBoxWords.TabIndex = 0;
            // 
            // labelVowels
            // 
            this.labelVowels.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelVowels.Location = new System.Drawing.Point(142, 89);
            this.labelVowels.Name = "labelVowels";
            this.labelVowels.Size = new System.Drawing.Size(181, 21);
            this.labelVowels.TabIndex = 5;
            this.labelVowels.Text = "0";
            // 
            // labelCount
            // 
            this.labelCount.AutoSize = true;
            this.labelCount.Location = new System.Drawing.Point(42, 89);
            this.labelCount.Name = "labelCount";
            this.labelCount.Size = new System.Drawing.Size(91, 20);
            this.labelCount.TabIndex = 7;
            this.labelCount.Text = "# of Vowels";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(38, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 20);
            this.label1.TabIndex = 8;
            this.label1.Text = "Enter Words";
            // 
            // buttonClear
            // 
            this.buttonClear.Location = new System.Drawing.Point(124, 176);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(91, 40);
            this.buttonClear.TabIndex = 2;
            this.buttonClear.Text = "Clear";
            this.buttonClear.UseVisualStyleBackColor = true;
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // buttonCount
            // 
            this.buttonCount.Location = new System.Drawing.Point(232, 176);
            this.buttonCount.Name = "buttonCount";
            this.buttonCount.Size = new System.Drawing.Size(91, 40);
            this.buttonCount.TabIndex = 1;
            this.buttonCount.Text = "Count";
            this.buttonCount.UseVisualStyleBackColor = true;
            this.buttonCount.Click += new System.EventHandler(this.buttonCount_Click);
            // 
            // labelConsonants
            // 
            this.labelConsonants.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelConsonants.Location = new System.Drawing.Point(142, 127);
            this.labelConsonants.Name = "labelConsonants";
            this.labelConsonants.Size = new System.Drawing.Size(181, 21);
            this.labelConsonants.TabIndex = 4;
            this.labelConsonants.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 128);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(126, 20);
            this.label3.TabIndex = 6;
            this.label3.Text = "# of Consonants";
            // 
            // Form1
            // 
            this.AcceptButton = this.buttonCount;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.buttonExit;
            this.ClientSize = new System.Drawing.Size(407, 259);
            this.Controls.Add(this.labelConsonants);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.textBoxWords);
            this.Controls.Add(this.labelVowels);
            this.Controls.Add(this.labelCount);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonClear);
            this.Controls.Add(this.buttonCount);
            this.Name = "Form1";
            this.Text = "Vowels & Consonants";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.TextBox textBoxWords;
        private System.Windows.Forms.Label labelVowels;
        private System.Windows.Forms.Label labelCount;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonClear;
        private System.Windows.Forms.Button buttonCount;
        private System.Windows.Forms.Label labelConsonants;
        private System.Windows.Forms.Label label3;
    }
}

