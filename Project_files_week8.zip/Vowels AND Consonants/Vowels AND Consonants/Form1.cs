﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vowels_AND_Consonants
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private string VowelCounter(string text)
        {
            int vowel = 0;
            foreach(char c in text)
            {
                if(c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u' || 
                    c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U')
                {
                    vowel++;
                }
            }
            return vowel.ToString();
        }

        private string ConsonantCounter(string text)
        {
            int consonant = 0;
            
            foreach(char c in text)
            {
                if(c != 'a' && c != 'e' && c != 'i' && c != 'o' && c != 'u' && 
                    c != 'A' && c != 'E' && c != 'I' && c != 'O' && c != 'U')
                {
                    if ((c >= 'b' && c <= 'z') || (c >= 'B' && c <= 'Z'))
                    {
                        consonant++;
                    }
                }
            }
            return consonant.ToString();
        }

        private void buttonCount_Click(object sender, EventArgs e)
        {
            string text = textBoxWords.Text;
            labelVowels.Text = VowelCounter(text);
            labelConsonants.Text = ConsonantCounter(text);
            textBoxWords.Focus();
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBoxWords.Text = "";
            labelConsonants.Text = "0";
            labelVowels.Text = "0";
            textBoxWords.Focus();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
