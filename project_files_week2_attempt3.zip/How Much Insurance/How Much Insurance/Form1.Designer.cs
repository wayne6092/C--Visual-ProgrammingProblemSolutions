﻿namespace How_Much_Insurance
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.exitButton = new System.Windows.Forms.Button();
            this.Calculate = new System.Windows.Forms.Button();
            this.replaceCostTitleLabel = new System.Windows.Forms.Label();
            this.minimumInsuranceTitleLabel = new System.Windows.Forms.Label();
            this.insuranceLabel = new System.Windows.Forms.Label();
            this.replaceCostTextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // exitButton
            // 
            this.exitButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.exitButton.Location = new System.Drawing.Point(108, 120);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(105, 44);
            this.exitButton.TabIndex = 2;
            this.exitButton.Text = "&Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Calculate
            // 
            this.Calculate.Location = new System.Drawing.Point(240, 120);
            this.Calculate.Name = "Calculate";
            this.Calculate.Size = new System.Drawing.Size(102, 44);
            this.Calculate.TabIndex = 1;
            this.Calculate.Text = "Calculate";
            this.Calculate.UseVisualStyleBackColor = true;
            this.Calculate.Click += new System.EventHandler(this.Calculate_Click);
            // 
            // replaceCostTitleLabel
            // 
            this.replaceCostTitleLabel.AutoSize = true;
            this.replaceCostTitleLabel.Location = new System.Drawing.Point(84, 21);
            this.replaceCostTitleLabel.Name = "replaceCostTitleLabel";
            this.replaceCostTitleLabel.Size = new System.Drawing.Size(141, 20);
            this.replaceCostTitleLabel.TabIndex = 5;
            this.replaceCostTitleLabel.Text = "Replacement Cost";
            // 
            // minimumInsuranceTitleLabel
            // 
            this.minimumInsuranceTitleLabel.AutoSize = true;
            this.minimumInsuranceTitleLabel.Location = new System.Drawing.Point(78, 73);
            this.minimumInsuranceTitleLabel.Name = "minimumInsuranceTitleLabel";
            this.minimumInsuranceTitleLabel.Size = new System.Drawing.Size(147, 20);
            this.minimumInsuranceTitleLabel.TabIndex = 4;
            this.minimumInsuranceTitleLabel.Text = "Minimum Insurance";
            // 
            // insuranceLabel
            // 
            this.insuranceLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.insuranceLabel.Location = new System.Drawing.Point(242, 73);
            this.insuranceLabel.Name = "insuranceLabel";
            this.insuranceLabel.Size = new System.Drawing.Size(100, 23);
            this.insuranceLabel.TabIndex = 3;
            // 
            // replaceCostTextBox
            // 
            this.replaceCostTextBox.Location = new System.Drawing.Point(242, 21);
            this.replaceCostTextBox.Name = "replaceCostTextBox";
            this.replaceCostTextBox.Size = new System.Drawing.Size(100, 26);
            this.replaceCostTextBox.TabIndex = 0;
            // 
            // Form1
            // 
            this.AcceptButton = this.Calculate;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.exitButton;
            this.ClientSize = new System.Drawing.Size(367, 188);
            this.Controls.Add(this.replaceCostTextBox);
            this.Controls.Add(this.insuranceLabel);
            this.Controls.Add(this.minimumInsuranceTitleLabel);
            this.Controls.Add(this.replaceCostTitleLabel);
            this.Controls.Add(this.Calculate);
            this.Controls.Add(this.exitButton);
            this.Name = "Form1";
            this.Text = "How Much Insurance";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button Calculate;
        private System.Windows.Forms.Label replaceCostTitleLabel;
        private System.Windows.Forms.Label minimumInsuranceTitleLabel;
        private System.Windows.Forms.Label insuranceLabel;
        private System.Windows.Forms.TextBox replaceCostTextBox;
    }
}

