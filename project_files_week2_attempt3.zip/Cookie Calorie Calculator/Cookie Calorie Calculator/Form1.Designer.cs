﻿namespace Cookie_Calorie_Calculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cookiesEatenTitleLabel = new System.Windows.Forms.Label();
            this.totalCaloriesTitleLabel = new System.Windows.Forms.Label();
            this.cookiesEatenTextBox = new System.Windows.Forms.TextBox();
            this.exitButton = new System.Windows.Forms.Button();
            this.calculateButton = new System.Windows.Forms.Button();
            this.totalCaloriesLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // cookiesEatenTitleLabel
            // 
            this.cookiesEatenTitleLabel.AutoSize = true;
            this.cookiesEatenTitleLabel.Location = new System.Drawing.Point(71, 28);
            this.cookiesEatenTitleLabel.Name = "cookiesEatenTitleLabel";
            this.cookiesEatenTitleLabel.Size = new System.Drawing.Size(113, 20);
            this.cookiesEatenTitleLabel.TabIndex = 5;
            this.cookiesEatenTitleLabel.Text = "Cookies Eaten";
            // 
            // totalCaloriesTitleLabel
            // 
            this.totalCaloriesTitleLabel.AutoSize = true;
            this.totalCaloriesTitleLabel.Location = new System.Drawing.Point(79, 89);
            this.totalCaloriesTitleLabel.Name = "totalCaloriesTitleLabel";
            this.totalCaloriesTitleLabel.Size = new System.Drawing.Size(105, 20);
            this.totalCaloriesTitleLabel.TabIndex = 4;
            this.totalCaloriesTitleLabel.Text = "Total Calories";
            // 
            // cookiesEatenTextBox
            // 
            this.cookiesEatenTextBox.Location = new System.Drawing.Point(202, 22);
            this.cookiesEatenTextBox.Name = "cookiesEatenTextBox";
            this.cookiesEatenTextBox.Size = new System.Drawing.Size(100, 26);
            this.cookiesEatenTextBox.TabIndex = 0;
            // 
            // exitButton
            // 
            this.exitButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.exitButton.Location = new System.Drawing.Point(75, 145);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(89, 45);
            this.exitButton.TabIndex = 2;
            this.exitButton.Text = "&Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(202, 145);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(100, 45);
            this.calculateButton.TabIndex = 1;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // totalCaloriesLabel
            // 
            this.totalCaloriesLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalCaloriesLabel.Location = new System.Drawing.Point(202, 88);
            this.totalCaloriesLabel.Name = "totalCaloriesLabel";
            this.totalCaloriesLabel.Size = new System.Drawing.Size(100, 23);
            this.totalCaloriesLabel.TabIndex = 3;
            // 
            // Form1
            // 
            this.AcceptButton = this.calculateButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.exitButton;
            this.ClientSize = new System.Drawing.Size(397, 213);
            this.Controls.Add(this.totalCaloriesLabel);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.cookiesEatenTextBox);
            this.Controls.Add(this.totalCaloriesTitleLabel);
            this.Controls.Add(this.cookiesEatenTitleLabel);
            this.Name = "Form1";
            this.Text = "Cookie Calorie Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label cookiesEatenTitleLabel;
        private System.Windows.Forms.Label totalCaloriesTitleLabel;
        private System.Windows.Forms.TextBox cookiesEatenTextBox;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Label totalCaloriesLabel;
    }
}

