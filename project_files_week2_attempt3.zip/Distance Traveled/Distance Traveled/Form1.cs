﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Distance_Traveled
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void fiveHoursButton_Click(object sender, EventArgs e)
        {
            double speed;

            try
            {
                speed = double.Parse(speedTextBox.Text);
                double distance = speed * 5;
                resultLabel.Text = distance.ToString();
            }
            catch (Exception ex)
            {
                resultLabel.Text = ex.Message;
            }
        }

        private void eightHoursButton_Click(object sender, EventArgs e)
        {
            double speed;

            try
            {
                speed = double.Parse(speedTextBox.Text);
                double distance = speed * 8;
                resultLabel.Text = distance.ToString();
            }
            catch (Exception ex)
            {
                resultLabel.Text = ex.Message;
            }
        }

        private void twelveHoursButton_Click(object sender, EventArgs e)
        {
            double speed;

            try
            {
                speed = double.Parse(speedTextBox.Text);
                double distance = speed * 12;
                resultLabel.Text = distance.ToString();
            }
            catch (Exception ex)
            {
                resultLabel.Text = ex.Message;
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            speedTextBox.Text = "";
            resultLabel.Text = "";
        }
    }
}
