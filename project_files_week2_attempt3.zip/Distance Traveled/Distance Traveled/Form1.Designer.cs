﻿namespace Distance_Traveled
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.speedTextBox = new System.Windows.Forms.TextBox();
            this.speedTitleLabel = new System.Windows.Forms.Label();
            this.resultLabel = new System.Windows.Forms.Label();
            this.fiveHoursButton = new System.Windows.Forms.Button();
            this.eightHoursButton = new System.Windows.Forms.Button();
            this.twelveHoursButton = new System.Windows.Forms.Button();
            this.distanceTitleLabel = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // speedTextBox
            // 
            this.speedTextBox.Location = new System.Drawing.Point(121, 17);
            this.speedTextBox.Name = "speedTextBox";
            this.speedTextBox.Size = new System.Drawing.Size(100, 26);
            this.speedTextBox.TabIndex = 0;
            // 
            // speedTitleLabel
            // 
            this.speedTitleLabel.AutoSize = true;
            this.speedTitleLabel.Location = new System.Drawing.Point(8, 20);
            this.speedTitleLabel.Name = "speedTitleLabel";
            this.speedTitleLabel.Size = new System.Drawing.Size(105, 20);
            this.speedTitleLabel.TabIndex = 8;
            this.speedTitleLabel.Text = "Speed (MPH)";
            // 
            // resultLabel
            // 
            this.resultLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.resultLabel.Location = new System.Drawing.Point(121, 66);
            this.resultLabel.Name = "resultLabel";
            this.resultLabel.Size = new System.Drawing.Size(100, 23);
            this.resultLabel.TabIndex = 6;
            // 
            // fiveHoursButton
            // 
            this.fiveHoursButton.Location = new System.Drawing.Point(12, 109);
            this.fiveHoursButton.Name = "fiveHoursButton";
            this.fiveHoursButton.Size = new System.Drawing.Size(67, 54);
            this.fiveHoursButton.TabIndex = 1;
            this.fiveHoursButton.Text = "Five Hours";
            this.fiveHoursButton.UseVisualStyleBackColor = true;
            this.fiveHoursButton.Click += new System.EventHandler(this.fiveHoursButton_Click);
            // 
            // eightHoursButton
            // 
            this.eightHoursButton.Location = new System.Drawing.Point(109, 109);
            this.eightHoursButton.Name = "eightHoursButton";
            this.eightHoursButton.Size = new System.Drawing.Size(88, 54);
            this.eightHoursButton.TabIndex = 2;
            this.eightHoursButton.Text = "Eight Hours";
            this.eightHoursButton.UseVisualStyleBackColor = true;
            this.eightHoursButton.Click += new System.EventHandler(this.eightHoursButton_Click);
            // 
            // twelveHoursButton
            // 
            this.twelveHoursButton.Location = new System.Drawing.Point(225, 109);
            this.twelveHoursButton.Name = "twelveHoursButton";
            this.twelveHoursButton.Size = new System.Drawing.Size(87, 54);
            this.twelveHoursButton.TabIndex = 3;
            this.twelveHoursButton.Text = "Twelve Hours";
            this.twelveHoursButton.UseVisualStyleBackColor = true;
            this.twelveHoursButton.Click += new System.EventHandler(this.twelveHoursButton_Click);
            // 
            // distanceTitleLabel
            // 
            this.distanceTitleLabel.AutoSize = true;
            this.distanceTitleLabel.Location = new System.Drawing.Point(41, 66);
            this.distanceTitleLabel.Name = "distanceTitleLabel";
            this.distanceTitleLabel.Size = new System.Drawing.Size(72, 20);
            this.distanceTitleLabel.TabIndex = 7;
            this.distanceTitleLabel.Text = "Distance";
            // 
            // exitButton
            // 
            this.exitButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.exitButton.Location = new System.Drawing.Point(225, 198);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(87, 41);
            this.exitButton.TabIndex = 5;
            this.exitButton.Text = "&Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(121, 198);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(76, 41);
            this.clearButton.TabIndex = 4;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // Form1
            // 
            this.AcceptButton = this.clearButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.exitButton;
            this.ClientSize = new System.Drawing.Size(320, 245);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.distanceTitleLabel);
            this.Controls.Add(this.twelveHoursButton);
            this.Controls.Add(this.eightHoursButton);
            this.Controls.Add(this.fiveHoursButton);
            this.Controls.Add(this.resultLabel);
            this.Controls.Add(this.speedTitleLabel);
            this.Controls.Add(this.speedTextBox);
            this.Name = "Form1";
            this.Text = "Distance Traveled";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox speedTextBox;
        private System.Windows.Forms.Label speedTitleLabel;
        private System.Windows.Forms.Label resultLabel;
        private System.Windows.Forms.Button fiveHoursButton;
        private System.Windows.Forms.Button eightHoursButton;
        private System.Windows.Forms.Button twelveHoursButton;
        private System.Windows.Forms.Label distanceTitleLabel;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button clearButton;
    }
}

