﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sales_Tax_and_Total
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            decimal purchaseAmount;
            decimal salesTax;
            decimal countyTax;
            decimal totalTax;
            decimal totalSale;

            try
            {
                purchaseAmount = decimal.Parse(purchaseAmountTextBox.Text);
                salesTax = purchaseAmount * (decimal) 0.04;
                countyTax = purchaseAmount * (decimal) 0.02;
                totalTax = salesTax + countyTax;
                totalSale = totalTax + purchaseAmount;

                stateSalesTaxLabel.Text = salesTax.ToString("c");
                countySalesTaxLabel.Text = countyTax.ToString("c");
                totalSalesTaxLabel.Text = totalTax.ToString("c");
                totalSaleLabel.Text = totalSale.ToString("c");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }
    }
}
