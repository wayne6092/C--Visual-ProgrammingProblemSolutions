﻿namespace Sales_Tax_and_Total
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.exitButton = new System.Windows.Forms.Button();
            this.calculateButton = new System.Windows.Forms.Button();
            this.purchaseTitleLabel = new System.Windows.Forms.Label();
            this.stateSalesTaxTitleLabel = new System.Windows.Forms.Label();
            this.stateSalesTaxLabel = new System.Windows.Forms.Label();
            this.countySalesTaxLabel = new System.Windows.Forms.Label();
            this.purchaseAmountTextBox = new System.Windows.Forms.TextBox();
            this.countySalesTaxTitleLabel = new System.Windows.Forms.Label();
            this.totalSalesTaxTitleLabel = new System.Windows.Forms.Label();
            this.totalSalesTaxLabel = new System.Windows.Forms.Label();
            this.totalSaleTitleLabel = new System.Windows.Forms.Label();
            this.totalSaleLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // exitButton
            // 
            this.exitButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.exitButton.Location = new System.Drawing.Point(64, 289);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(86, 36);
            this.exitButton.TabIndex = 2;
            this.exitButton.Text = "&Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(189, 289);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(100, 36);
            this.calculateButton.TabIndex = 1;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // purchaseTitleLabel
            // 
            this.purchaseTitleLabel.AutoSize = true;
            this.purchaseTitleLabel.Location = new System.Drawing.Point(41, 26);
            this.purchaseTitleLabel.Name = "purchaseTitleLabel";
            this.purchaseTitleLabel.Size = new System.Drawing.Size(136, 20);
            this.purchaseTitleLabel.TabIndex = 2;
            this.purchaseTitleLabel.Text = "Purchase Amount";
            // 
            // stateSalesTaxTitleLabel
            // 
            this.stateSalesTaxTitleLabel.AutoSize = true;
            this.stateSalesTaxTitleLabel.Location = new System.Drawing.Point(25, 73);
            this.stateSalesTaxTitleLabel.Name = "stateSalesTaxTitleLabel";
            this.stateSalesTaxTitleLabel.Size = new System.Drawing.Size(158, 20);
            this.stateSalesTaxTitleLabel.TabIndex = 7;
            this.stateSalesTaxTitleLabel.Text = "State Sales Tax (4%)";
            // 
            // stateSalesTaxLabel
            // 
            this.stateSalesTaxLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.stateSalesTaxLabel.Location = new System.Drawing.Point(189, 72);
            this.stateSalesTaxLabel.Name = "stateSalesTaxLabel";
            this.stateSalesTaxLabel.Size = new System.Drawing.Size(100, 23);
            this.stateSalesTaxLabel.TabIndex = 3;
            // 
            // countySalesTaxLabel
            // 
            this.countySalesTaxLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.countySalesTaxLabel.Location = new System.Drawing.Point(189, 125);
            this.countySalesTaxLabel.Name = "countySalesTaxLabel";
            this.countySalesTaxLabel.Size = new System.Drawing.Size(100, 23);
            this.countySalesTaxLabel.TabIndex = 4;
            // 
            // purchaseAmountTextBox
            // 
            this.purchaseAmountTextBox.Location = new System.Drawing.Point(189, 20);
            this.purchaseAmountTextBox.Name = "purchaseAmountTextBox";
            this.purchaseAmountTextBox.Size = new System.Drawing.Size(100, 26);
            this.purchaseAmountTextBox.TabIndex = 0;
            // 
            // countySalesTaxTitleLabel
            // 
            this.countySalesTaxTitleLabel.AutoSize = true;
            this.countySalesTaxTitleLabel.Location = new System.Drawing.Point(8, 125);
            this.countySalesTaxTitleLabel.Name = "countySalesTaxTitleLabel";
            this.countySalesTaxTitleLabel.Size = new System.Drawing.Size(169, 20);
            this.countySalesTaxTitleLabel.TabIndex = 8;
            this.countySalesTaxTitleLabel.Text = "County Sales Tax (2%)";
            // 
            // totalSalesTaxTitleLabel
            // 
            this.totalSalesTaxTitleLabel.AutoSize = true;
            this.totalSalesTaxTitleLabel.Location = new System.Drawing.Point(60, 183);
            this.totalSalesTaxTitleLabel.Name = "totalSalesTaxTitleLabel";
            this.totalSalesTaxTitleLabel.Size = new System.Drawing.Size(117, 20);
            this.totalSalesTaxTitleLabel.TabIndex = 9;
            this.totalSalesTaxTitleLabel.Text = "Total Sales Tax";
            // 
            // totalSalesTaxLabel
            // 
            this.totalSalesTaxLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalSalesTaxLabel.Location = new System.Drawing.Point(189, 182);
            this.totalSalesTaxLabel.Name = "totalSalesTaxLabel";
            this.totalSalesTaxLabel.Size = new System.Drawing.Size(100, 23);
            this.totalSalesTaxLabel.TabIndex = 5;
            // 
            // totalSaleTitleLabel
            // 
            this.totalSaleTitleLabel.AutoSize = true;
            this.totalSaleTitleLabel.Location = new System.Drawing.Point(79, 229);
            this.totalSaleTitleLabel.Name = "totalSaleTitleLabel";
            this.totalSaleTitleLabel.Size = new System.Drawing.Size(98, 20);
            this.totalSaleTitleLabel.TabIndex = 10;
            this.totalSaleTitleLabel.Text = "Total of Sale";
            // 
            // totalSaleLabel
            // 
            this.totalSaleLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalSaleLabel.Location = new System.Drawing.Point(189, 229);
            this.totalSaleLabel.Name = "totalSaleLabel";
            this.totalSaleLabel.Size = new System.Drawing.Size(100, 23);
            this.totalSaleLabel.TabIndex = 6;
            // 
            // Form1
            // 
            this.AcceptButton = this.calculateButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.exitButton;
            this.ClientSize = new System.Drawing.Size(299, 343);
            this.Controls.Add(this.totalSaleLabel);
            this.Controls.Add(this.totalSaleTitleLabel);
            this.Controls.Add(this.totalSalesTaxLabel);
            this.Controls.Add(this.totalSalesTaxTitleLabel);
            this.Controls.Add(this.countySalesTaxTitleLabel);
            this.Controls.Add(this.purchaseAmountTextBox);
            this.Controls.Add(this.countySalesTaxLabel);
            this.Controls.Add(this.stateSalesTaxLabel);
            this.Controls.Add(this.stateSalesTaxTitleLabel);
            this.Controls.Add(this.purchaseTitleLabel);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.exitButton);
            this.Name = "Form1";
            this.Text = "Sales Tax and Total";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Label purchaseTitleLabel;
        private System.Windows.Forms.Label stateSalesTaxTitleLabel;
        private System.Windows.Forms.Label stateSalesTaxLabel;
        private System.Windows.Forms.Label countySalesTaxLabel;
        private System.Windows.Forms.TextBox purchaseAmountTextBox;
        private System.Windows.Forms.Label countySalesTaxTitleLabel;
        private System.Windows.Forms.Label totalSalesTaxTitleLabel;
        private System.Windows.Forms.Label totalSalesTaxLabel;
        private System.Windows.Forms.Label totalSaleTitleLabel;
        private System.Windows.Forms.Label totalSaleLabel;
    }
}

