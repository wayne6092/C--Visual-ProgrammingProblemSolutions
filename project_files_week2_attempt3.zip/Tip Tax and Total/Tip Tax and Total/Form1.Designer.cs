﻿namespace Tip_Tax_and_Total
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.foodChargeTextBox = new System.Windows.Forms.TextBox();
            this.taxLabel = new System.Windows.Forms.Label();
            this.tipLabel = new System.Windows.Forms.Label();
            this.totalLabel = new System.Windows.Forms.Label();
            this.calculateButton = new System.Windows.Forms.Button();
            this.taxTitleLabel = new System.Windows.Forms.Label();
            this.tipTitleLabel = new System.Windows.Forms.Label();
            this.total = new System.Windows.Forms.Label();
            this.foodBill = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // foodChargeTextBox
            // 
            this.foodChargeTextBox.Location = new System.Drawing.Point(151, 29);
            this.foodChargeTextBox.Name = "foodChargeTextBox";
            this.foodChargeTextBox.Size = new System.Drawing.Size(100, 26);
            this.foodChargeTextBox.TabIndex = 0;
            // 
            // taxLabel
            // 
            this.taxLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.taxLabel.Location = new System.Drawing.Point(151, 70);
            this.taxLabel.Name = "taxLabel";
            this.taxLabel.Size = new System.Drawing.Size(100, 26);
            this.taxLabel.TabIndex = 1;
            this.taxLabel.Click += new System.EventHandler(this.label1_Click);
            // 
            // tipLabel
            // 
            this.tipLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tipLabel.Location = new System.Drawing.Point(151, 119);
            this.tipLabel.Name = "tipLabel";
            this.tipLabel.Size = new System.Drawing.Size(100, 29);
            this.tipLabel.TabIndex = 2;
            // 
            // totalLabel
            // 
            this.totalLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalLabel.Location = new System.Drawing.Point(151, 168);
            this.totalLabel.Name = "totalLabel";
            this.totalLabel.Size = new System.Drawing.Size(100, 33);
            this.totalLabel.TabIndex = 3;
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(151, 223);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(100, 39);
            this.calculateButton.TabIndex = 4;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // taxTitleLabel
            // 
            this.taxTitleLabel.AutoSize = true;
            this.taxTitleLabel.Location = new System.Drawing.Point(91, 76);
            this.taxTitleLabel.Name = "taxTitleLabel";
            this.taxTitleLabel.Size = new System.Drawing.Size(34, 20);
            this.taxTitleLabel.TabIndex = 8;
            this.taxTitleLabel.Text = "Tax";
            // 
            // tipTitleLabel
            // 
            this.tipTitleLabel.AutoSize = true;
            this.tipTitleLabel.Location = new System.Drawing.Point(91, 128);
            this.tipTitleLabel.Name = "tipTitleLabel";
            this.tipTitleLabel.Size = new System.Drawing.Size(30, 20);
            this.tipTitleLabel.TabIndex = 7;
            this.tipTitleLabel.Text = "Tip";
            // 
            // total
            // 
            this.total.AutoSize = true;
            this.total.Location = new System.Drawing.Point(74, 181);
            this.total.Name = "total";
            this.total.Size = new System.Drawing.Size(44, 20);
            this.total.TabIndex = 6;
            this.total.Text = "Total";
            // 
            // foodBill
            // 
            this.foodBill.AutoSize = true;
            this.foodBill.Location = new System.Drawing.Point(70, 35);
            this.foodBill.Name = "foodBill";
            this.foodBill.Size = new System.Drawing.Size(70, 20);
            this.foodBill.TabIndex = 9;
            this.foodBill.Text = "Food Bill";
            // 
            // exitButton
            // 
            this.exitButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.exitButton.Location = new System.Drawing.Point(62, 223);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(78, 39);
            this.exitButton.TabIndex = 5;
            this.exitButton.Text = "&Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AcceptButton = this.calculateButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.exitButton;
            this.ClientSize = new System.Drawing.Size(329, 296);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.foodBill);
            this.Controls.Add(this.total);
            this.Controls.Add(this.tipTitleLabel);
            this.Controls.Add(this.taxTitleLabel);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.totalLabel);
            this.Controls.Add(this.tipLabel);
            this.Controls.Add(this.taxLabel);
            this.Controls.Add(this.foodChargeTextBox);
            this.Name = "Form1";
            this.Text = "Tip Tax and Total";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox foodChargeTextBox;
        private System.Windows.Forms.Label taxLabel;
        private System.Windows.Forms.Label tipLabel;
        private System.Windows.Forms.Label totalLabel;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Label taxTitleLabel;
        private System.Windows.Forms.Label tipTitleLabel;
        private System.Windows.Forms.Label total;
        private System.Windows.Forms.Label foodBill;
        private System.Windows.Forms.Button exitButton;
    }
}

