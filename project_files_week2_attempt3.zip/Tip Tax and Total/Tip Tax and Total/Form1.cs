﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tip_Tax_and_Total
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
           
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            decimal foodCharge;
            decimal tax;
            decimal total;
            decimal tip;

            try
            {
                //Get food charge
                //converts string to decimal
                foodCharge = decimal.Parse(foodChargeTextBox.Text);

                //calculate tip, tax and total
                tip = foodCharge * 0.15m;

                tax = foodCharge * 0.07m;

                total = foodCharge + tip + tax;

                tipLabel.Text = tip.ToString("c");
                taxLabel.Text = tax.ToString("c");
                totalLabel.Text = total.ToString("c");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
