﻿namespace Sentence_Builder_2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Btnthe = new System.Windows.Forms.Button();
            this.The = new System.Windows.Forms.Button();
            this.to = new System.Windows.Forms.Button();
            this.baby = new System.Windows.Forms.Button();
            this.kid = new System.Windows.Forms.Button();
            this.exclaimationPoint = new System.Windows.Forms.Button();
            this.comma = new System.Windows.Forms.Button();
            this.period = new System.Windows.Forms.Button();
            this.space = new System.Windows.Forms.Button();
            this.drove = new System.Windows.Forms.Button();
            this.laughedAt = new System.Windows.Forms.Button();
            this.spoke = new System.Windows.Forms.Button();
            this.rode = new System.Windows.Forms.Button();
            this.lookAt = new System.Windows.Forms.Button();
            this.strange = new System.Windows.Forms.Button();
            this.small = new System.Windows.Forms.Button();
            this.beautiful = new System.Windows.Forms.Button();
            this.bicycle = new System.Windows.Forms.Button();
            this.car = new System.Windows.Forms.Button();
            this.cat = new System.Windows.Forms.Button();
            this.dog = new System.Windows.Forms.Button();
            this.woman = new System.Windows.Forms.Button();
            this.man = new System.Windows.Forms.Button();
            this.an = new System.Windows.Forms.Button();
            this.AnButton = new System.Windows.Forms.Button();
            this.aButton = new System.Windows.Forms.Button();
            this.A = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.sentenceLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Btnthe
            // 
            this.Btnthe.Location = new System.Drawing.Point(159, 77);
            this.Btnthe.Name = "Btnthe";
            this.Btnthe.Size = new System.Drawing.Size(75, 34);
            this.Btnthe.TabIndex = 8;
            this.Btnthe.Text = "the";
            this.Btnthe.UseVisualStyleBackColor = true;
            this.Btnthe.Click += new System.EventHandler(this.Btnthe_Click);
            // 
            // The
            // 
            this.The.Location = new System.Drawing.Point(62, 77);
            this.The.Name = "The";
            this.The.Size = new System.Drawing.Size(75, 34);
            this.The.TabIndex = 7;
            this.The.Text = "The";
            this.The.UseVisualStyleBackColor = true;
            this.The.Click += new System.EventHandler(this.The_Click);
            // 
            // to
            // 
            this.to.Location = new System.Drawing.Point(656, 127);
            this.to.Name = "to";
            this.to.Size = new System.Drawing.Size(75, 34);
            this.to.TabIndex = 20;
            this.to.Text = "to";
            this.to.UseVisualStyleBackColor = true;
            this.to.Click += new System.EventHandler(this.to_Click);
            // 
            // baby
            // 
            this.baby.Location = new System.Drawing.Point(555, 177);
            this.baby.Name = "baby";
            this.baby.Size = new System.Drawing.Size(75, 34);
            this.baby.TabIndex = 26;
            this.baby.Text = "baby";
            this.baby.UseVisualStyleBackColor = true;
            this.baby.Click += new System.EventHandler(this.baby_Click);
            // 
            // kid
            // 
            this.kid.Location = new System.Drawing.Point(450, 177);
            this.kid.Name = "kid";
            this.kid.Size = new System.Drawing.Size(75, 34);
            this.kid.TabIndex = 25;
            this.kid.Text = "kid";
            this.kid.UseVisualStyleBackColor = true;
            this.kid.Click += new System.EventHandler(this.kid_Click);
            // 
            // exclaimationPoint
            // 
            this.exclaimationPoint.Location = new System.Drawing.Point(349, 177);
            this.exclaimationPoint.Name = "exclaimationPoint";
            this.exclaimationPoint.Size = new System.Drawing.Size(75, 34);
            this.exclaimationPoint.TabIndex = 24;
            this.exclaimationPoint.Text = "(!)";
            this.exclaimationPoint.UseVisualStyleBackColor = true;
            this.exclaimationPoint.Click += new System.EventHandler(this.exclaimationPoint_Click);
            // 
            // comma
            // 
            this.comma.Location = new System.Drawing.Point(252, 177);
            this.comma.Name = "comma";
            this.comma.Size = new System.Drawing.Size(75, 34);
            this.comma.TabIndex = 23;
            this.comma.Text = "(,)";
            this.comma.UseVisualStyleBackColor = true;
            this.comma.Click += new System.EventHandler(this.comma_Click);
            // 
            // period
            // 
            this.period.Location = new System.Drawing.Point(159, 177);
            this.period.Name = "period";
            this.period.Size = new System.Drawing.Size(75, 34);
            this.period.TabIndex = 22;
            this.period.Text = "(.)";
            this.period.UseVisualStyleBackColor = true;
            this.period.Click += new System.EventHandler(this.period_Click);
            // 
            // space
            // 
            this.space.Location = new System.Drawing.Point(55, 177);
            this.space.Name = "space";
            this.space.Size = new System.Drawing.Size(91, 34);
            this.space.TabIndex = 21;
            this.space.Text = "(Space)";
            this.space.UseVisualStyleBackColor = true;
            this.space.Click += new System.EventHandler(this.space_Click);
            // 
            // drove
            // 
            this.drove.Location = new System.Drawing.Point(656, 77);
            this.drove.Name = "drove";
            this.drove.Size = new System.Drawing.Size(75, 34);
            this.drove.TabIndex = 13;
            this.drove.Text = "drove";
            this.drove.UseVisualStyleBackColor = true;
            this.drove.Click += new System.EventHandler(this.drove_Click);
            // 
            // laughedAt
            // 
            this.laughedAt.Location = new System.Drawing.Point(555, 116);
            this.laughedAt.Name = "laughedAt";
            this.laughedAt.Size = new System.Drawing.Size(81, 55);
            this.laughedAt.TabIndex = 19;
            this.laughedAt.Text = "laughed at";
            this.laughedAt.UseVisualStyleBackColor = true;
            this.laughedAt.Click += new System.EventHandler(this.laughedAt_Click);
            // 
            // spoke
            // 
            this.spoke.Location = new System.Drawing.Point(450, 127);
            this.spoke.Name = "spoke";
            this.spoke.Size = new System.Drawing.Size(75, 34);
            this.spoke.TabIndex = 18;
            this.spoke.Text = "spoke to";
            this.spoke.UseVisualStyleBackColor = true;
            this.spoke.Click += new System.EventHandler(this.spoke_Click);
            // 
            // rode
            // 
            this.rode.Location = new System.Drawing.Point(349, 127);
            this.rode.Name = "rode";
            this.rode.Size = new System.Drawing.Size(75, 34);
            this.rode.TabIndex = 17;
            this.rode.Text = "rode";
            this.rode.UseVisualStyleBackColor = true;
            this.rode.Click += new System.EventHandler(this.rode_Click);
            // 
            // lookAt
            // 
            this.lookAt.Location = new System.Drawing.Point(252, 127);
            this.lookAt.Name = "lookAt";
            this.lookAt.Size = new System.Drawing.Size(75, 34);
            this.lookAt.TabIndex = 16;
            this.lookAt.Text = "look at";
            this.lookAt.UseVisualStyleBackColor = true;
            this.lookAt.Click += new System.EventHandler(this.lookAt_Click);
            // 
            // strange
            // 
            this.strange.Location = new System.Drawing.Point(159, 127);
            this.strange.Name = "strange";
            this.strange.Size = new System.Drawing.Size(75, 34);
            this.strange.TabIndex = 15;
            this.strange.Text = "strange";
            this.strange.UseVisualStyleBackColor = true;
            this.strange.Click += new System.EventHandler(this.strange_Click);
            // 
            // small
            // 
            this.small.Location = new System.Drawing.Point(62, 127);
            this.small.Name = "small";
            this.small.Size = new System.Drawing.Size(75, 34);
            this.small.TabIndex = 14;
            this.small.Text = "small";
            this.small.UseVisualStyleBackColor = true;
            this.small.Click += new System.EventHandler(this.small_Click);
            // 
            // beautiful
            // 
            this.beautiful.Location = new System.Drawing.Point(445, 27);
            this.beautiful.Name = "beautiful";
            this.beautiful.Size = new System.Drawing.Size(84, 34);
            this.beautiful.TabIndex = 4;
            this.beautiful.Text = "beautiful";
            this.beautiful.UseVisualStyleBackColor = true;
            this.beautiful.Click += new System.EventHandler(this.beautiful_Click);
            // 
            // bicycle
            // 
            this.bicycle.Location = new System.Drawing.Point(555, 27);
            this.bicycle.Name = "bicycle";
            this.bicycle.Size = new System.Drawing.Size(75, 34);
            this.bicycle.TabIndex = 5;
            this.bicycle.Text = "bicycle";
            this.bicycle.UseVisualStyleBackColor = true;
            this.bicycle.Click += new System.EventHandler(this.bicycle_Click);
            // 
            // car
            // 
            this.car.Location = new System.Drawing.Point(656, 27);
            this.car.Name = "car";
            this.car.Size = new System.Drawing.Size(75, 34);
            this.car.TabIndex = 6;
            this.car.Text = "car";
            this.car.UseVisualStyleBackColor = true;
            this.car.Click += new System.EventHandler(this.car_Click);
            // 
            // cat
            // 
            this.cat.Location = new System.Drawing.Point(349, 77);
            this.cat.Name = "cat";
            this.cat.Size = new System.Drawing.Size(75, 34);
            this.cat.TabIndex = 10;
            this.cat.Text = "cat";
            this.cat.UseVisualStyleBackColor = true;
            this.cat.Click += new System.EventHandler(this.cat_Click);
            // 
            // dog
            // 
            this.dog.Location = new System.Drawing.Point(450, 77);
            this.dog.Name = "dog";
            this.dog.Size = new System.Drawing.Size(75, 34);
            this.dog.TabIndex = 11;
            this.dog.Text = "dog";
            this.dog.UseVisualStyleBackColor = true;
            this.dog.Click += new System.EventHandler(this.dog_Click);
            // 
            // woman
            // 
            this.woman.Location = new System.Drawing.Point(555, 77);
            this.woman.Name = "woman";
            this.woman.Size = new System.Drawing.Size(75, 34);
            this.woman.TabIndex = 12;
            this.woman.Text = "woman";
            this.woman.UseVisualStyleBackColor = true;
            this.woman.Click += new System.EventHandler(this.woman_Click);
            // 
            // man
            // 
            this.man.Location = new System.Drawing.Point(252, 77);
            this.man.Name = "man";
            this.man.Size = new System.Drawing.Size(75, 34);
            this.man.TabIndex = 9;
            this.man.Text = "man";
            this.man.UseVisualStyleBackColor = true;
            this.man.Click += new System.EventHandler(this.man_Click);
            // 
            // an
            // 
            this.an.Location = new System.Drawing.Point(349, 27);
            this.an.Name = "an";
            this.an.Size = new System.Drawing.Size(75, 34);
            this.an.TabIndex = 3;
            this.an.Text = "an";
            this.an.UseVisualStyleBackColor = true;
            this.an.Click += new System.EventHandler(this.an_Click);
            // 
            // AnButton
            // 
            this.AnButton.Location = new System.Drawing.Point(252, 27);
            this.AnButton.Name = "AnButton";
            this.AnButton.Size = new System.Drawing.Size(75, 34);
            this.AnButton.TabIndex = 2;
            this.AnButton.Text = "An";
            this.AnButton.UseVisualStyleBackColor = true;
            this.AnButton.Click += new System.EventHandler(this.AnButton_Click);
            // 
            // aButton
            // 
            this.aButton.Location = new System.Drawing.Point(159, 27);
            this.aButton.Name = "aButton";
            this.aButton.Size = new System.Drawing.Size(75, 34);
            this.aButton.TabIndex = 1;
            this.aButton.Text = "a";
            this.aButton.UseVisualStyleBackColor = true;
            this.aButton.Click += new System.EventHandler(this.aButton_Click);
            // 
            // A
            // 
            this.A.Location = new System.Drawing.Point(62, 27);
            this.A.Name = "A";
            this.A.Size = new System.Drawing.Size(75, 34);
            this.A.TabIndex = 0;
            this.A.Text = "A";
            this.A.UseVisualStyleBackColor = true;
            this.A.Click += new System.EventHandler(this.A_Click);
            // 
            // exitButton
            // 
            this.exitButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.exitButton.Location = new System.Drawing.Point(444, 359);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(164, 50);
            this.exitButton.TabIndex = 28;
            this.exitButton.Text = "&Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(185, 359);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(131, 50);
            this.clearButton.TabIndex = 27;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // sentenceLabel
            // 
            this.sentenceLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sentenceLabel.Location = new System.Drawing.Point(185, 247);
            this.sentenceLabel.Name = "sentenceLabel";
            this.sentenceLabel.Size = new System.Drawing.Size(423, 83);
            this.sentenceLabel.TabIndex = 62;
            // 
            // Form1
            // 
            this.AcceptButton = this.clearButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.exitButton;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.sentenceLabel);
            this.Controls.Add(this.Btnthe);
            this.Controls.Add(this.The);
            this.Controls.Add(this.to);
            this.Controls.Add(this.baby);
            this.Controls.Add(this.kid);
            this.Controls.Add(this.exclaimationPoint);
            this.Controls.Add(this.comma);
            this.Controls.Add(this.period);
            this.Controls.Add(this.space);
            this.Controls.Add(this.drove);
            this.Controls.Add(this.laughedAt);
            this.Controls.Add(this.spoke);
            this.Controls.Add(this.rode);
            this.Controls.Add(this.lookAt);
            this.Controls.Add(this.strange);
            this.Controls.Add(this.small);
            this.Controls.Add(this.beautiful);
            this.Controls.Add(this.bicycle);
            this.Controls.Add(this.car);
            this.Controls.Add(this.cat);
            this.Controls.Add(this.dog);
            this.Controls.Add(this.woman);
            this.Controls.Add(this.man);
            this.Controls.Add(this.an);
            this.Controls.Add(this.AnButton);
            this.Controls.Add(this.aButton);
            this.Controls.Add(this.A);
            this.Name = "Form1";
            this.Text = "Sentence Builder 2";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Btnthe;
        private System.Windows.Forms.Button The;
        private System.Windows.Forms.Button to;
        private System.Windows.Forms.Button baby;
        private System.Windows.Forms.Button kid;
        private System.Windows.Forms.Button exclaimationPoint;
        private System.Windows.Forms.Button comma;
        private System.Windows.Forms.Button period;
        private System.Windows.Forms.Button space;
        private System.Windows.Forms.Button drove;
        private System.Windows.Forms.Button laughedAt;
        private System.Windows.Forms.Button spoke;
        private System.Windows.Forms.Button rode;
        private System.Windows.Forms.Button lookAt;
        private System.Windows.Forms.Button strange;
        private System.Windows.Forms.Button small;
        private System.Windows.Forms.Button beautiful;
        private System.Windows.Forms.Button bicycle;
        private System.Windows.Forms.Button car;
        private System.Windows.Forms.Button cat;
        private System.Windows.Forms.Button dog;
        private System.Windows.Forms.Button woman;
        private System.Windows.Forms.Button man;
        private System.Windows.Forms.Button an;
        private System.Windows.Forms.Button AnButton;
        private System.Windows.Forms.Button aButton;
        private System.Windows.Forms.Button A;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Label sentenceLabel;
    }
}

