﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sentence_Builder_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void A_Click(object sender, EventArgs e)
        {
            string A = "A";
            sentenceLabel.Text = sentenceLabel.Text + A;
        }

        private void aButton_Click(object sender, EventArgs e)
        {
            string a = "a";
            sentenceLabel.Text = sentenceLabel.Text + a;
        }

        private void AnButton_Click(object sender, EventArgs e)
        {
            string An = "An";
            sentenceLabel.Text = sentenceLabel.Text + An;
        }

        private void an_Click(object sender, EventArgs e)
        {
            string an = "an";
            sentenceLabel.Text = sentenceLabel.Text + an;
        }

        private void beautiful_Click(object sender, EventArgs e)
        {
            string strings = "beautiful";
            sentenceLabel.Text = sentenceLabel.Text + strings;
        }

        private void bicycle_Click(object sender, EventArgs e)
        {
            string strings = "bicycle";
            sentenceLabel.Text = sentenceLabel.Text + strings;
        }

        private void car_Click(object sender, EventArgs e)
        {
            string strings = "car";
            sentenceLabel.Text = sentenceLabel.Text + strings;
        }

        private void The_Click(object sender, EventArgs e)
        {
            string The = "The";
            sentenceLabel.Text = sentenceLabel.Text + The;
        }

        private void Btnthe_Click(object sender, EventArgs e)
        {
            string strings = "the";
            sentenceLabel.Text = sentenceLabel.Text + strings;
        }

        private void man_Click(object sender, EventArgs e)
        {
            string strings = "man";
            sentenceLabel.Text = sentenceLabel.Text + strings;
        }

        private void cat_Click(object sender, EventArgs e)
        {
            string strings = "cat";
            sentenceLabel.Text = sentenceLabel.Text + strings;
        }

        private void dog_Click(object sender, EventArgs e)
        {
            string strings = "dog";
            sentenceLabel.Text = sentenceLabel.Text + strings;
        }

        private void woman_Click(object sender, EventArgs e)
        {
            string strings = "woman";
            sentenceLabel.Text = sentenceLabel.Text + strings;
        }

        private void drove_Click(object sender, EventArgs e)
        {
            string strings = "drove";
            sentenceLabel.Text = sentenceLabel.Text + strings;
        }

        private void small_Click(object sender, EventArgs e)
        {
            string strings = "small";
            sentenceLabel.Text = sentenceLabel.Text + strings;
        }

        private void strange_Click(object sender, EventArgs e)
        {
            string strings = "strange";
            sentenceLabel.Text = sentenceLabel.Text + strings;
        }

        private void lookAt_Click(object sender, EventArgs e)
        {
            string strings = "look at";
            sentenceLabel.Text = sentenceLabel.Text + strings;
        }

        private void rode_Click(object sender, EventArgs e)
        {
            string strings = "rode";
            sentenceLabel.Text = sentenceLabel.Text + strings;
        }

        private void spoke_Click(object sender, EventArgs e)
        {
            string strings = "spoke";
            sentenceLabel.Text = sentenceLabel.Text + strings;
        }

        private void laughedAt_Click(object sender, EventArgs e)
        {
            string strings = "laughed at";
            sentenceLabel.Text = sentenceLabel.Text + strings;
        }

        private void to_Click(object sender, EventArgs e)
        {
            string strings = "to";
            sentenceLabel.Text = sentenceLabel.Text + strings;
        }

        private void space_Click(object sender, EventArgs e)
        {
            string strings = " ";
            sentenceLabel.Text = sentenceLabel.Text + strings;
        }

        private void period_Click(object sender, EventArgs e)
        {
            string strings = ".";
            sentenceLabel.Text = sentenceLabel.Text + strings;
        }

        private void comma_Click(object sender, EventArgs e)
        {
            string strings = ",";
            sentenceLabel.Text = sentenceLabel.Text + strings;
        }

        private void exclaimationPoint_Click(object sender, EventArgs e)
        {
            string strings = "!";
            sentenceLabel.Text = sentenceLabel.Text + strings;
        }

        private void kid_Click(object sender, EventArgs e)
        {
            string strings = "kid";
            sentenceLabel.Text = sentenceLabel.Text + strings;
        }

        private void baby_Click(object sender, EventArgs e)
        {
            string strings = "baby";
            sentenceLabel.Text = sentenceLabel.Text + strings;
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            sentenceLabel.Text = "";
        }
    }
}
