﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Paint_Job_Estimator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            try
            {
                double wallSqFt = double.Parse(textBoxSquareFeet.Text);
                decimal pricePerGallon = decimal.Parse(textBoxPricePerGallon.Text);
                double gallonsOfPaint = wallSqFt / 115;
                double hoursOfLabor = wallSqFt / 14.375;
                decimal laborCost = (decimal)hoursOfLabor * 20;
                decimal paintCostTotal = pricePerGallon * (decimal)gallonsOfPaint;
                decimal jobTotalCost = laborCost + paintCostTotal;

                labelGallonsNeeded.Text = gallonsOfPaint.ToString("n");
                labelHoursLabor.Text = hoursOfLabor.ToString("n");
                labelTotalLaborCost.Text = laborCost.ToString("c");
                labelTotalPaintCost.Text = paintCostTotal.ToString("c");
                labelTotalCost.Text = jobTotalCost.ToString("c");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            textBoxSquareFeet.Text = "0";
            textBoxPricePerGallon.Text = "0";
            labelGallonsNeeded.Text = "0";
            labelHoursLabor.Text = "0";
            labelTotalLaborCost.Text = "0";
            labelTotalPaintCost.Text = "0";
            labelTotalCost.Text = "0";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
