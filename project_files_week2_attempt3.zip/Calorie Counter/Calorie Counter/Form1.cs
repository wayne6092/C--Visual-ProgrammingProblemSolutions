﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calorie_Counter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBoxBanana_Click(object sender, EventArgs e)
        {
            try
            {
                int calories = int.Parse(totalCaloriesLabel.Text);
                int bananaCal = 115;
                int totalCalories = calories + bananaCal;

                totalCaloriesLabel.Text = totalCalories.ToString();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void pictureBoxApple_Click(object sender, EventArgs e)
        {
            try
            {
                int calories = int.Parse(totalCaloriesLabel.Text);
                int appleCal = 80;
                int totalCalories = calories + appleCal;

                totalCaloriesLabel.Text = totalCalories.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void pictureBoxOrange_Click(object sender, EventArgs e)
        {
            try
            {
                int calories = int.Parse(totalCaloriesLabel.Text);
                int orangeCal = 90;
                int totalCalories = calories + orangeCal;

                totalCaloriesLabel.Text = totalCalories.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void pictureBoxPear_Click(object sender, EventArgs e)
        {
            try
            {
                int calories = int.Parse(totalCaloriesLabel.Text);
                int pearCal = 120;
                int totalCalories = calories + pearCal;

                totalCaloriesLabel.Text = totalCalories.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void resetButton_Click(object sender, EventArgs e)
        {
            totalCaloriesLabel.Text = "0";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
