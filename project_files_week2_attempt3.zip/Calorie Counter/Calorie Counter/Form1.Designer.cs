﻿namespace Calorie_Counter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.totalCaloriesTitleLabel = new System.Windows.Forms.Label();
            this.totalCaloriesLabel = new System.Windows.Forms.Label();
            this.resetButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBoxPear = new System.Windows.Forms.PictureBox();
            this.pictureBoxApple = new System.Windows.Forms.PictureBox();
            this.pictureBoxBanana = new System.Windows.Forms.PictureBox();
            this.pictureBoxOrange = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPear)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxApple)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBanana)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOrange)).BeginInit();
            this.SuspendLayout();
            // 
            // totalCaloriesTitleLabel
            // 
            this.totalCaloriesTitleLabel.AutoSize = true;
            this.totalCaloriesTitleLabel.Location = new System.Drawing.Point(326, 13);
            this.totalCaloriesTitleLabel.Name = "totalCaloriesTitleLabel";
            this.totalCaloriesTitleLabel.Size = new System.Drawing.Size(105, 20);
            this.totalCaloriesTitleLabel.TabIndex = 3;
            this.totalCaloriesTitleLabel.Text = "Total Calories";
            // 
            // totalCaloriesLabel
            // 
            this.totalCaloriesLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalCaloriesLabel.Location = new System.Drawing.Point(326, 52);
            this.totalCaloriesLabel.Name = "totalCaloriesLabel";
            this.totalCaloriesLabel.Size = new System.Drawing.Size(100, 23);
            this.totalCaloriesLabel.TabIndex = 2;
            this.totalCaloriesLabel.Text = "0";
            // 
            // resetButton
            // 
            this.resetButton.Location = new System.Drawing.Point(316, 137);
            this.resetButton.Name = "resetButton";
            this.resetButton.Size = new System.Drawing.Size(110, 50);
            this.resetButton.TabIndex = 0;
            this.resetButton.Text = "Reset";
            this.resetButton.UseVisualStyleBackColor = true;
            this.resetButton.Click += new System.EventHandler(this.resetButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.exitButton.Location = new System.Drawing.Point(316, 193);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(110, 50);
            this.exitButton.TabIndex = 1;
            this.exitButton.Text = "&Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.pictureBoxPear);
            this.panel1.Controls.Add(this.pictureBoxApple);
            this.panel1.Controls.Add(this.pictureBoxBanana);
            this.panel1.Controls.Add(this.pictureBoxOrange);
            this.panel1.Location = new System.Drawing.Point(35, 25);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(243, 218);
            this.panel1.TabIndex = 4;
            // 
            // pictureBoxPear
            // 
            this.pictureBoxPear.Image = global::Calorie_Counter.Properties.Resources.Pear;
            this.pictureBoxPear.Location = new System.Drawing.Point(126, 110);
            this.pictureBoxPear.Name = "pictureBoxPear";
            this.pictureBoxPear.Size = new System.Drawing.Size(112, 101);
            this.pictureBoxPear.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxPear.TabIndex = 3;
            this.pictureBoxPear.TabStop = false;
            this.pictureBoxPear.Click += new System.EventHandler(this.pictureBoxPear_Click);
            // 
            // pictureBoxApple
            // 
            this.pictureBoxApple.Image = global::Calorie_Counter.Properties.Resources.Apple;
            this.pictureBoxApple.Location = new System.Drawing.Point(5, 3);
            this.pictureBoxApple.Name = "pictureBoxApple";
            this.pictureBoxApple.Size = new System.Drawing.Size(115, 101);
            this.pictureBoxApple.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxApple.TabIndex = 2;
            this.pictureBoxApple.TabStop = false;
            this.pictureBoxApple.Click += new System.EventHandler(this.pictureBoxApple_Click);
            // 
            // pictureBoxBanana
            // 
            this.pictureBoxBanana.Image = global::Calorie_Counter.Properties.Resources.Banana;
            this.pictureBoxBanana.Location = new System.Drawing.Point(126, 3);
            this.pictureBoxBanana.Name = "pictureBoxBanana";
            this.pictureBoxBanana.Size = new System.Drawing.Size(112, 101);
            this.pictureBoxBanana.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxBanana.TabIndex = 1;
            this.pictureBoxBanana.TabStop = false;
            this.pictureBoxBanana.Click += new System.EventHandler(this.pictureBoxBanana_Click);
            // 
            // pictureBoxOrange
            // 
            this.pictureBoxOrange.Image = global::Calorie_Counter.Properties.Resources.Orange;
            this.pictureBoxOrange.Location = new System.Drawing.Point(3, 110);
            this.pictureBoxOrange.Name = "pictureBoxOrange";
            this.pictureBoxOrange.Size = new System.Drawing.Size(117, 101);
            this.pictureBoxOrange.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxOrange.TabIndex = 0;
            this.pictureBoxOrange.TabStop = false;
            this.pictureBoxOrange.Click += new System.EventHandler(this.pictureBoxOrange_Click);
            // 
            // Form1
            // 
            this.AcceptButton = this.resetButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.exitButton;
            this.ClientSize = new System.Drawing.Size(445, 264);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.resetButton);
            this.Controls.Add(this.totalCaloriesLabel);
            this.Controls.Add(this.totalCaloriesTitleLabel);
            this.Name = "Form1";
            this.Text = "Calorie Counter";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPear)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxApple)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBanana)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOrange)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label totalCaloriesTitleLabel;
        private System.Windows.Forms.Label totalCaloriesLabel;
        private System.Windows.Forms.Button resetButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBoxPear;
        private System.Windows.Forms.PictureBox pictureBoxApple;
        private System.Windows.Forms.PictureBox pictureBoxBanana;
        private System.Windows.Forms.PictureBox pictureBoxOrange;
    }
}

