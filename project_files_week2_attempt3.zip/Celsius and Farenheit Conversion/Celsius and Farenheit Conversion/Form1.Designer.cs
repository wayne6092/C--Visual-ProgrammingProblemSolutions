﻿namespace Celsius_and_Farenheit_Conversion
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tempTextBox = new System.Windows.Forms.TextBox();
            this.tempTitleLabel = new System.Windows.Forms.Label();
            this.conversionLabel = new System.Windows.Forms.Label();
            this.conversionTitleLabel = new System.Windows.Forms.Label();
            this.fToC = new System.Windows.Forms.Button();
            this.celsius = new System.Windows.Forms.Button();
            this.quitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // tempTextBox
            // 
            this.tempTextBox.Location = new System.Drawing.Point(224, 36);
            this.tempTextBox.Name = "tempTextBox";
            this.tempTextBox.Size = new System.Drawing.Size(100, 26);
            this.tempTextBox.TabIndex = 0;
            // 
            // tempTitleLabel
            // 
            this.tempTitleLabel.AutoSize = true;
            this.tempTitleLabel.Location = new System.Drawing.Point(39, 42);
            this.tempTitleLabel.Name = "tempTitleLabel";
            this.tempTitleLabel.Size = new System.Drawing.Size(167, 20);
            this.tempTitleLabel.TabIndex = 1;
            this.tempTitleLabel.Text = "Temperature (°C or °F)";
            // 
            // conversionLabel
            // 
            this.conversionLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.conversionLabel.Location = new System.Drawing.Point(224, 108);
            this.conversionLabel.Name = "conversionLabel";
            this.conversionLabel.Size = new System.Drawing.Size(100, 23);
            this.conversionLabel.TabIndex = 2;
            // 
            // conversionTitleLabel
            // 
            this.conversionTitleLabel.AutoSize = true;
            this.conversionTitleLabel.Location = new System.Drawing.Point(114, 109);
            this.conversionTitleLabel.Name = "conversionTitleLabel";
            this.conversionTitleLabel.Size = new System.Drawing.Size(88, 20);
            this.conversionTitleLabel.TabIndex = 3;
            this.conversionTitleLabel.Text = "Conversion";
            // 
            // fToC
            // 
            this.fToC.Location = new System.Drawing.Point(110, 170);
            this.fToC.Name = "fToC";
            this.fToC.Size = new System.Drawing.Size(96, 33);
            this.fToC.TabIndex = 4;
            this.fToC.Text = "Farenheit";
            this.fToC.UseVisualStyleBackColor = true;
            this.fToC.Click += new System.EventHandler(this.fToC_Click);
            // 
            // celsius
            // 
            this.celsius.Location = new System.Drawing.Point(234, 170);
            this.celsius.Name = "celsius";
            this.celsius.Size = new System.Drawing.Size(90, 33);
            this.celsius.TabIndex = 5;
            this.celsius.Text = "Celsius";
            this.celsius.UseVisualStyleBackColor = true;
            this.celsius.Click += new System.EventHandler(this.celsius_Click);
            // 
            // quitButton
            // 
            this.quitButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.quitButton.Location = new System.Drawing.Point(12, 170);
            this.quitButton.Name = "quitButton";
            this.quitButton.Size = new System.Drawing.Size(73, 33);
            this.quitButton.TabIndex = 6;
            this.quitButton.Text = "&Quit";
            this.quitButton.UseVisualStyleBackColor = true;
            this.quitButton.Click += new System.EventHandler(this.quitButton_Click);
            // 
            // Form1
            // 
            this.AcceptButton = this.fToC;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.quitButton;
            this.ClientSize = new System.Drawing.Size(343, 255);
            this.Controls.Add(this.quitButton);
            this.Controls.Add(this.celsius);
            this.Controls.Add(this.fToC);
            this.Controls.Add(this.conversionTitleLabel);
            this.Controls.Add(this.conversionLabel);
            this.Controls.Add(this.tempTitleLabel);
            this.Controls.Add(this.tempTextBox);
            this.Name = "Form1";
            this.Text = "Temperature Conversion";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tempTextBox;
        private System.Windows.Forms.Label tempTitleLabel;
        private System.Windows.Forms.Label conversionLabel;
        private System.Windows.Forms.Label conversionTitleLabel;
        private System.Windows.Forms.Button fToC;
        private System.Windows.Forms.Button celsius;
        private System.Windows.Forms.Button quitButton;
    }
}

