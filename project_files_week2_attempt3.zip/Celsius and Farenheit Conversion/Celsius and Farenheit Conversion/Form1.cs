﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Celsius_and_Farenheit_Conversion
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void fToC_Click(object sender, EventArgs e)
        {
            double farenheit;
            double celsius;

            try
            {
                celsius = double.Parse(tempTextBox.Text);
                farenheit = (celsius * 9/5) + 32;
                string strings = "°F " + farenheit.ToString("n");

                conversionLabel.Text = strings;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void celsius_Click(object sender, EventArgs e)
        {
            double farenheit;
            double celsius;

            try
            {
                farenheit = double.Parse(tempTextBox.Text);
                celsius = (farenheit - 32) * 5 / 9;
                string strings = "°C " + celsius.ToString("n");

                conversionLabel.Text = strings;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void quitButton_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
