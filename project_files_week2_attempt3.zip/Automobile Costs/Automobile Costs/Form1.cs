﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Automobile_Costs
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            try
            {
                decimal loanPayment = decimal.Parse(loanPaymentTextBox.Text);
                decimal insurance = decimal.Parse(textBoxInsurance.Text);
                decimal gas = decimal.Parse(textBoxGas.Text);
                decimal oil = decimal.Parse(textBoxOil.Text);
                decimal tires = decimal.Parse(textBoxTires.Text);
                decimal maintenance = decimal.Parse(textBoxMaintenance.Text);

                decimal monthlyTotal = loanPayment + insurance +
                    gas + oil + tires + maintenance;

                decimal annualTotal = monthlyTotal * 12;

                labelMonthlyTotal.Text = monthlyTotal.ToString("c");
                labelAnnualTotal.Text = annualTotal.ToString("c");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void resetButton_Click(object sender, EventArgs e)
        {
            loanPaymentTextBox.Text = "0";
            textBoxInsurance.Text = "0";
            textBoxGas.Text = "0";
            textBoxOil.Text = "0";
            textBoxTires.Text = "0";
            textBoxMaintenance.Text = "0";
            labelMonthlyTotal.Text = "0";
            labelAnnualTotal.Text = "0";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
