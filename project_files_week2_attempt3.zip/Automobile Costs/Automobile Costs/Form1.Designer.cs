﻿namespace Automobile_Costs
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.loanPaymentTextBox = new System.Windows.Forms.TextBox();
            this.textBoxInsurance = new System.Windows.Forms.TextBox();
            this.textBoxGas = new System.Windows.Forms.TextBox();
            this.textBoxOil = new System.Windows.Forms.TextBox();
            this.textBoxTires = new System.Windows.Forms.TextBox();
            this.textBoxMaintenance = new System.Windows.Forms.TextBox();
            this.resetButton = new System.Windows.Forms.Button();
            this.calculateButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.labelMonthlyTotal = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.labelAnnualTotal = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(111, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Loan Payment";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(41, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Insurance";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(82, 108);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Gas";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(94, 154);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(27, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Oil";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(78, 200);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "Tires";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(20, 251);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(101, 20);
            this.label6.TabIndex = 5;
            this.label6.Text = "Maintenance";
            // 
            // loanPaymentTextBox
            // 
            this.loanPaymentTextBox.Location = new System.Drawing.Point(127, 19);
            this.loanPaymentTextBox.Name = "loanPaymentTextBox";
            this.loanPaymentTextBox.Size = new System.Drawing.Size(100, 26);
            this.loanPaymentTextBox.TabIndex = 6;
            this.loanPaymentTextBox.Text = "0";
            // 
            // textBoxInsurance
            // 
            this.textBoxInsurance.Location = new System.Drawing.Point(127, 63);
            this.textBoxInsurance.Name = "textBoxInsurance";
            this.textBoxInsurance.Size = new System.Drawing.Size(100, 26);
            this.textBoxInsurance.TabIndex = 7;
            this.textBoxInsurance.Text = "0";
            // 
            // textBoxGas
            // 
            this.textBoxGas.Location = new System.Drawing.Point(127, 102);
            this.textBoxGas.Name = "textBoxGas";
            this.textBoxGas.Size = new System.Drawing.Size(100, 26);
            this.textBoxGas.TabIndex = 8;
            this.textBoxGas.Text = "0";
            // 
            // textBoxOil
            // 
            this.textBoxOil.Location = new System.Drawing.Point(127, 148);
            this.textBoxOil.Name = "textBoxOil";
            this.textBoxOil.Size = new System.Drawing.Size(100, 26);
            this.textBoxOil.TabIndex = 9;
            this.textBoxOil.Text = "0";
            // 
            // textBoxTires
            // 
            this.textBoxTires.Location = new System.Drawing.Point(127, 194);
            this.textBoxTires.Name = "textBoxTires";
            this.textBoxTires.Size = new System.Drawing.Size(100, 26);
            this.textBoxTires.TabIndex = 10;
            this.textBoxTires.Text = "0";
            // 
            // textBoxMaintenance
            // 
            this.textBoxMaintenance.Location = new System.Drawing.Point(127, 248);
            this.textBoxMaintenance.Name = "textBoxMaintenance";
            this.textBoxMaintenance.Size = new System.Drawing.Size(100, 26);
            this.textBoxMaintenance.TabIndex = 11;
            this.textBoxMaintenance.Text = "0";
            // 
            // resetButton
            // 
            this.resetButton.Location = new System.Drawing.Point(360, 190);
            this.resetButton.Name = "resetButton";
            this.resetButton.Size = new System.Drawing.Size(95, 35);
            this.resetButton.TabIndex = 12;
            this.resetButton.Text = "Reset";
            this.resetButton.UseVisualStyleBackColor = true;
            this.resetButton.Click += new System.EventHandler(this.resetButton_Click);
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(360, 145);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(95, 35);
            this.calculateButton.TabIndex = 13;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.exitButton.Location = new System.Drawing.Point(360, 236);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(95, 35);
            this.exitButton.TabIndex = 14;
            this.exitButton.Text = "&Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(240, 24);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(103, 20);
            this.label7.TabIndex = 15;
            this.label7.Text = "Monthly Total";
            // 
            // labelMonthlyTotal
            // 
            this.labelMonthlyTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelMonthlyTotal.Location = new System.Drawing.Point(355, 24);
            this.labelMonthlyTotal.Name = "labelMonthlyTotal";
            this.labelMonthlyTotal.Size = new System.Drawing.Size(100, 23);
            this.labelMonthlyTotal.TabIndex = 16;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(245, 79);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(98, 20);
            this.label9.TabIndex = 17;
            this.label9.Text = "Annual Total";
            // 
            // labelAnnualTotal
            // 
            this.labelAnnualTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelAnnualTotal.Location = new System.Drawing.Point(355, 78);
            this.labelAnnualTotal.Name = "labelAnnualTotal";
            this.labelAnnualTotal.Size = new System.Drawing.Size(100, 23);
            this.labelAnnualTotal.TabIndex = 18;
            // 
            // Form1
            // 
            this.AcceptButton = this.calculateButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.exitButton;
            this.ClientSize = new System.Drawing.Size(486, 288);
            this.Controls.Add(this.labelAnnualTotal);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.labelMonthlyTotal);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.resetButton);
            this.Controls.Add(this.textBoxMaintenance);
            this.Controls.Add(this.textBoxTires);
            this.Controls.Add(this.textBoxOil);
            this.Controls.Add(this.textBoxGas);
            this.Controls.Add(this.textBoxInsurance);
            this.Controls.Add(this.loanPaymentTextBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Automobile Costs";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox loanPaymentTextBox;
        private System.Windows.Forms.TextBox textBoxInsurance;
        private System.Windows.Forms.TextBox textBoxGas;
        private System.Windows.Forms.TextBox textBoxOil;
        private System.Windows.Forms.TextBox textBoxTires;
        private System.Windows.Forms.TextBox textBoxMaintenance;
        private System.Windows.Forms.Button resetButton;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label labelMonthlyTotal;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label labelAnnualTotal;
    }
}

