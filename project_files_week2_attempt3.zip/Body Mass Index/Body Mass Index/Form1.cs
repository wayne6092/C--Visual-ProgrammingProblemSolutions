﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Body_Mass_Index
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            double weight;
            double height;
            double bmi;

            try
            {
                weight = double.Parse(weightTextBox.Text);
                height = double.Parse(heightTextBox.Text);

                bmi = (weight * 703) / (height * height);
                bmiLabel.Text = bmi.ToString("n1");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            weightTextBox.Text = "";
            heightTextBox.Text = "";
            bmiLabel.Text = "";
        }

        private void quitButton_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
