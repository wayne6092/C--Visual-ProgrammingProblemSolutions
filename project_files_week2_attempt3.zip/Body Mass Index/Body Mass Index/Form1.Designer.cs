﻿namespace Body_Mass_Index
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.weightTitleLabel = new System.Windows.Forms.Label();
            this.heightTitleLabel = new System.Windows.Forms.Label();
            this.BmiTitleLabel = new System.Windows.Forms.Label();
            this.bmiLabel = new System.Windows.Forms.Label();
            this.weightTextBox = new System.Windows.Forms.TextBox();
            this.heightTextBox = new System.Windows.Forms.TextBox();
            this.quitButton = new System.Windows.Forms.Button();
            this.calculateButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // weightTitleLabel
            // 
            this.weightTitleLabel.AutoSize = true;
            this.weightTitleLabel.Location = new System.Drawing.Point(81, 27);
            this.weightTitleLabel.Name = "weightTitleLabel";
            this.weightTitleLabel.Size = new System.Drawing.Size(99, 20);
            this.weightTitleLabel.TabIndex = 8;
            this.weightTitleLabel.Text = "Weight (Lbs)";
            // 
            // heightTitleLabel
            // 
            this.heightTitleLabel.AutoSize = true;
            this.heightTitleLabel.Location = new System.Drawing.Point(62, 74);
            this.heightTitleLabel.Name = "heightTitleLabel";
            this.heightTitleLabel.Size = new System.Drawing.Size(118, 20);
            this.heightTitleLabel.TabIndex = 7;
            this.heightTitleLabel.Text = "Height (Inches)";
            // 
            // BmiTitleLabel
            // 
            this.BmiTitleLabel.AutoSize = true;
            this.BmiTitleLabel.Location = new System.Drawing.Point(7, 122);
            this.BmiTitleLabel.Name = "BmiTitleLabel";
            this.BmiTitleLabel.Size = new System.Drawing.Size(173, 20);
            this.BmiTitleLabel.TabIndex = 6;
            this.BmiTitleLabel.Text = "BMI (Body Mass Index)";
            // 
            // bmiLabel
            // 
            this.bmiLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.bmiLabel.Location = new System.Drawing.Point(186, 122);
            this.bmiLabel.Name = "bmiLabel";
            this.bmiLabel.Size = new System.Drawing.Size(100, 23);
            this.bmiLabel.TabIndex = 5;
            // 
            // weightTextBox
            // 
            this.weightTextBox.Location = new System.Drawing.Point(186, 21);
            this.weightTextBox.Name = "weightTextBox";
            this.weightTextBox.Size = new System.Drawing.Size(100, 26);
            this.weightTextBox.TabIndex = 0;
            // 
            // heightTextBox
            // 
            this.heightTextBox.Location = new System.Drawing.Point(186, 70);
            this.heightTextBox.Name = "heightTextBox";
            this.heightTextBox.Size = new System.Drawing.Size(100, 26);
            this.heightTextBox.TabIndex = 1;
            // 
            // quitButton
            // 
            this.quitButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.quitButton.Location = new System.Drawing.Point(12, 179);
            this.quitButton.Name = "quitButton";
            this.quitButton.Size = new System.Drawing.Size(86, 36);
            this.quitButton.TabIndex = 4;
            this.quitButton.Text = "&Quit";
            this.quitButton.UseVisualStyleBackColor = true;
            this.quitButton.Click += new System.EventHandler(this.quitButton_Click);
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(197, 179);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(100, 36);
            this.calculateButton.TabIndex = 2;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(105, 179);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(86, 36);
            this.clearButton.TabIndex = 3;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // Form1
            // 
            this.AcceptButton = this.calculateButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.quitButton;
            this.ClientSize = new System.Drawing.Size(363, 248);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.quitButton);
            this.Controls.Add(this.heightTextBox);
            this.Controls.Add(this.weightTextBox);
            this.Controls.Add(this.bmiLabel);
            this.Controls.Add(this.BmiTitleLabel);
            this.Controls.Add(this.heightTitleLabel);
            this.Controls.Add(this.weightTitleLabel);
            this.Name = "Form1";
            this.Text = "BMI Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label weightTitleLabel;
        private System.Windows.Forms.Label heightTitleLabel;
        private System.Windows.Forms.Label BmiTitleLabel;
        private System.Windows.Forms.Label bmiLabel;
        private System.Windows.Forms.TextBox weightTextBox;
        private System.Windows.Forms.TextBox heightTextBox;
        private System.Windows.Forms.Button quitButton;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Button clearButton;
    }
}

