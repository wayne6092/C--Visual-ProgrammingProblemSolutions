﻿namespace Name_Format_Program
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.firstNameTextBox = new System.Windows.Forms.TextBox();
            this.lastNameTextBox = new System.Windows.Forms.TextBox();
            this.middleNameTextBox = new System.Windows.Forms.TextBox();
            this.sirNameTextBox = new System.Windows.Forms.TextBox();
            this.PrefFnMLn = new System.Windows.Forms.Button();
            this.FnMLn = new System.Windows.Forms.Button();
            this.LnFnMPref = new System.Windows.Forms.Button();
            this.FnLn = new System.Windows.Forms.Button();
            this.LnFnM = new System.Windows.Forms.Button();
            this.LnFn = new System.Windows.Forms.Button();
            this.firstNameLabel = new System.Windows.Forms.Label();
            this.middleNameLabel = new System.Windows.Forms.Label();
            this.lastNameLabel = new System.Windows.Forms.Label();
            this.sirNameLabel = new System.Windows.Forms.Label();
            this.formattedNameLabel = new System.Windows.Forms.Label();
            this.formattedNameTitleLabel = new System.Windows.Forms.Label();
            this.quit = new System.Windows.Forms.Button();
            this.buttonClear = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // firstNameTextBox
            // 
            this.firstNameTextBox.Location = new System.Drawing.Point(124, 39);
            this.firstNameTextBox.Name = "firstNameTextBox";
            this.firstNameTextBox.Size = new System.Drawing.Size(100, 26);
            this.firstNameTextBox.TabIndex = 0;
            // 
            // lastNameTextBox
            // 
            this.lastNameTextBox.Location = new System.Drawing.Point(124, 188);
            this.lastNameTextBox.Name = "lastNameTextBox";
            this.lastNameTextBox.Size = new System.Drawing.Size(100, 26);
            this.lastNameTextBox.TabIndex = 2;
            // 
            // middleNameTextBox
            // 
            this.middleNameTextBox.Location = new System.Drawing.Point(124, 113);
            this.middleNameTextBox.Name = "middleNameTextBox";
            this.middleNameTextBox.Size = new System.Drawing.Size(100, 26);
            this.middleNameTextBox.TabIndex = 1;
            // 
            // sirNameTextBox
            // 
            this.sirNameTextBox.Location = new System.Drawing.Point(124, 271);
            this.sirNameTextBox.Name = "sirNameTextBox";
            this.sirNameTextBox.Size = new System.Drawing.Size(100, 26);
            this.sirNameTextBox.TabIndex = 3;
            // 
            // PrefFnMLn
            // 
            this.PrefFnMLn.Location = new System.Drawing.Point(301, 99);
            this.PrefFnMLn.Name = "PrefFnMLn";
            this.PrefFnMLn.Size = new System.Drawing.Size(95, 59);
            this.PrefFnMLn.TabIndex = 4;
            this.PrefFnMLn.Text = "Pref. Fn M Ln";
            this.PrefFnMLn.UseVisualStyleBackColor = true;
            this.PrefFnMLn.Click += new System.EventHandler(this.PrefFnMLn_Click);
            // 
            // FnMLn
            // 
            this.FnMLn.Location = new System.Drawing.Point(301, 173);
            this.FnMLn.Name = "FnMLn";
            this.FnMLn.Size = new System.Drawing.Size(95, 56);
            this.FnMLn.TabIndex = 6;
            this.FnMLn.Text = "Fn M Ln";
            this.FnMLn.UseVisualStyleBackColor = true;
            this.FnMLn.Click += new System.EventHandler(this.FnMLn_Click);
            // 
            // LnFnMPref
            // 
            this.LnFnMPref.Location = new System.Drawing.Point(422, 99);
            this.LnFnMPref.Name = "LnFnMPref";
            this.LnFnMPref.Size = new System.Drawing.Size(102, 59);
            this.LnFnMPref.TabIndex = 5;
            this.LnFnMPref.Text = "Ln, Fn M, Pref.";
            this.LnFnMPref.UseVisualStyleBackColor = true;
            this.LnFnMPref.Click += new System.EventHandler(this.LnFnMPref_Click);
            // 
            // FnLn
            // 
            this.FnLn.Location = new System.Drawing.Point(301, 245);
            this.FnLn.Name = "FnLn";
            this.FnLn.Size = new System.Drawing.Size(95, 54);
            this.FnLn.TabIndex = 8;
            this.FnLn.Text = "Fn Ln";
            this.FnLn.UseVisualStyleBackColor = true;
            this.FnLn.Click += new System.EventHandler(this.FnLn_Click);
            // 
            // LnFnM
            // 
            this.LnFnM.Location = new System.Drawing.Point(422, 173);
            this.LnFnM.Name = "LnFnM";
            this.LnFnM.Size = new System.Drawing.Size(102, 56);
            this.LnFnM.TabIndex = 7;
            this.LnFnM.Text = "Ln, Fn M";
            this.LnFnM.UseVisualStyleBackColor = true;
            this.LnFnM.Click += new System.EventHandler(this.LnFnM_Click);
            // 
            // LnFn
            // 
            this.LnFn.Location = new System.Drawing.Point(422, 245);
            this.LnFn.Name = "LnFn";
            this.LnFn.Size = new System.Drawing.Size(102, 54);
            this.LnFn.TabIndex = 9;
            this.LnFn.Text = "Ln, Fn";
            this.LnFn.UseVisualStyleBackColor = true;
            this.LnFn.Click += new System.EventHandler(this.LnFn_Click);
            // 
            // firstNameLabel
            // 
            this.firstNameLabel.AutoSize = true;
            this.firstNameLabel.Location = new System.Drawing.Point(18, 42);
            this.firstNameLabel.Name = "firstNameLabel";
            this.firstNameLabel.Size = new System.Drawing.Size(86, 20);
            this.firstNameLabel.TabIndex = 10;
            this.firstNameLabel.Text = "First Name";
            // 
            // middleNameLabel
            // 
            this.middleNameLabel.AutoSize = true;
            this.middleNameLabel.Location = new System.Drawing.Point(49, 119);
            this.middleNameLabel.Name = "middleNameLabel";
            this.middleNameLabel.Size = new System.Drawing.Size(55, 20);
            this.middleNameLabel.TabIndex = 11;
            this.middleNameLabel.Text = "Middle";
            // 
            // lastNameLabel
            // 
            this.lastNameLabel.AutoSize = true;
            this.lastNameLabel.Location = new System.Drawing.Point(18, 191);
            this.lastNameLabel.Name = "lastNameLabel";
            this.lastNameLabel.Size = new System.Drawing.Size(86, 20);
            this.lastNameLabel.TabIndex = 12;
            this.lastNameLabel.Text = "Last Name";
            // 
            // sirNameLabel
            // 
            this.sirNameLabel.AutoSize = true;
            this.sirNameLabel.Location = new System.Drawing.Point(30, 274);
            this.sirNameLabel.Name = "sirNameLabel";
            this.sirNameLabel.Size = new System.Drawing.Size(74, 20);
            this.sirNameLabel.TabIndex = 13;
            this.sirNameLabel.Text = "Sir Name";
            // 
            // formattedNameLabel
            // 
            this.formattedNameLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.formattedNameLabel.Location = new System.Drawing.Point(301, 39);
            this.formattedNameLabel.Name = "formattedNameLabel";
            this.formattedNameLabel.Size = new System.Drawing.Size(223, 46);
            this.formattedNameLabel.TabIndex = 13;
            // 
            // formattedNameTitleLabel
            // 
            this.formattedNameTitleLabel.AutoSize = true;
            this.formattedNameTitleLabel.Location = new System.Drawing.Point(346, 0);
            this.formattedNameTitleLabel.Name = "formattedNameTitleLabel";
            this.formattedNameTitleLabel.Size = new System.Drawing.Size(129, 20);
            this.formattedNameTitleLabel.TabIndex = 12;
            this.formattedNameTitleLabel.Text = "Formatted Name";
            // 
            // quit
            // 
            this.quit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.quit.Location = new System.Drawing.Point(416, 315);
            this.quit.Name = "quit";
            this.quit.Size = new System.Drawing.Size(107, 37);
            this.quit.TabIndex = 11;
            this.quit.Text = "&Quit App";
            this.quit.UseVisualStyleBackColor = true;
            this.quit.Click += new System.EventHandler(this.quit_Click);
            // 
            // buttonClear
            // 
            this.buttonClear.Location = new System.Drawing.Point(301, 315);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(79, 37);
            this.buttonClear.TabIndex = 16;
            this.buttonClear.Text = "Clear";
            this.buttonClear.UseVisualStyleBackColor = true;
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // Form1
            // 
            this.AcceptButton = this.buttonClear;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.quit;
            this.ClientSize = new System.Drawing.Size(535, 364);
            this.Controls.Add(this.buttonClear);
            this.Controls.Add(this.quit);
            this.Controls.Add(this.formattedNameTitleLabel);
            this.Controls.Add(this.formattedNameLabel);
            this.Controls.Add(this.sirNameLabel);
            this.Controls.Add(this.lastNameLabel);
            this.Controls.Add(this.middleNameLabel);
            this.Controls.Add(this.firstNameLabel);
            this.Controls.Add(this.LnFn);
            this.Controls.Add(this.LnFnM);
            this.Controls.Add(this.FnLn);
            this.Controls.Add(this.LnFnMPref);
            this.Controls.Add(this.FnMLn);
            this.Controls.Add(this.PrefFnMLn);
            this.Controls.Add(this.sirNameTextBox);
            this.Controls.Add(this.middleNameTextBox);
            this.Controls.Add(this.lastNameTextBox);
            this.Controls.Add(this.firstNameTextBox);
            this.Name = "Form1";
            this.Text = "Name Formatter";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox firstNameTextBox;
        private System.Windows.Forms.TextBox lastNameTextBox;
        private System.Windows.Forms.TextBox middleNameTextBox;
        private System.Windows.Forms.TextBox sirNameTextBox;
        private System.Windows.Forms.Button PrefFnMLn;
        private System.Windows.Forms.Button FnMLn;
        private System.Windows.Forms.Button LnFnMPref;
        private System.Windows.Forms.Button FnLn;
        private System.Windows.Forms.Button LnFnM;
        private System.Windows.Forms.Button LnFn;
        private System.Windows.Forms.Label firstNameLabel;
        private System.Windows.Forms.Label middleNameLabel;
        private System.Windows.Forms.Label lastNameLabel;
        private System.Windows.Forms.Label sirNameLabel;
        private System.Windows.Forms.Label formattedNameLabel;
        private System.Windows.Forms.Label formattedNameTitleLabel;
        private System.Windows.Forms.Button quit;
        private System.Windows.Forms.Button buttonClear;
    }
}

