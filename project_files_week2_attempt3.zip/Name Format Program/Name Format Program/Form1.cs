﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Name_Format_Program
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
        }

        private void PrefFnMLn_Click(object sender, EventArgs e)
        {
            
            string sirName = sirNameTextBox.Text;
            string firstName = firstNameTextBox.Text;
            string middle = middleNameTextBox.Text;
            string lastName = lastNameTextBox.Text;

            string output = sirName + " " + firstName
                + " " + middle + " " + lastName;

            try
            {
                formattedNameLabel.Text = output;
                //Concatenate the input
            }
            catch (Exception ex)
            {
                formattedNameLabel.Text = ex.Message;
            }
        }

        private void FnMLn_Click(object sender, EventArgs e)
        {
            string lastName = lastNameTextBox.Text;
            string firstName = firstNameTextBox.Text;
            string middle = middleNameTextBox.Text;

            string output = firstName
                + " " + middle + " " + lastName;

            formattedNameLabel.Text = output;
        }

        private void FnLn_Click(object sender, EventArgs e)
        {
            string lastName = lastNameTextBox.Text;
            string firstName = firstNameTextBox.Text;

            string output = firstName + " " + lastName;

            try
            {
                formattedNameLabel.Text = output;
                //Concatenate the input
            }
            catch (Exception ex)
            {
                formattedNameLabel.Text = ex.Message;
            }
        }

        private void LnFnMPref_Click(object sender, EventArgs e)
        {
            string sirName = sirNameTextBox.Text;
            string firstName = firstNameTextBox.Text;
            string middle = middleNameTextBox.Text;
            string lastName = lastNameTextBox.Text;

            string output = lastName + ", " + firstName
                + " " + middle + ", " + sirName;

            try
            {
                formattedNameLabel.Text = output;
                //Concatenate the input
            }
            catch (Exception ex)
            {
                formattedNameLabel.Text = ex.Message;
            }
        }

        private void LnFnM_Click(object sender, EventArgs e)
        {
            string lastName = lastNameTextBox.Text;
            string firstName = firstNameTextBox.Text;
            string middle = middleNameTextBox.Text;

            string output = lastName
                + ", " + firstName + " " + middle;

            try
            {
                formattedNameLabel.Text = output;
                //Concatenate the input
            }
            catch (Exception ex)
            {
                formattedNameLabel.Text = ex.Message;
            }
        }

        private void LnFn_Click(object sender, EventArgs e)
        {
            string lastName = lastNameTextBox.Text;
            string firstName = firstNameTextBox.Text;

            string output = lastName + " " + firstName;

            try
            {
                formattedNameLabel.Text = output;
                //Concatenate the input
            }
            catch (Exception ex)
            {
                formattedNameLabel.Text = ex.Message;
            }
        }

        private void quit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            lastNameTextBox.Text = "";
            middleNameTextBox.Text = "";
            firstNameTextBox.Text = "";
            sirNameTextBox.Text = "";
            formattedNameLabel.Text = "";
        }
    }
}
