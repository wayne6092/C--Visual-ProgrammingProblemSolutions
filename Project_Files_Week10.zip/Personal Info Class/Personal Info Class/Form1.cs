﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Personal_Info_Class
{
    public partial class Form1 : Form
    {
        private PersonalInfo myself = new PersonalInfo("Wayne Williams Jr", "15154 Island Drive, Sterling Heights", 26, "586-525-5080");
        private PersonalInfo girlFriend = new PersonalInfo("Alyssa Kanan", "15154 Island Drive, Sterling Heights", 26, "586-251-8179");
        private PersonalInfo father = new PersonalInfo("Wayne Williams Sr", "15154 Island Drive, Sterling Heights", 60, "586-525-5080");
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Display first object
            labelName.Text = myself.Name;
            labelAddress.Text = myself.Address;
            labelAge.Text = myself.Age.ToString();
            labelPhone.Text = myself.PhoneNumber;

            //Display second object
            labelNameTwo.Text = girlFriend.Name;
            labelAddressTwo.Text = girlFriend.Address;
            labelAgeTwo.Text = girlFriend.Age.ToString();
            labelPhoneTwo.Text = girlFriend.PhoneNumber;

            //Display third object
            labelNameThree.Text = father.Name;
            labelAddressThree.Text = father.Address;
            labelAgeThree.Text = father.Age.ToString();
            labelPhoneThree.Text = father.PhoneNumber;
        }
    }
}
