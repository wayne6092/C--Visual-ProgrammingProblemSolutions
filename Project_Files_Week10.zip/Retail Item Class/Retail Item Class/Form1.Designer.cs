﻿namespace Retail_Item_Class
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonExit = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.labelDesc = new System.Windows.Forms.Label();
            this.labelUnits = new System.Windows.Forms.Label();
            this.labelPrice = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.labelPriceTwo = new System.Windows.Forms.Label();
            this.labelDescTwo = new System.Windows.Forms.Label();
            this.labelUnitsTwo = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.labelPriceThree = new System.Windows.Forms.Label();
            this.labelDescThree = new System.Windows.Forms.Label();
            this.labelUnitsThree = new System.Windows.Forms.Label();
            this.listBoxShowObject = new System.Windows.Forms.ListBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonExit
            // 
            this.buttonExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonExit.Location = new System.Drawing.Point(399, 275);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(290, 42);
            this.buttonExit.TabIndex = 0;
            this.buttonExit.Text = "&Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(36, 70);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Units On Hand";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(61, 29);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Description";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(106, 115);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 20);
            this.label3.TabIndex = 3;
            this.label3.Text = "Price";
            // 
            // labelDesc
            // 
            this.labelDesc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelDesc.Location = new System.Drawing.Point(177, 29);
            this.labelDesc.Name = "labelDesc";
            this.labelDesc.Size = new System.Drawing.Size(143, 23);
            this.labelDesc.TabIndex = 4;
            this.labelDesc.Text = " ";
            // 
            // labelUnits
            // 
            this.labelUnits.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelUnits.Location = new System.Drawing.Point(177, 70);
            this.labelUnits.Name = "labelUnits";
            this.labelUnits.Size = new System.Drawing.Size(143, 23);
            this.labelUnits.TabIndex = 5;
            this.labelUnits.Text = " ";
            // 
            // labelPrice
            // 
            this.labelPrice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelPrice.Location = new System.Drawing.Point(177, 115);
            this.labelPrice.Name = "labelPrice";
            this.labelPrice.Size = new System.Drawing.Size(143, 23);
            this.labelPrice.TabIndex = 6;
            this.labelPrice.Text = "$0.00";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.labelUnits);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.labelDesc);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.labelPrice);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(357, 159);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Item #1";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.labelPriceTwo);
            this.groupBox2.Controls.Add(this.labelDescTwo);
            this.groupBox2.Controls.Add(this.labelUnitsTwo);
            this.groupBox2.Location = new System.Drawing.Point(12, 177);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(357, 159);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Item #2";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.labelPriceThree);
            this.groupBox3.Controls.Add(this.labelDescThree);
            this.groupBox3.Controls.Add(this.labelUnitsThree);
            this.groupBox3.Location = new System.Drawing.Point(12, 342);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(357, 159);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Item #3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(61, 31);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 20);
            this.label4.TabIndex = 8;
            this.label4.Text = "Description";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(36, 72);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(114, 20);
            this.label5.TabIndex = 7;
            this.label5.Text = "Units On Hand";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(106, 117);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 20);
            this.label6.TabIndex = 9;
            this.label6.Text = "Price";
            // 
            // labelPriceTwo
            // 
            this.labelPriceTwo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelPriceTwo.Location = new System.Drawing.Point(177, 117);
            this.labelPriceTwo.Name = "labelPriceTwo";
            this.labelPriceTwo.Size = new System.Drawing.Size(143, 23);
            this.labelPriceTwo.TabIndex = 12;
            this.labelPriceTwo.Text = "$0.00";
            // 
            // labelDescTwo
            // 
            this.labelDescTwo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelDescTwo.Location = new System.Drawing.Point(177, 31);
            this.labelDescTwo.Name = "labelDescTwo";
            this.labelDescTwo.Size = new System.Drawing.Size(143, 23);
            this.labelDescTwo.TabIndex = 10;
            this.labelDescTwo.Text = " ";
            // 
            // labelUnitsTwo
            // 
            this.labelUnitsTwo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelUnitsTwo.Location = new System.Drawing.Point(177, 72);
            this.labelUnitsTwo.Name = "labelUnitsTwo";
            this.labelUnitsTwo.Size = new System.Drawing.Size(143, 23);
            this.labelUnitsTwo.TabIndex = 11;
            this.labelUnitsTwo.Text = " ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(61, 32);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(89, 20);
            this.label10.TabIndex = 8;
            this.label10.Text = "Description";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(36, 73);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(114, 20);
            this.label11.TabIndex = 7;
            this.label11.Text = "Units On Hand";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(106, 118);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(44, 20);
            this.label12.TabIndex = 9;
            this.label12.Text = "Price";
            // 
            // labelPriceThree
            // 
            this.labelPriceThree.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelPriceThree.Location = new System.Drawing.Point(177, 118);
            this.labelPriceThree.Name = "labelPriceThree";
            this.labelPriceThree.Size = new System.Drawing.Size(143, 23);
            this.labelPriceThree.TabIndex = 12;
            this.labelPriceThree.Text = "$0.00";
            // 
            // labelDescThree
            // 
            this.labelDescThree.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelDescThree.Location = new System.Drawing.Point(177, 32);
            this.labelDescThree.Name = "labelDescThree";
            this.labelDescThree.Size = new System.Drawing.Size(143, 23);
            this.labelDescThree.TabIndex = 10;
            this.labelDescThree.Text = " ";
            // 
            // labelUnitsThree
            // 
            this.labelUnitsThree.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelUnitsThree.Location = new System.Drawing.Point(177, 73);
            this.labelUnitsThree.Name = "labelUnitsThree";
            this.labelUnitsThree.Size = new System.Drawing.Size(143, 23);
            this.labelUnitsThree.TabIndex = 11;
            this.labelUnitsThree.Text = " ";
            // 
            // listBoxShowObject
            // 
            this.listBoxShowObject.FormattingEnabled = true;
            this.listBoxShowObject.ItemHeight = 20;
            this.listBoxShowObject.Location = new System.Drawing.Point(399, 12);
            this.listBoxShowObject.Name = "listBoxShowObject";
            this.listBoxShowObject.Size = new System.Drawing.Size(290, 244);
            this.listBoxShowObject.TabIndex = 8;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.buttonExit;
            this.ClientSize = new System.Drawing.Size(715, 519);
            this.Controls.Add(this.listBoxShowObject);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.buttonExit);
            this.Name = "Form1";
            this.Text = "Retail Item Class";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label labelDesc;
        private System.Windows.Forms.Label labelUnits;
        private System.Windows.Forms.Label labelPrice;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label labelPriceTwo;
        private System.Windows.Forms.Label labelDescTwo;
        private System.Windows.Forms.Label labelUnitsTwo;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label labelPriceThree;
        private System.Windows.Forms.Label labelDescThree;
        private System.Windows.Forms.Label labelUnitsThree;
        private System.Windows.Forms.ListBox listBoxShowObject;
    }
}

