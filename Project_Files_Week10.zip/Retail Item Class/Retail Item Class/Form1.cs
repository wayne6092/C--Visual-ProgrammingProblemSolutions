﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Retail_Item_Class
{
    public partial class Form1 : Form
    {



        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            RetailItem[] retailItem =
            {
                new RetailItem("Jacket", 12, 59.95m),
                new RetailItem("Jeans", 40, 34.95m),
                new RetailItem("Shirt", 20, 24.95m)
            };

            for (int index = 0; index < retailItem.Length; index++)
            {
                //If statements for adding to labels
                if (index == 0)
                {
                    labelDesc.Text = retailItem[index].Description;
                    labelUnits.Text = retailItem[index].UnitsOnHand.ToString();
                    labelPrice.Text = retailItem[index].Price.ToString("c");
                }
                else if (index == 1)
                {
                    labelDescTwo.Text = retailItem[index].Description;
                    labelUnitsTwo.Text = retailItem[index].UnitsOnHand.ToString();
                    labelPriceTwo.Text = retailItem[index].Price.ToString("c");
                }
                else
                {
                    labelDescThree.Text = retailItem[index].Description;
                    labelUnitsThree.Text = retailItem[index].UnitsOnHand.ToString();
                    labelPriceThree.Text = retailItem[index].Price.ToString("c");
                }

                //Just Add to ListBox
                listBoxShowObject.Items.Add("Item: #" + (index + 1).ToString());
                listBoxShowObject.Items.Add("Description: " + retailItem[index].Description);
                listBoxShowObject.Items.Add("Units On Hand: " + retailItem[index].UnitsOnHand.ToString());
                listBoxShowObject.Items.Add("Price: " + retailItem[index].Price.ToString("c"));
                listBoxShowObject.Items.Add("");

                //Using a message box to show objects
                MessageBox.Show("Item: #" + (index + 1).ToString() +
                    ". Description: " + retailItem[index].Description + 
                    ". Units On Hand: " + retailItem[index].UnitsOnHand.ToString() +
                    ". Price: " + retailItem[index].Price.ToString("c"));
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

