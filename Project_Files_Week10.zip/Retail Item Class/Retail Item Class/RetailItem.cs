﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Retail_Item_Class
{
    class RetailItem
    {
        private string _description;
        private int _unitsOnHand;
        private decimal _price;
    
        //Constructor
        public RetailItem(string description, int unitsOnHand, decimal price)
        {
            _description = description;
            _unitsOnHand = unitsOnHand;
            _price = price;
        }


        //Name property
        public string Description
        {
            get { return _description; }
            set { _description = value; }
        }

        //Adress property
        public int UnitsOnHand
        {
            get { return _unitsOnHand; }
            set { _unitsOnHand = value; }
        }

        //Age property
        public decimal Price
        {
            get { return _price; }
            set { _price = value; }
        }
    }
}
