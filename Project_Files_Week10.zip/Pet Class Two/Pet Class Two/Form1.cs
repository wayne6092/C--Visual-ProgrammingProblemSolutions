﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pet_Class_Two
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            //Create instance of pet class
            Pet myPet = new Pet();

            //Get user input
            myPet.Name = textBoxName.Text;
            myPet.Type = textBoxType.Text;
            myPet.Age = int.Parse(textBoxAge.Text);

            //Retrieve objects properties
            labelName.Text = myPet.Name;
            labelType.Text = myPet.Type;
            labelAge.Text = myPet.Age.ToString();
        }

        private void buttonQuit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
