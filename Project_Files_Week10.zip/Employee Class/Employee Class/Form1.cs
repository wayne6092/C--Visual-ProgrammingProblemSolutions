﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Employee_Class
{
    public partial class Form1 : Form
    {
        private Employee susanMeyers = new Employee("Susan Meyers", 47899, "Accounting", "Vice President");
        private Employee markJones = new Employee("Mark Jones", 39119, "IT", "Programmer");
        private Employee joyRogers = new Employee("Joy Rogers", 81774, "Manufacturing", "Engineer");
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Display first object
            labelName.Text = susanMeyers.Name;
            labelIdNumber.Text = susanMeyers.IDNumber.ToString();
            labelDepartment.Text = susanMeyers.Department;
            labelPosition.Text = susanMeyers.Position;

            //Display second object
            labelNameTwo.Text = markJones.Name;
            labelIdNumberTwo.Text = markJones.IDNumber.ToString();
            labelDepartmentTwo.Text = markJones.Department;
            labelPositionTwo.Text = markJones.Position;

            //Display third object
            labelNameThree.Text = joyRogers.Name;
            labelIdNumberThree.Text = joyRogers.IDNumber.ToString();
            labelDepartmentThree.Text = joyRogers.Department;
            labelPositionThree.Text = joyRogers.Position;
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
