﻿namespace Car_Class
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonAccelerate = new System.Windows.Forms.Button();
            this.buttonBrake = new System.Windows.Forms.Button();
            this.labelSpeed = new System.Windows.Forms.Label();
            this.labelYear = new System.Windows.Forms.Label();
            this.labelMake = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.buttonQuit = new System.Windows.Forms.Button();
            this.buttonReset = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonAccelerate
            // 
            this.buttonAccelerate.Location = new System.Drawing.Point(18, 19);
            this.buttonAccelerate.Name = "buttonAccelerate";
            this.buttonAccelerate.Size = new System.Drawing.Size(123, 41);
            this.buttonAccelerate.TabIndex = 0;
            this.buttonAccelerate.Text = "Accelerate";
            this.buttonAccelerate.UseVisualStyleBackColor = true;
            this.buttonAccelerate.Click += new System.EventHandler(this.buttonAccelerate_Click);
            // 
            // buttonBrake
            // 
            this.buttonBrake.Location = new System.Drawing.Point(147, 19);
            this.buttonBrake.Name = "buttonBrake";
            this.buttonBrake.Size = new System.Drawing.Size(75, 41);
            this.buttonBrake.TabIndex = 1;
            this.buttonBrake.Text = "Brake";
            this.buttonBrake.UseVisualStyleBackColor = true;
            this.buttonBrake.Click += new System.EventHandler(this.buttonBrake_Click);
            // 
            // labelSpeed
            // 
            this.labelSpeed.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelSpeed.Location = new System.Drawing.Point(121, 103);
            this.labelSpeed.Name = "labelSpeed";
            this.labelSpeed.Size = new System.Drawing.Size(100, 23);
            this.labelSpeed.TabIndex = 2;
            this.labelSpeed.Text = " ";
            this.labelSpeed.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelYear
            // 
            this.labelYear.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelYear.Location = new System.Drawing.Point(121, 59);
            this.labelYear.Name = "labelYear";
            this.labelYear.Size = new System.Drawing.Size(100, 23);
            this.labelYear.TabIndex = 3;
            this.labelYear.Text = " ";
            this.labelYear.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelMake
            // 
            this.labelMake.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelMake.Location = new System.Drawing.Point(121, 24);
            this.labelMake.Name = "labelMake";
            this.labelMake.Size = new System.Drawing.Size(100, 23);
            this.labelMake.TabIndex = 4;
            this.labelMake.Text = " ";
            this.labelMake.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(29, 103);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 20);
            this.label4.TabIndex = 5;
            this.label4.Text = "Speed: ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(29, 59);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 20);
            this.label5.TabIndex = 6;
            this.label5.Text = "Year:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(29, 24);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 20);
            this.label6.TabIndex = 7;
            this.label6.Text = "Make:";
            // 
            // buttonQuit
            // 
            this.buttonQuit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonQuit.Location = new System.Drawing.Point(147, 75);
            this.buttonQuit.Name = "buttonQuit";
            this.buttonQuit.Size = new System.Drawing.Size(75, 55);
            this.buttonQuit.TabIndex = 3;
            this.buttonQuit.Text = "&Quit";
            this.buttonQuit.UseVisualStyleBackColor = true;
            this.buttonQuit.Click += new System.EventHandler(this.buttonQuit_Click);
            // 
            // buttonReset
            // 
            this.buttonReset.Location = new System.Drawing.Point(18, 75);
            this.buttonReset.Name = "buttonReset";
            this.buttonReset.Size = new System.Drawing.Size(123, 55);
            this.buttonReset.TabIndex = 2;
            this.buttonReset.Text = "Emergency Brake";
            this.buttonReset.UseVisualStyleBackColor = true;
            this.buttonReset.Click += new System.EventHandler(this.buttonReset_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.buttonQuit);
            this.panel1.Controls.Add(this.buttonAccelerate);
            this.panel1.Controls.Add(this.buttonReset);
            this.panel1.Controls.Add(this.buttonBrake);
            this.panel1.Location = new System.Drawing.Point(22, 175);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(245, 150);
            this.panel1.TabIndex = 10;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.labelSpeed);
            this.panel2.Controls.Add(this.labelYear);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.labelMake);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Location = new System.Drawing.Point(22, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(245, 157);
            this.panel2.TabIndex = 11;
            // 
            // Form1
            // 
            this.AcceptButton = this.buttonAccelerate;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.buttonQuit;
            this.ClientSize = new System.Drawing.Size(292, 340);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Car Class";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonAccelerate;
        private System.Windows.Forms.Button buttonBrake;
        private System.Windows.Forms.Label labelSpeed;
        private System.Windows.Forms.Label labelYear;
        private System.Windows.Forms.Label labelMake;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button buttonQuit;
        private System.Windows.Forms.Button buttonReset;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
    }
}

