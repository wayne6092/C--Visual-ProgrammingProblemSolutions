﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Car_Class
{
    public partial class Form1 : Form
    {
        //Create car
        private Car car1 = new Car("Nissan Altima", 0, 1999);

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            labelMake.Text = car1.Make;
            labelYear.Text = car1.Year.ToString();
            labelSpeed.Text = car1.Speed.ToString() + " MPH";
        }

        private void buttonAccelerate_Click(object sender, EventArgs e)
        {
            car1.Accelerate();
            labelSpeed.Text = car1.Speed.ToString() + " MPH";   
            MessageBox.Show("Speed increased by 5, Speed is now: " + car1.Speed.ToString());

        }

        private void buttonReset_Click(object sender, EventArgs e)
        {
            car1.EmergencyBrake();
            labelSpeed.Text = car1.Speed.ToString() + " MPH";
            MessageBox.Show("Car has been stopped manually: " + car1.Speed.ToString());
        }

        private void buttonBrake_Click(object sender, EventArgs e)
        {
            car1.Brake();
            labelSpeed.Text = car1.Speed.ToString() + " MPH";
            MessageBox.Show("Speed decreased by 5, Speed is now: " + car1.Speed.ToString());
        }

        private void buttonQuit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
