﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Team_Leader
{
    internal class TeamLeader : ProductionWorker
    {
        public decimal MonthlyBonusAmount { get; set; }
        public int NumberOfRequiredHours { get; set; }
        public int NumberOfHoursAttended { get; set; }
    }
}
