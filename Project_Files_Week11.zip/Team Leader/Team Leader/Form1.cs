﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Team_Leader
{
    public partial class Form1 : Form
    {
        TeamLeader tLeader = new TeamLeader();

        public Form1()
        {
            InitializeComponent();
        }

        private void buttonDisplay_Click(object sender, EventArgs e)
        {
            tLeader.Name = textBoxEmployeeName.Text;
            tLeader.Number = int.Parse(textBoxEmployeeNumber.Text);
            tLeader.HourlyRate = decimal.Parse(textBoxHourlyRate.Text);
            tLeader.MonthlyBonusAmount = decimal.Parse(textBoxMonthlyBonus.Text);
            tLeader.NumberOfHoursAttended = int.Parse(textBoxHoursAttended.Text);
            tLeader.NumberOfRequiredHours = int.Parse(textBoxHoursRequired.Text);

            try
            {
                if (radioButtonDayShift.Checked || radioButtonNightShift.Checked)
                {
                    if (tLeader.NumberOfHoursAttended >= tLeader.NumberOfRequiredHours)
                    {
                        labelResult.Text = "Employee Name: " + tLeader.Name + "\n" +
                            "Employee Number: " + tLeader.Number.ToString() + "\n" +
                            "Hourly Rate: " + tLeader.HourlyRate.ToString("c") + "\n" +
                            "Monthly Bonus Amount: " + tLeader.MonthlyBonusAmount.ToString("c") + "\n" +
                            "HOURS MET! Bonus will be added to total." + "\n" +
                            "Number of Hours Attended: " + tLeader.NumberOfHoursAttended.ToString() + "\n" +
                            "Number of Hours Required: " + tLeader.NumberOfRequiredHours.ToString() + "\n" +
                            "Shift Number: " + tLeader.ShiftNum.ToString() + "\n" +
                            "Total Earned From Training: " + (tLeader.HourlyRate * tLeader.NumberOfHoursAttended).ToString("c") + "\n" +
                            "Total Earned This Month: " + ((tLeader.HourlyRate * tLeader.NumberOfHoursAttended) + tLeader.MonthlyBonusAmount).ToString("c");
                    }
                    else
                    {
                        tLeader.MonthlyBonusAmount = 0.00m;
                        labelResult.Text = "Employee Name: " + tLeader.Name + "\n" +
                            "Employee Number: " + tLeader.Number.ToString() + "\n" +
                            "Hourly Rate: " + tLeader.HourlyRate.ToString("c") + "\n" +
                            "Monthly Bonus Amount: " + tLeader.MonthlyBonusAmount.ToString("c") + "\n" +
                            "HOURS NOT MET! Bonus will not be added to total." + "\n" +
                            "Number of Hours Attended: " + tLeader.NumberOfHoursAttended.ToString() + "\n" +
                            "Number of Hours Required: " + tLeader.NumberOfRequiredHours.ToString() + "\n" +
                            "Shift Number: " + tLeader.ShiftNum.ToString() + "\n" +
                            "Total Earned From Training This Month: " + (tLeader.HourlyRate * tLeader.NumberOfHoursAttended).ToString("c");

                    }
                    textBoxEmployeeName.Focus();
                }
                else
                {
                    MessageBox.Show("Please select a shift.");
                    radioButtonDayShift.Focus();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("Something went wrong: " + ex.Message);
            }
           
        }

        private void radioButtonDayShift_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonDayShift.Checked)
            {
                tLeader.ShiftNum = 1;
            }
        }

        private void radioButtonNightShift_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonNightShift.Checked)
            {
                tLeader.ShiftNum = 2;
            }
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBoxEmployeeName.Text = "";
            textBoxEmployeeNumber.Text = "0";
            textBoxHourlyRate.Text = "0.00";
            textBoxMonthlyBonus.Text = "0.00";
            textBoxHoursAttended.Text = "0.0";
            textBoxHoursRequired.Text = "0.0";
            textBoxEmployeeName.Focus();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
