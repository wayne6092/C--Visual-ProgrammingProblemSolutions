﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Preferred_Customer_Class
{
    public partial class Form1 : Form
    {
        PreferredCustomer pCustomer = new PreferredCustomer();

        public Form1()
        {
            InitializeComponent();
        }

        private void buttonDisplay_Click(object sender, EventArgs e)
        {
            try
            {
                pCustomer.Name = textBoxCustomerName.Text;
                pCustomer.Address = textBoxAddress.Text;
                pCustomer.PhoneNumber = textBoxPhoneNumber.Text;
                pCustomer.CustomerNumber = textBoxCustomerNumber.Text;
                //pCustomer.TotalAmountSpent = decimal.Parse(labelTotalSpent.Text);
                //pCustomer.DiscountLevel = decimal.Parse(labelDiscountLevel.Text);
                if (radioButtonNo.Checked || radioButtonYes.Checked)
                {
                    labelResult.Text = "Customer Name: " + pCustomer.Name + "\n" +
                    "Customer Address: " + pCustomer.Address + "\n" +
                    "Customer Phone Number: " + pCustomer.PhoneNumber + "\n" +
                    "Customer Number: " + pCustomer.CustomerNumber + "\n" +
                    "Mailing List: " + pCustomer.MailingList + "\n" +
                    "Total Amount Spent: " + pCustomer.TotalAmountSpent.ToString("c") + "\n" + 
                    "Discount Level: " + pCustomer.DiscountLevel.ToString("p") + "\n" + 
                    "Total Saved: " + pCustomer.TotalSaved.ToString("c");
                }
                else
                {
                    MessageBox.Show("Please click yes or no for mailing list.");
                }
                textBoxCustomerName.Focus();
            }
            catch(Exception ex)
            {
                MessageBox.Show("Something went wrong: " + ex.Message);
            }
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            pCustomer.TotalAmountSpent = 0.0m;
            pCustomer.TotalSaved = 0.0m;
            pCustomer.DiscountLevel = 0.0m;
        }

        private void radioButtonYes_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonYes.Checked)
            {
                pCustomer.MailingList = true;
            }
        }

        private void radioButtonNo_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonNo.Checked)
            {
                pCustomer.MailingList = false;
            }
        }

        private void buttonAddPurchase_Click(object sender, EventArgs e)
        {

            decimal amountSaved = 0;
            if (decimal.TryParse(textBoxAmountSpent.Text, out decimal amountSpent) && amountSpent > 0)
            {
                pCustomer.TotalAmountSpent += amountSpent;

                if(pCustomer.TotalAmountSpent >= 2000)
                {
                    pCustomer.DiscountLevel = 0.10m;
                }

                else if(pCustomer.TotalAmountSpent >= 1500)
                {
                    pCustomer.DiscountLevel = 0.07m;
                }

                else if(pCustomer.TotalAmountSpent >= 1000)
                {
                    pCustomer.DiscountLevel = 0.06m;
                }

                amountSaved = pCustomer.DiscountLevel * amountSpent;
                pCustomer.TotalSaved += amountSaved;
                labelAmountSaved.Text = amountSaved.ToString("c");
                
                labelTotalSaved.Text = pCustomer.TotalSaved.ToString("c");
                
                labelTotalSpent.Text = pCustomer.TotalAmountSpent.ToString("c");
                labelDiscountLevel.Text = pCustomer.DiscountLevel.ToString("p");

                labelActualCosts.Text = (pCustomer.TotalAmountSpent - pCustomer.TotalSaved).ToString("c");
                textBoxAmountSpent.Focus();
            }
            else
            {
                MessageBox.Show("Please enter a number above zero.");
                textBoxAmountSpent.Focus();
            }
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBoxPhoneNumber.Text = "";
            textBoxCustomerNumber.Text = "0000000";
            textBoxAddress.Text = "";
            textBoxCustomerName.Text = "";
            textBoxCustomerName.Focus();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonReset_Click(object sender, EventArgs e)
        {
            textBoxAmountSpent.Text = "0.00";
            labelAmountSaved.Text = "0.00";
            labelActualCosts.Text = "0.00";
            labelDiscountLevel.Text = "0.0";
            labelTotalSaved.Text = "0.00";
            labelTotalSpent.Text = "0.00";
            pCustomer.TotalSaved = 0.00m;
            pCustomer.TotalAmountSpent = 0.00m;
            textBoxAmountSpent.Focus();
        }
    }
}
