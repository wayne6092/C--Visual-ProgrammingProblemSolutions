﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Preferred_Customer_Class
{
    class Customer : Person
    {
        public string CustomerNumber { get; set; }
        public bool MailingList { get; set; }
    }
}
