﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Preferred_Customer_Class
{
    class PreferredCustomer : Customer
    {
        public decimal TotalAmountSpent { get; set; }
        public decimal DiscountLevel { get; set; }

        public decimal TotalSaved { get; set; }
    }
}
