﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using String_Extension_Methods;

namespace String_Extension_Methods
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonFormat_Click(object sender, EventArgs e)
        {
            //Date 
            DateTime selected = dateTimePickerDOB.Value;
            string dob = selected.ToString("d");
            labelStringArrayDate.Text = dob.DateFormat();

            //Name
            string name = textBoxName.Text;
            labelArrayOfCharName.Text = name.CharArray();

            //Phone Number
            string phoneNumber = textBoxPhoneNumber.Text;
            if (phoneNumber.IsValid())
            {
                labelFormatPhoneNumber.Text = phoneNumber.PhoneFormat();
            }
            else
            {
                labelFormatPhoneNumber.Text = "Phone Number Not Valid.";
            }

            //Sentence
            string sentence = textBoxSentence.Text;
            
            //Sentence reversed
            labelSentenceBackwards.Text = sentence.ReverseString();
            
            //Count words in sentence
            labelWordCount.Text = sentence.WordCounter();
        }

        private void buttonReset_Click(object sender, EventArgs e)
        {
            textBoxName.Text = "";
            textBoxPhoneNumber.Text = "";
            textBoxSentence.Text = "";
            labelArrayOfCharName.Text = "";
            labelFormatPhoneNumber.Text = "";
            labelSentenceBackwards.Text = "";
            labelStringArrayDate.Text = "";
            labelWordCount.Text = "";
            textBoxName.Focus();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
