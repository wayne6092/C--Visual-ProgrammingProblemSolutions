﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace String_Extension_Methods
{
    static class Extensions
    {
        //(Name) Static method convert string to array of Char
        public static string CharArray(this string str)
        {
            string charString = "";
            char[] chars = str.ToCharArray();
            foreach(char c in chars)
            {
                charString += c.ToString() + "\n";
            }
            return charString;
        }

        //(DOB) Static method convert date string ("mm/dd/yyyy") -> string[] array (mm, dd, yyyy)
        public static string DateFormat(this string str)
        {
            string resultArray;
            char[] delim = { '/' };
            string[] tokens = str.Split(delim);

            resultArray = "Element Month: " + tokens[0] + "\n" +
                "Element Day: " + tokens[1] + "\n" +
                "Element Year: " + tokens[2];
            return resultArray;
        }
        //(Phone Number)Static method formats 10-character string as a phone #. 5862222913 -> (586)222-2913
        //1. Check string: Determine if it is 10 characters, and if all chars are digits
        public static bool IsValid(this string str)
        {
            const int VALID_LENGTH = 10;
            bool valid = true;
            if(str.Length == VALID_LENGTH)
            {
                foreach(char ch in str)
                {
                    if (!char.IsDigit(ch))
                    {
                        valid = false;
                    }
                }
            }
            else
            {
                valid = false;
            }
            return valid;
        }

        //2. Format Phone number to read: (586)222-2913
        public static string PhoneFormat(this string str)
        {
            string newString = str.Insert(0, "(");
            newString = newString.Insert(4, ")");
            newString = newString.Insert(8, "-");
            return newString;
        }

        //(Sentence) Static method returns string backwards
        public static string ReverseString(this string str)
        {
            string reversedString = "";
            char[] chars = str.ToCharArray();
            for(int i = chars.Length- 1; i >= 0; i--)
            {
                reversedString += chars[i].ToString();
            }
            return reversedString;
        }

        //(Sentence) Static method that counts # of word in string
        public static string WordCounter(this string str)
        {
            int wordCount = 0;
            string[] tokens = str.Split(null);
            foreach (string s in tokens)
            {
                wordCount++;
            }
            return wordCount.ToString();
        }
    }
}
