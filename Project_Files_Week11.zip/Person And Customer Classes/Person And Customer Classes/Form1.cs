﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Person_And_Customer_Classes
{
    public partial class Form1 : Form
    {
        Customer cust = new Customer();

        public Form1()
        {
            InitializeComponent();
        }

        private void buttonDisplay_Click(object sender, EventArgs e)
        {
            cust.Name = textBoxCustomerName.Text;
            cust.Address = textBoxAddress.Text;
            cust.PhoneNumber = textBoxPhoneNumber.Text;
            cust.CustomerNumber = textBoxCustomerNumber.Text;

            if(radioButtonNo.Checked || radioButtonYes.Checked)
            {
                labelResult.Text = "Customer Name: " + cust.Name + "\n" +
                "Customer Address: " + cust.Address + "\n" +
                "Customer Phone Number: " + cust.PhoneNumber + "\n" +
                "Customer Number: " + cust.CustomerNumber.ToString() + "\n" +
                "Mailing List: " + cust.MailingList;
            }
            textBoxCustomerName.Focus();
            
        }

        private void radioButtonYes_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonYes.Checked)
            {
                cust.MailingList = true;
            }
        }

        private void radioButtonNo_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonNo.Checked)
            {
                cust.MailingList = false;
            }
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBoxPhoneNumber.Text = "";
            textBoxCustomerNumber.Text = "0000000";
            textBoxAddress.Text = "";
            textBoxCustomerName.Text = "";
            textBoxCustomerName.Focus();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
