﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Shift_Supervisor
{
    public partial class Form1 : Form
    {
        //ShiftSupervisor Object
        ShiftSupervisor sSupervisor = new ShiftSupervisor();

        public Form1()
        {
            InitializeComponent();
        }
        public bool metGoal;
        private void buttonDisplay_Click(object sender, EventArgs e)
        {
            try
            {
                if (radioButtonDayShift.Checked || radioButtonNightShift.Checked)
                {
                    if (radioButtonMetGoals.Checked || radioButtonDidntMeetGoals.Checked)
                    {
                        sSupervisor.Name = textBoxEmployeeName.Text;
                        sSupervisor.Number = int.Parse(textBoxEmployeeNumber.Text);
                        sSupervisor.AnnualSalary = decimal.Parse(textBoxAnnualSalary.Text);
                        sSupervisor.AnnualProductionBonus = decimal.Parse(textBoxProductionBonus.Text);
                        if (radioButtonMetGoals.Checked)
                        {
                            labelResult.Text = "Employee Name: " + sSupervisor.Name + "\n" +
                                "Employee Number: " + sSupervisor.Number + "\n" +
                                "Shift Number: " + sSupervisor.ShiftNum + "\n" +
                                "Annual Salary: " + sSupervisor.AnnualSalary.ToString("c") + "\n" +
                                "Annual Production Bonus: " + sSupervisor.AnnualProductionBonus.ToString("c") + "\n" +
                                "Total Amount Earned Annually: " +
                                (sSupervisor.AnnualProductionBonus + sSupervisor.AnnualSalary).ToString("c");
                            textBoxEmployeeName.Focus();
                        }
                        else if (radioButtonDidntMeetGoals.Checked)
                        {
                            labelResult.Text = "Employee Name: " + sSupervisor.Name + "\n" +
                                "Employee Number: " + sSupervisor.Number + "\n" +
                                "Shift Number: " + sSupervisor.ShiftNum + "\n" +
                                "Annual Salary: " + sSupervisor.AnnualSalary.ToString("c");
                            textBoxEmployeeName.Focus();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please indicate whether production goals were met.");
                        radioButtonMetGoals.Focus();
                    }

                }
                else
                {
                    MessageBox.Show("Please choose a shift.");
                    radioButtonDayShift.Focus();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("Something went wrong: " + ex.Message);
            }
            
            
        }

        private void radioButtonNightShift_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonNightShift.Checked)
            {
                sSupervisor.ShiftNum = 2;
            }
        }

        private void radioButtonDayShift_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonDayShift.Checked)
            {
                sSupervisor.ShiftNum = 1;
            }
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBoxEmployeeName.Text = "";
            textBoxEmployeeNumber.Text = "0";
            textBoxAnnualSalary.Text = "0.00";
            textBoxProductionBonus.Text = "0.00";
            labelResult.Text = "";
            textBoxEmployeeName.Focus();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
