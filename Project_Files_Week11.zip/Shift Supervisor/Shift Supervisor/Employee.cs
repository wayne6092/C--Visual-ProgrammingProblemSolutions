﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shift_Supervisor
{
    class Employee
    {
        public string Name { get; set; }
        public int Number { get; set; }
    }


}
