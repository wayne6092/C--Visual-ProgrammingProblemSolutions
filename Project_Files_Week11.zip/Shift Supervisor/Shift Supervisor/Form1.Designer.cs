﻿namespace Shift_Supervisor
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonExit = new System.Windows.Forms.Button();
            this.buttonClear = new System.Windows.Forms.Button();
            this.buttonDisplay = new System.Windows.Forms.Button();
            this.labelResult = new System.Windows.Forms.Label();
            this.textBoxProductionBonus = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radioButtonNightShift = new System.Windows.Forms.RadioButton();
            this.radioButtonDayShift = new System.Windows.Forms.RadioButton();
            this.textBoxEmployeeNumber = new System.Windows.Forms.TextBox();
            this.textBoxEmployeeName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxAnnualSalary = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radioButtonDidntMeetGoals = new System.Windows.Forms.RadioButton();
            this.radioButtonMetGoals = new System.Windows.Forms.RadioButton();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonExit
            // 
            this.buttonExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonExit.Location = new System.Drawing.Point(37, 183);
            this.buttonExit.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(66, 22);
            this.buttonExit.TabIndex = 10;
            this.buttonExit.Text = "&Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // buttonClear
            // 
            this.buttonClear.Location = new System.Drawing.Point(114, 183);
            this.buttonClear.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(66, 22);
            this.buttonClear.TabIndex = 9;
            this.buttonClear.Text = "Clear";
            this.buttonClear.UseVisualStyleBackColor = true;
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // buttonDisplay
            // 
            this.buttonDisplay.Location = new System.Drawing.Point(190, 183);
            this.buttonDisplay.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.buttonDisplay.Name = "buttonDisplay";
            this.buttonDisplay.Size = new System.Drawing.Size(66, 22);
            this.buttonDisplay.TabIndex = 8;
            this.buttonDisplay.Text = "Display";
            this.buttonDisplay.UseVisualStyleBackColor = true;
            this.buttonDisplay.Click += new System.EventHandler(this.buttonDisplay_Click);
            // 
            // labelResult
            // 
            this.labelResult.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelResult.Location = new System.Drawing.Point(11, 213);
            this.labelResult.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelResult.Name = "labelResult";
            this.labelResult.Size = new System.Drawing.Size(246, 92);
            this.labelResult.TabIndex = 18;
            // 
            // textBoxProductionBonus
            // 
            this.textBoxProductionBonus.Location = new System.Drawing.Point(152, 159);
            this.textBoxProductionBonus.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxProductionBonus.Name = "textBoxProductionBonus";
            this.textBoxProductionBonus.Size = new System.Drawing.Size(105, 20);
            this.textBoxProductionBonus.TabIndex = 7;
            this.textBoxProductionBonus.Text = "0.00";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(11, 161);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(139, 13);
            this.label3.TabIndex = 17;
            this.label3.Text = "Annual Production Bonus: $";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioButtonNightShift);
            this.groupBox1.Controls.Add(this.radioButtonDayShift);
            this.groupBox1.Location = new System.Drawing.Point(8, 51);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Size = new System.Drawing.Size(248, 40);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Shift Number:";
            // 
            // radioButtonNightShift
            // 
            this.radioButtonNightShift.AutoSize = true;
            this.radioButtonNightShift.Location = new System.Drawing.Point(123, 16);
            this.radioButtonNightShift.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.radioButtonNightShift.Name = "radioButtonNightShift";
            this.radioButtonNightShift.Size = new System.Drawing.Size(72, 20);
            this.radioButtonNightShift.TabIndex = 3;
            this.radioButtonNightShift.TabStop = true;
            this.radioButtonNightShift.Text = "Night (2)";
            this.radioButtonNightShift.UseVisualStyleBackColor = true;
            this.radioButtonNightShift.CheckedChanged += new System.EventHandler(this.radioButtonNightShift_CheckedChanged);
            // 
            // radioButtonDayShift
            // 
            this.radioButtonDayShift.AutoSize = true;
            this.radioButtonDayShift.Location = new System.Drawing.Point(16, 16);
            this.radioButtonDayShift.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.radioButtonDayShift.Name = "radioButtonDayShift";
            this.radioButtonDayShift.Size = new System.Drawing.Size(66, 20);
            this.radioButtonDayShift.TabIndex = 2;
            this.radioButtonDayShift.TabStop = true;
            this.radioButtonDayShift.Text = "Day (1)";
            this.radioButtonDayShift.UseVisualStyleBackColor = true;
            this.radioButtonDayShift.CheckedChanged += new System.EventHandler(this.radioButtonDayShift_CheckedChanged);
            // 
            // textBoxEmployeeNumber
            // 
            this.textBoxEmployeeNumber.Location = new System.Drawing.Point(103, 30);
            this.textBoxEmployeeNumber.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxEmployeeNumber.Name = "textBoxEmployeeNumber";
            this.textBoxEmployeeNumber.Size = new System.Drawing.Size(154, 20);
            this.textBoxEmployeeNumber.TabIndex = 1;
            this.textBoxEmployeeNumber.Text = "000000";
            // 
            // textBoxEmployeeName
            // 
            this.textBoxEmployeeName.Location = new System.Drawing.Point(103, 4);
            this.textBoxEmployeeName.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxEmployeeName.Name = "textBoxEmployeeName";
            this.textBoxEmployeeName.Size = new System.Drawing.Size(154, 20);
            this.textBoxEmployeeName.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 30);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 13);
            this.label2.TabIndex = 13;
            this.label2.Text = "Employee Number:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 6);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 13);
            this.label1.TabIndex = 11;
            this.label1.Text = "Employee Name:";
            // 
            // textBoxAnnualSalary
            // 
            this.textBoxAnnualSalary.Location = new System.Drawing.Point(152, 136);
            this.textBoxAnnualSalary.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxAnnualSalary.Name = "textBoxAnnualSalary";
            this.textBoxAnnualSalary.Size = new System.Drawing.Size(105, 20);
            this.textBoxAnnualSalary.TabIndex = 6;
            this.textBoxAnnualSalary.Text = "0.00";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(65, 138);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 13);
            this.label4.TabIndex = 22;
            this.label4.Text = "Annual Salary: $";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radioButtonDidntMeetGoals);
            this.groupBox2.Controls.Add(this.radioButtonMetGoals);
            this.groupBox2.Location = new System.Drawing.Point(8, 92);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox2.Size = new System.Drawing.Size(248, 40);
            this.groupBox2.TabIndex = 23;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Production:";
            // 
            // radioButtonDidntMeetGoals
            // 
            this.radioButtonDidntMeetGoals.AutoSize = true;
            this.radioButtonDidntMeetGoals.Location = new System.Drawing.Point(123, 16);
            this.radioButtonDidntMeetGoals.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.radioButtonDidntMeetGoals.Name = "radioButtonDidntMeetGoals";
            this.radioButtonDidntMeetGoals.Size = new System.Drawing.Size(116, 20);
            this.radioButtonDidntMeetGoals.TabIndex = 5;
            this.radioButtonDidntMeetGoals.TabStop = true;
            this.radioButtonDidntMeetGoals.Text = "Didn\'t Meet Goals";
            this.radioButtonDidntMeetGoals.UseVisualStyleBackColor = true;
            // 
            // radioButtonMetGoals
            // 
            this.radioButtonMetGoals.AutoSize = true;
            this.radioButtonMetGoals.Location = new System.Drawing.Point(16, 16);
            this.radioButtonMetGoals.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.radioButtonMetGoals.Name = "radioButtonMetGoals";
            this.radioButtonMetGoals.Size = new System.Drawing.Size(80, 20);
            this.radioButtonMetGoals.TabIndex = 4;
            this.radioButtonMetGoals.TabStop = true;
            this.radioButtonMetGoals.Text = "Met Goals";
            this.radioButtonMetGoals.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AcceptButton = this.buttonDisplay;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.buttonExit;
            this.ClientSize = new System.Drawing.Size(273, 310);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.textBoxAnnualSalary);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.buttonClear);
            this.Controls.Add(this.buttonDisplay);
            this.Controls.Add(this.labelResult);
            this.Controls.Add(this.textBoxProductionBonus);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.textBoxEmployeeNumber);
            this.Controls.Add(this.textBoxEmployeeName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form1";
            this.Text = "Shift Supervisor";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Button buttonClear;
        private System.Windows.Forms.Button buttonDisplay;
        private System.Windows.Forms.Label labelResult;
        private System.Windows.Forms.TextBox textBoxProductionBonus;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radioButtonNightShift;
        private System.Windows.Forms.RadioButton radioButtonDayShift;
        private System.Windows.Forms.TextBox textBoxEmployeeNumber;
        private System.Windows.Forms.TextBox textBoxEmployeeName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxAnnualSalary;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton radioButtonDidntMeetGoals;
        private System.Windows.Forms.RadioButton radioButtonMetGoals;
    }
}

