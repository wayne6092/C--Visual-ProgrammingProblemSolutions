﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Employee_and_Production_Worker
{
    public partial class Form1 : Form
    {
        // ProductionWorker Object
        ProductionWorker pWorker = new ProductionWorker();

        public Form1()
        {
            InitializeComponent();
        }

        private void buttonDisplay_Click(object sender, EventArgs e)
        {
            try
            {
                pWorker.Name = textBoxEmployeeName.Text;
                pWorker.Number = int.Parse(textBoxEmployeeNumber.Text);
                pWorker.HourlyRate = decimal.Parse(textBoxHourlyPayRate.Text);
                labelResult.Text = "Employee Name: " + pWorker.Name + "\n" +
                    "Employee Number: " + pWorker.Number + "\n" +
                    "Shift Number: " + pWorker.ShiftNum + "\n" +
                    "Hourly pay rate: " + pWorker.HourlyRate.ToString("c");
                textBoxEmployeeName.Focus();
            }
            catch(Exception ex)
            {
                MessageBox.Show("Something went wrong: " + ex.Message);
                textBoxEmployeeName.Focus();
            }
        }

        private void radioButtonNightShift_CheckedChanged(object sender, EventArgs e)
        {
            if(radioButtonNightShift.Checked)
            {
                pWorker.ShiftNum = 2;
            }
        }

        private void radioButtonDayShift_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonDayShift.Checked)
            {
                pWorker.ShiftNum = 1;
            }
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBoxEmployeeName.Text = "";
            textBoxEmployeeNumber.Text = "";
            textBoxHourlyPayRate.Text = "0.00";
            labelResult.Text = "";
            textBoxEmployeeName.Focus();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
