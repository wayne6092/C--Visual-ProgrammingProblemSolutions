﻿namespace Employee_and_Production_Worker
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxEmployeeName = new System.Windows.Forms.TextBox();
            this.textBoxEmployeeNumber = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radioButtonNightShift = new System.Windows.Forms.RadioButton();
            this.radioButtonDayShift = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxHourlyPayRate = new System.Windows.Forms.TextBox();
            this.labelResult = new System.Windows.Forms.Label();
            this.buttonDisplay = new System.Windows.Forms.Button();
            this.buttonClear = new System.Windows.Forms.Button();
            this.buttonExit = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 6);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Employee Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 30);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Employee Number:";
            // 
            // textBoxEmployeeName
            // 
            this.textBoxEmployeeName.Location = new System.Drawing.Point(103, 4);
            this.textBoxEmployeeName.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxEmployeeName.Name = "textBoxEmployeeName";
            this.textBoxEmployeeName.Size = new System.Drawing.Size(154, 20);
            this.textBoxEmployeeName.TabIndex = 0;
            // 
            // textBoxEmployeeNumber
            // 
            this.textBoxEmployeeNumber.Location = new System.Drawing.Point(103, 30);
            this.textBoxEmployeeNumber.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxEmployeeNumber.Name = "textBoxEmployeeNumber";
            this.textBoxEmployeeNumber.Size = new System.Drawing.Size(154, 20);
            this.textBoxEmployeeNumber.TabIndex = 1;
            this.textBoxEmployeeNumber.Text = "000000";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioButtonNightShift);
            this.groupBox1.Controls.Add(this.radioButtonDayShift);
            this.groupBox1.Location = new System.Drawing.Point(8, 64);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Size = new System.Drawing.Size(248, 65);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Shift";
            // 
            // radioButtonNightShift
            // 
            this.radioButtonNightShift.AutoSize = true;
            this.radioButtonNightShift.Location = new System.Drawing.Point(137, 25);
            this.radioButtonNightShift.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.radioButtonNightShift.Name = "radioButtonNightShift";
            this.radioButtonNightShift.Size = new System.Drawing.Size(72, 20);
            this.radioButtonNightShift.TabIndex = 3;
            this.radioButtonNightShift.TabStop = true;
            this.radioButtonNightShift.Text = "Night (2)";
            this.radioButtonNightShift.UseVisualStyleBackColor = true;
            this.radioButtonNightShift.CheckedChanged += new System.EventHandler(this.radioButtonNightShift_CheckedChanged);
            // 
            // radioButtonDayShift
            // 
            this.radioButtonDayShift.AutoSize = true;
            this.radioButtonDayShift.Location = new System.Drawing.Point(43, 25);
            this.radioButtonDayShift.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.radioButtonDayShift.Name = "radioButtonDayShift";
            this.radioButtonDayShift.Size = new System.Drawing.Size(66, 20);
            this.radioButtonDayShift.TabIndex = 2;
            this.radioButtonDayShift.TabStop = true;
            this.radioButtonDayShift.Text = "Day (1)";
            this.radioButtonDayShift.UseVisualStyleBackColor = true;
            this.radioButtonDayShift.CheckedChanged += new System.EventHandler(this.radioButtonDayShift_CheckedChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(11, 155);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Hourly Pay Rate: $";
            // 
            // textBoxHourlyPayRate
            // 
            this.textBoxHourlyPayRate.Location = new System.Drawing.Point(108, 153);
            this.textBoxHourlyPayRate.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxHourlyPayRate.Name = "textBoxHourlyPayRate";
            this.textBoxHourlyPayRate.Size = new System.Drawing.Size(149, 20);
            this.textBoxHourlyPayRate.TabIndex = 4;
            this.textBoxHourlyPayRate.Text = "0.00";
            // 
            // labelResult
            // 
            this.labelResult.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelResult.Location = new System.Drawing.Point(11, 213);
            this.labelResult.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelResult.Name = "labelResult";
            this.labelResult.Size = new System.Drawing.Size(246, 75);
            this.labelResult.TabIndex = 7;
            // 
            // buttonDisplay
            // 
            this.buttonDisplay.Location = new System.Drawing.Point(190, 183);
            this.buttonDisplay.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.buttonDisplay.Name = "buttonDisplay";
            this.buttonDisplay.Size = new System.Drawing.Size(66, 22);
            this.buttonDisplay.TabIndex = 5;
            this.buttonDisplay.Text = "Display";
            this.buttonDisplay.UseVisualStyleBackColor = true;
            this.buttonDisplay.Click += new System.EventHandler(this.buttonDisplay_Click);
            // 
            // buttonClear
            // 
            this.buttonClear.Location = new System.Drawing.Point(114, 183);
            this.buttonClear.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(66, 22);
            this.buttonClear.TabIndex = 8;
            this.buttonClear.Text = "Clear";
            this.buttonClear.UseVisualStyleBackColor = true;
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // buttonExit
            // 
            this.buttonExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonExit.Location = new System.Drawing.Point(37, 183);
            this.buttonExit.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(66, 22);
            this.buttonExit.TabIndex = 9;
            this.buttonExit.Text = "&Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // Form1
            // 
            this.AcceptButton = this.buttonDisplay;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.buttonExit;
            this.ClientSize = new System.Drawing.Size(289, 292);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.buttonClear);
            this.Controls.Add(this.buttonDisplay);
            this.Controls.Add(this.labelResult);
            this.Controls.Add(this.textBoxHourlyPayRate);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.textBoxEmployeeNumber);
            this.Controls.Add(this.textBoxEmployeeName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form1";
            this.Text = "Employee and ProductionWorker Class";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxEmployeeName;
        private System.Windows.Forms.TextBox textBoxEmployeeNumber;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxHourlyPayRate;
        private System.Windows.Forms.Label labelResult;
        private System.Windows.Forms.Button buttonDisplay;
        private System.Windows.Forms.RadioButton radioButtonNightShift;
        private System.Windows.Forms.RadioButton radioButtonDayShift;
        private System.Windows.Forms.Button buttonClear;
        private System.Windows.Forms.Button buttonExit;
    }
}

