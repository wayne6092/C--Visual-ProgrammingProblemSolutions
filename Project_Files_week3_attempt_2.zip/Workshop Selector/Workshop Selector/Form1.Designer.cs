﻿namespace Workshop_Selector
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonExit = new System.Windows.Forms.Button();
            this.buttonCalculate = new System.Windows.Forms.Button();
            this.groupBoxWorkshops = new System.Windows.Forms.GroupBox();
            this.groupBoxLocations = new System.Windows.Forms.GroupBox();
            this.listBoxWorkshops = new System.Windows.Forms.ListBox();
            this.listBoxLocations = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.labelRegistration = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.labelLodging = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.labelTotal = new System.Windows.Forms.Label();
            this.buttonClear = new System.Windows.Forms.Button();
            this.groupBoxWorkshops.SuspendLayout();
            this.groupBoxLocations.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonExit
            // 
            this.buttonExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonExit.Location = new System.Drawing.Point(323, 316);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(90, 39);
            this.buttonExit.TabIndex = 4;
            this.buttonExit.Text = "&Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // buttonCalculate
            // 
            this.buttonCalculate.Location = new System.Drawing.Point(323, 222);
            this.buttonCalculate.Name = "buttonCalculate";
            this.buttonCalculate.Size = new System.Drawing.Size(90, 39);
            this.buttonCalculate.TabIndex = 2;
            this.buttonCalculate.Text = "Calculate";
            this.buttonCalculate.UseVisualStyleBackColor = true;
            this.buttonCalculate.Click += new System.EventHandler(this.buttonCalculate_Click);
            // 
            // groupBoxWorkshops
            // 
            this.groupBoxWorkshops.Controls.Add(this.listBoxWorkshops);
            this.groupBoxWorkshops.Location = new System.Drawing.Point(25, 12);
            this.groupBoxWorkshops.Name = "groupBoxWorkshops";
            this.groupBoxWorkshops.Size = new System.Drawing.Size(216, 195);
            this.groupBoxWorkshops.TabIndex = 0;
            this.groupBoxWorkshops.TabStop = false;
            this.groupBoxWorkshops.Text = "Workshops";
            // 
            // groupBoxLocations
            // 
            this.groupBoxLocations.Controls.Add(this.listBoxLocations);
            this.groupBoxLocations.Location = new System.Drawing.Point(267, 12);
            this.groupBoxLocations.Name = "groupBoxLocations";
            this.groupBoxLocations.Size = new System.Drawing.Size(192, 195);
            this.groupBoxLocations.TabIndex = 1;
            this.groupBoxLocations.TabStop = false;
            this.groupBoxLocations.Text = "Locations";
            // 
            // listBoxWorkshops
            // 
            this.listBoxWorkshops.FormattingEnabled = true;
            this.listBoxWorkshops.ItemHeight = 20;
            this.listBoxWorkshops.Items.AddRange(new object[] {
            "Handeling Stress",
            "Time Management",
            "Supervision Skills",
            "Negotiation",
            "How to Interview"});
            this.listBoxWorkshops.Location = new System.Drawing.Point(36, 41);
            this.listBoxWorkshops.Name = "listBoxWorkshops";
            this.listBoxWorkshops.Size = new System.Drawing.Size(144, 124);
            this.listBoxWorkshops.TabIndex = 0;
            // 
            // listBoxLocations
            // 
            this.listBoxLocations.FormattingEnabled = true;
            this.listBoxLocations.ItemHeight = 20;
            this.listBoxLocations.Items.AddRange(new object[] {
            "Austin",
            "Chicago",
            "Dallas",
            "Orlando",
            "Pheonix",
            "Raleigh"});
            this.listBoxLocations.Location = new System.Drawing.Point(38, 41);
            this.listBoxLocations.Name = "listBoxLocations";
            this.listBoxLocations.Size = new System.Drawing.Size(120, 124);
            this.listBoxLocations.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(41, 223);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 20);
            this.label1.TabIndex = 8;
            this.label1.Text = "Registration";
            // 
            // labelRegistration
            // 
            this.labelRegistration.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelRegistration.Location = new System.Drawing.Point(142, 222);
            this.labelRegistration.Name = "labelRegistration";
            this.labelRegistration.Size = new System.Drawing.Size(100, 23);
            this.labelRegistration.TabIndex = 7;
            this.labelRegistration.Text = "$0.00";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(70, 273);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 20);
            this.label3.TabIndex = 9;
            this.label3.Text = "Lodging";
            // 
            // labelLodging
            // 
            this.labelLodging.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelLodging.Location = new System.Drawing.Point(142, 272);
            this.labelLodging.Name = "labelLodging";
            this.labelLodging.Size = new System.Drawing.Size(100, 23);
            this.labelLodging.TabIndex = 6;
            this.labelLodging.Text = "$0.00";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(92, 325);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 20);
            this.label5.TabIndex = 10;
            this.label5.Text = "Total";
            // 
            // labelTotal
            // 
            this.labelTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelTotal.Location = new System.Drawing.Point(142, 324);
            this.labelTotal.Name = "labelTotal";
            this.labelTotal.Size = new System.Drawing.Size(100, 23);
            this.labelTotal.TabIndex = 5;
            this.labelTotal.Text = "$0.00";
            // 
            // buttonClear
            // 
            this.buttonClear.Location = new System.Drawing.Point(324, 268);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(89, 41);
            this.buttonClear.TabIndex = 3;
            this.buttonClear.Text = "Clear";
            this.buttonClear.UseVisualStyleBackColor = true;
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // Form1
            // 
            this.AcceptButton = this.buttonCalculate;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.buttonExit;
            this.ClientSize = new System.Drawing.Size(473, 363);
            this.Controls.Add(this.buttonClear);
            this.Controls.Add(this.labelTotal);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.labelLodging);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.labelRegistration);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBoxLocations);
            this.Controls.Add(this.groupBoxWorkshops);
            this.Controls.Add(this.buttonCalculate);
            this.Controls.Add(this.buttonExit);
            this.Name = "Form1";
            this.Text = "Workshop Selector";
            this.groupBoxWorkshops.ResumeLayout(false);
            this.groupBoxLocations.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Button buttonCalculate;
        private System.Windows.Forms.GroupBox groupBoxWorkshops;
        private System.Windows.Forms.ListBox listBoxWorkshops;
        private System.Windows.Forms.GroupBox groupBoxLocations;
        private System.Windows.Forms.ListBox listBoxLocations;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelRegistration;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label labelLodging;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label labelTotal;
        private System.Windows.Forms.Button buttonClear;
    }
}

