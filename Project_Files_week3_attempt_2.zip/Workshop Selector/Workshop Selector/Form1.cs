﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Workshop_Selector
{
    public partial class Form1 : Form
    {
        private const decimal HANDLING_STRESS = 1000;
        private const decimal TIME_MANAGEMENT = 800;
        private const decimal SUPERVISION_SKILLS = 1500;
        private const decimal NEGOTIATION = 1300;
        private const decimal HOW_TO_INTERVIEW = 500;
        private const decimal AUSTIN = 150;
        private const decimal CHICAGO = 225;
        private const decimal DALLAS = 175;
        private const decimal ORLANDO = 300;
        private const decimal PHEONIX = 175;
        private const decimal RALEIGH = 150;
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonCalculate_Click(object sender, EventArgs e)
        {
            int days;
            decimal registerFee;
            decimal lodgingFee;
            decimal total;

            if (listBoxLocations.SelectedIndex != -1 &&
                listBoxWorkshops.SelectedIndex != -1)
            {
                //Handeling stress and locations
                if (listBoxWorkshops.SelectedIndex == 0)
                {
                    registerFee = HANDLING_STRESS;
                    days = 3;
                    labelRegistration.Text = registerFee.ToString("c");
                    switch (listBoxLocations.SelectedIndex)
                    {
                        case 0:
                            lodgingFee = AUSTIN * days;
                            total = registerFee + lodgingFee;
                            labelLodging.Text = lodgingFee.ToString("c");
                            labelTotal.Text = total.ToString("c");
                            break;
                        case 1:
                            lodgingFee = CHICAGO * days;
                            total = registerFee + lodgingFee;
                            labelLodging.Text = lodgingFee.ToString("c");
                            labelTotal.Text = total.ToString("c");
                            break;
                        case 2:
                            lodgingFee = DALLAS * days;
                            total = registerFee + lodgingFee;
                            labelLodging.Text = lodgingFee.ToString("c");
                            labelTotal.Text = total.ToString("c");
                            break;
                        case 3:
                            lodgingFee = ORLANDO * days;
                            total = registerFee + lodgingFee;
                            labelLodging.Text = lodgingFee.ToString("c");
                            labelTotal.Text = total.ToString("c");
                            break;
                        case 4:
                            lodgingFee = PHEONIX * days;
                            total = registerFee + lodgingFee;
                            labelLodging.Text = lodgingFee.ToString("c");
                            labelTotal.Text = total.ToString("c");
                            break;
                        case 5:
                            lodgingFee = RALEIGH * days;
                            total = registerFee + lodgingFee;
                            labelLodging.Text = lodgingFee.ToString("c");
                            labelTotal.Text = total.ToString("c");
                            break;
                        default:
                            lodgingFee = 0;
                            total = 0;
                            labelLodging.Text = lodgingFee.ToString("c");
                            labelTotal.Text = total.ToString("c");
                            listBoxLocations.Focus();
                            break;
                    }
                }
                //Time management and locations
                else if (listBoxWorkshops.SelectedIndex == 1)
                {
                    registerFee = TIME_MANAGEMENT;
                    days = 3;
                    labelRegistration.Text = registerFee.ToString("c");
                    switch (listBoxLocations.SelectedIndex)
                    {
                        case 0:
                            lodgingFee = AUSTIN * days;
                            total = registerFee + lodgingFee;
                            labelLodging.Text = lodgingFee.ToString("c");
                            labelTotal.Text = total.ToString("c");
                            break;
                        case 1:
                            lodgingFee = CHICAGO * days;
                            total = registerFee + lodgingFee;
                            labelLodging.Text = lodgingFee.ToString("c");
                            labelTotal.Text = total.ToString("c");
                            break;
                        case 2:
                            lodgingFee = DALLAS * days;
                            total = registerFee + lodgingFee;
                            labelLodging.Text = lodgingFee.ToString("c");
                            labelTotal.Text = total.ToString("c");
                            break;
                        case 3:
                            lodgingFee = ORLANDO * days;
                            total = registerFee + lodgingFee;
                            labelLodging.Text = lodgingFee.ToString("c");
                            labelTotal.Text = total.ToString("c");
                            break;
                        case 4:
                            lodgingFee = PHEONIX * days;
                            total = registerFee + lodgingFee;
                            labelLodging.Text = lodgingFee.ToString("c");
                            labelTotal.Text = total.ToString("c");
                            break;
                        case 5:
                            lodgingFee = RALEIGH * days;
                            total = registerFee + lodgingFee;
                            labelLodging.Text = lodgingFee.ToString("c");
                            labelTotal.Text = total.ToString("c");
                            break;
                        default:
                            lodgingFee = 0;
                            total = 0;
                            labelLodging.Text = lodgingFee.ToString("c");
                            labelTotal.Text = total.ToString("c");
                            listBoxLocations.Focus();
                            break;
                    }
                }
                //Supervision skills and locations
                else if (listBoxWorkshops.SelectedIndex == 2)
                {
                    registerFee = SUPERVISION_SKILLS;
                    days = 3;
                    labelRegistration.Text = registerFee.ToString("c");
                    switch (listBoxLocations.SelectedIndex)
                    {
                        case 0:
                            lodgingFee = AUSTIN * days;
                            total = registerFee + lodgingFee;
                            labelLodging.Text = lodgingFee.ToString("c");
                            labelTotal.Text = total.ToString("c");
                            break;
                        case 1:
                            lodgingFee = CHICAGO * days;
                            total = registerFee + lodgingFee;
                            labelLodging.Text = lodgingFee.ToString("c");
                            labelTotal.Text = total.ToString("c");
                            break;
                        case 2:
                            lodgingFee = DALLAS * days;
                            total = registerFee + lodgingFee;
                            labelLodging.Text = lodgingFee.ToString("c");
                            labelTotal.Text = total.ToString("c");
                            break;
                        case 3:
                            lodgingFee = ORLANDO * days;
                            total = registerFee + lodgingFee;
                            labelLodging.Text = lodgingFee.ToString("c");
                            labelTotal.Text = total.ToString("c");
                            break;
                        case 4:
                            lodgingFee = PHEONIX * days;
                            total = registerFee + lodgingFee;
                            labelLodging.Text = lodgingFee.ToString("c");
                            labelTotal.Text = total.ToString("c");
                            break;
                        case 5:
                            lodgingFee = RALEIGH * days;
                            total = registerFee + lodgingFee;
                            labelLodging.Text = lodgingFee.ToString("c");
                            labelTotal.Text = total.ToString("c");
                            break;
                        default:
                            lodgingFee = 0;
                            total = 0;
                            labelLodging.Text = lodgingFee.ToString("c");
                            labelTotal.Text = total.ToString("c");
                            listBoxLocations.Focus();
                            break;
                    }
                }
                else if (listBoxWorkshops.SelectedIndex == 3)
                {
                    registerFee = NEGOTIATION;
                    days = 5;
                    labelRegistration.Text = registerFee.ToString("c");
                    switch (listBoxLocations.SelectedIndex)
                    {
                        case 0:
                            lodgingFee = AUSTIN * days;
                            total = registerFee + lodgingFee;
                            labelLodging.Text = lodgingFee.ToString("c");
                            labelTotal.Text = total.ToString("c");
                            break;
                        case 1:
                            lodgingFee = CHICAGO * days;
                            total = registerFee + lodgingFee;
                            labelLodging.Text = lodgingFee.ToString("c");
                            labelTotal.Text = total.ToString("c");
                            break;
                        case 2:
                            lodgingFee = DALLAS * days;
                            total = registerFee + lodgingFee;
                            labelLodging.Text = lodgingFee.ToString("c");
                            labelTotal.Text = total.ToString("c");
                            break;
                        case 3:
                            lodgingFee = ORLANDO * days;
                            total = registerFee + lodgingFee;
                            labelLodging.Text = lodgingFee.ToString("c");
                            labelTotal.Text = total.ToString("c");
                            break;
                        case 4:
                            lodgingFee = PHEONIX * days;
                            total = registerFee + lodgingFee;
                            labelLodging.Text = lodgingFee.ToString("c");
                            labelTotal.Text = total.ToString("c");
                            break;
                        case 5:
                            lodgingFee = RALEIGH * days;
                            total = registerFee + lodgingFee;
                            labelLodging.Text = lodgingFee.ToString("c");
                            labelTotal.Text = total.ToString("c");
                            break;
                        default:
                            lodgingFee = 0;
                            total = 0;
                            labelLodging.Text = lodgingFee.ToString("c");
                            labelTotal.Text = total.ToString("c");
                            listBoxLocations.Focus();
                            break;
                    }
                }
                else if (listBoxWorkshops.SelectedIndex == 4)
                {
                    registerFee = HOW_TO_INTERVIEW;
                    days = 1;
                    labelRegistration.Text = registerFee.ToString("c");
                    switch (listBoxLocations.SelectedIndex)
                    {
                        case 0:
                            lodgingFee = AUSTIN * days;
                            total = registerFee + lodgingFee;
                            labelLodging.Text = lodgingFee.ToString("c");
                            labelTotal.Text = total.ToString("c");
                            break;
                        case 1:
                            lodgingFee = CHICAGO * days;
                            total = registerFee + lodgingFee;
                            labelLodging.Text = lodgingFee.ToString("c");
                            labelTotal.Text = total.ToString("c");
                            break;
                        case 2:
                            lodgingFee = DALLAS * days;
                            total = registerFee + lodgingFee;
                            labelLodging.Text = lodgingFee.ToString("c");
                            labelTotal.Text = total.ToString("c");
                            break;
                        case 3:
                            lodgingFee = ORLANDO * days;
                            total = registerFee + lodgingFee;
                            labelLodging.Text = lodgingFee.ToString("c");
                            labelTotal.Text = total.ToString("c");
                            break;
                        case 4:
                            lodgingFee = PHEONIX * days;
                            total = registerFee + lodgingFee;
                            labelLodging.Text = lodgingFee.ToString("c");
                            labelTotal.Text = total.ToString("c");
                            break;
                        case 5:
                            lodgingFee = RALEIGH * days;
                            total = registerFee + lodgingFee;
                            labelLodging.Text = lodgingFee.ToString("c");
                            labelTotal.Text = total.ToString("c");
                            break;
                        default:
                            lodgingFee = 0;
                            total = 0;
                            labelLodging.Text = lodgingFee.ToString("c");
                            labelTotal.Text = total.ToString("c");
                            listBoxLocations.Focus();
                            break;
                    }
                }
                else
                {
                    MessageBox.Show("Please select one workshop & one location.");
                    listBoxWorkshops.Focus();
                }
            }
            else
            {
                MessageBox.Show("Please select one workshop & one location.");
                listBoxWorkshops.Focus();
            }
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            labelTotal.Text = "$0.00";
            labelRegistration.Text = "$0.00";
            labelLodging.Text = "$0.00";
            listBoxWorkshops.Focus();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}

