﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Color_Mixer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonMix_Click(object sender, EventArgs e)
        {
            //radioButtonRed.Checked = true;
            //radioButtonRed2.Checked = true;
            //radioButtonYellow.Focus();

            //Blue primary to all secondary
            if (radioButtonBlue.Checked && radioButtonRed2.Checked)
            {
                this.BackColor = Color.Purple;
            }
            else if(radioButtonBlue.Checked && radioButtonYellow2.Checked)
            {
                this.BackColor = Color.Green;
            }
            else if (radioButtonBlue.Checked && radioButtonBlue2.Checked)
            {
                this.BackColor = Color.Blue;
            }

            //Red primary to all secondary
            else if(radioButtonRed.Checked && radioButtonYellow2.Checked)
            {
                this.BackColor = Color.Orange;
            }
            else if(radioButtonRed.Checked && radioButtonBlue2.Checked)
            {
                this.BackColor = Color.Purple;
            }
            else if (radioButtonRed.Checked && radioButtonRed2.Checked)
            {
                this.BackColor = Color.Red;
            }

            //Yellow primary to all secondary
            else if (radioButtonYellow.Checked && radioButtonBlue2.Checked)
            {
                this.BackColor = Color.Green;
            }
            else if (radioButtonYellow.Checked && radioButtonRed2.Checked)
            {
                this.BackColor = Color.Orange;
            }
            else if (radioButtonYellow.Checked && radioButtonYellow2.Checked)
            {
                this.BackColor = Color.Yellow;
            }

            else
            {
                MessageBox.Show("Colors don't mix!");
            }
            //radioButtonRed.Focus();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
