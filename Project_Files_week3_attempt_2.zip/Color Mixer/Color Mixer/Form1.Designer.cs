﻿namespace Color_Mixer
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonExit = new System.Windows.Forms.Button();
            this.buttonMix = new System.Windows.Forms.Button();
            this.groupBox1stColor = new System.Windows.Forms.GroupBox();
            this.groupBox2ndColor = new System.Windows.Forms.GroupBox();
            this.radioButtonRed = new System.Windows.Forms.RadioButton();
            this.radioButtonBlue = new System.Windows.Forms.RadioButton();
            this.radioButtonYellow = new System.Windows.Forms.RadioButton();
            this.radioButtonYellow2 = new System.Windows.Forms.RadioButton();
            this.radioButtonBlue2 = new System.Windows.Forms.RadioButton();
            this.radioButtonRed2 = new System.Windows.Forms.RadioButton();
            this.groupBox1stColor.SuspendLayout();
            this.groupBox2ndColor.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonExit
            // 
            this.buttonExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonExit.Location = new System.Drawing.Point(63, 368);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(91, 34);
            this.buttonExit.TabIndex = 3;
            this.buttonExit.Text = "&Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // buttonMix
            // 
            this.buttonMix.Location = new System.Drawing.Point(184, 368);
            this.buttonMix.Name = "buttonMix";
            this.buttonMix.Size = new System.Drawing.Size(103, 34);
            this.buttonMix.TabIndex = 2;
            this.buttonMix.Text = "Mix";
            this.buttonMix.UseVisualStyleBackColor = true;
            this.buttonMix.Click += new System.EventHandler(this.buttonMix_Click);
            // 
            // groupBox1stColor
            // 
            this.groupBox1stColor.Controls.Add(this.radioButtonYellow);
            this.groupBox1stColor.Controls.Add(this.radioButtonBlue);
            this.groupBox1stColor.Controls.Add(this.radioButtonRed);
            this.groupBox1stColor.Location = new System.Drawing.Point(52, 22);
            this.groupBox1stColor.Name = "groupBox1stColor";
            this.groupBox1stColor.Size = new System.Drawing.Size(249, 167);
            this.groupBox1stColor.TabIndex = 0;
            this.groupBox1stColor.TabStop = false;
            this.groupBox1stColor.Text = "Select 1st Color";
            // 
            // groupBox2ndColor
            // 
            this.groupBox2ndColor.Controls.Add(this.radioButtonYellow2);
            this.groupBox2ndColor.Controls.Add(this.radioButtonBlue2);
            this.groupBox2ndColor.Controls.Add(this.radioButtonRed2);
            this.groupBox2ndColor.Location = new System.Drawing.Point(52, 195);
            this.groupBox2ndColor.Name = "groupBox2ndColor";
            this.groupBox2ndColor.Size = new System.Drawing.Size(249, 167);
            this.groupBox2ndColor.TabIndex = 1;
            this.groupBox2ndColor.TabStop = false;
            this.groupBox2ndColor.Text = "Select 2nd Color";
            // 
            // radioButtonRed
            // 
            this.radioButtonRed.AutoSize = true;
            this.radioButtonRed.Location = new System.Drawing.Point(20, 36);
            this.radioButtonRed.Name = "radioButtonRed";
            this.radioButtonRed.Size = new System.Drawing.Size(64, 24);
            this.radioButtonRed.TabIndex = 0;
            this.radioButtonRed.Text = "Red";
            this.radioButtonRed.UseVisualStyleBackColor = true;
            // 
            // radioButtonBlue
            // 
            this.radioButtonBlue.AutoSize = true;
            this.radioButtonBlue.Location = new System.Drawing.Point(20, 75);
            this.radioButtonBlue.Name = "radioButtonBlue";
            this.radioButtonBlue.Size = new System.Drawing.Size(66, 24);
            this.radioButtonBlue.TabIndex = 1;
            this.radioButtonBlue.TabStop = true;
            this.radioButtonBlue.Text = "Blue";
            this.radioButtonBlue.UseVisualStyleBackColor = true;
            // 
            // radioButtonYellow
            // 
            this.radioButtonYellow.AutoSize = true;
            this.radioButtonYellow.Location = new System.Drawing.Point(20, 115);
            this.radioButtonYellow.Name = "radioButtonYellow";
            this.radioButtonYellow.Size = new System.Drawing.Size(80, 24);
            this.radioButtonYellow.TabIndex = 2;
            this.radioButtonYellow.TabStop = true;
            this.radioButtonYellow.Text = "Yellow";
            this.radioButtonYellow.UseVisualStyleBackColor = true;
            // 
            // radioButtonYellow2
            // 
            this.radioButtonYellow2.AutoSize = true;
            this.radioButtonYellow2.Location = new System.Drawing.Point(20, 115);
            this.radioButtonYellow2.Name = "radioButtonYellow2";
            this.radioButtonYellow2.Size = new System.Drawing.Size(80, 24);
            this.radioButtonYellow2.TabIndex = 5;
            this.radioButtonYellow2.TabStop = true;
            this.radioButtonYellow2.Text = "Yellow";
            this.radioButtonYellow2.UseVisualStyleBackColor = true;
            // 
            // radioButtonBlue2
            // 
            this.radioButtonBlue2.AutoSize = true;
            this.radioButtonBlue2.Location = new System.Drawing.Point(20, 75);
            this.radioButtonBlue2.Name = "radioButtonBlue2";
            this.radioButtonBlue2.Size = new System.Drawing.Size(66, 24);
            this.radioButtonBlue2.TabIndex = 4;
            this.radioButtonBlue2.TabStop = true;
            this.radioButtonBlue2.Text = "Blue";
            this.radioButtonBlue2.UseVisualStyleBackColor = true;
            // 
            // radioButtonRed2
            // 
            this.radioButtonRed2.AutoSize = true;
            this.radioButtonRed2.Location = new System.Drawing.Point(20, 36);
            this.radioButtonRed2.Name = "radioButtonRed2";
            this.radioButtonRed2.Size = new System.Drawing.Size(64, 24);
            this.radioButtonRed2.TabIndex = 3;
            this.radioButtonRed2.Text = "Red";
            this.radioButtonRed2.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AcceptButton = this.buttonMix;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.buttonExit;
            this.ClientSize = new System.Drawing.Size(345, 419);
            this.Controls.Add(this.groupBox2ndColor);
            this.Controls.Add(this.groupBox1stColor);
            this.Controls.Add(this.buttonMix);
            this.Controls.Add(this.buttonExit);
            this.Name = "Form1";
            this.Text = "Color Mixer";
            this.groupBox1stColor.ResumeLayout(false);
            this.groupBox1stColor.PerformLayout();
            this.groupBox2ndColor.ResumeLayout(false);
            this.groupBox2ndColor.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Button buttonMix;
        private System.Windows.Forms.GroupBox groupBox1stColor;
        private System.Windows.Forms.RadioButton radioButtonYellow;
        private System.Windows.Forms.RadioButton radioButtonBlue;
        private System.Windows.Forms.RadioButton radioButtonRed;
        private System.Windows.Forms.GroupBox groupBox2ndColor;
        private System.Windows.Forms.RadioButton radioButtonYellow2;
        private System.Windows.Forms.RadioButton radioButtonBlue2;
        private System.Windows.Forms.RadioButton radioButtonRed2;
    }
}

