﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Roman_Numeral_Converter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonCalculate_Click(object sender, EventArgs e)
        {
            int number;
            if (int.TryParse(textBoxNumber.Text, out number))
            {
                if (number >= 0 && number <= 10)
                {
                    switch (number)
                    {
                        case 0:
                            labelRomanNumeral.Text = "Enter 1-10";
                            break;
                        case 1:
                            labelRomanNumeral.Text = "I";
                            break;
                        case 2:
                            labelRomanNumeral.Text = "II";
                            break;
                        case 3:
                            labelRomanNumeral.Text = "III";
                            break;
                        case 4:
                            labelRomanNumeral.Text = "IV";
                            break;
                        case 5:
                            labelRomanNumeral.Text = "V";
                            break;
                        case 6:
                            labelRomanNumeral.Text = "VI";
                            break;
                        case 7:
                            labelRomanNumeral.Text = "VII";
                            break;
                        case 8:
                            labelRomanNumeral.Text = "VIII";
                            break;
                        case 9:
                            labelRomanNumeral.Text = "IX";
                            break;
                        case 10:
                            labelRomanNumeral.Text = "X";
                            break;
                        default:
                            labelRomanNumeral.Text = "Enter 1-10";
                            break;
                    }
                    textBoxNumber.Focus();
                }
                else
                {
                    labelRomanNumeral.Text = "Enter 1-10";
                    textBoxNumber.Focus();
                }
            }
            else
            {
                labelRomanNumeral.Text = "Enter 1-10";
                textBoxNumber.Focus();
            }

        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBoxNumber.Text = "";
            labelRomanNumeral.Text = "";
            textBoxNumber.Focus();
        }
    }
}
