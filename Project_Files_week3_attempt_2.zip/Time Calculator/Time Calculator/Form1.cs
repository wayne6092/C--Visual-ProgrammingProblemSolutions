﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Time_Calculator
{
    public partial class Form1 : Form
    {
        private const int MINUTE = 60;
        private const int HOUR = 3600;
        private const int DAY = 86400;

        public Form1()
        {
            InitializeComponent();
        }

        private void buttonCalculate_Click(object sender, EventArgs e)
        {
            int seconds;
            int minutes;
            int hours;
            int days;

            if (int.TryParse(textBoxSeconds.Text, out seconds))
            {
                if(seconds > 0)
                {
                    if (seconds >= MINUTE)
                    {
                        minutes = seconds / MINUTE;
                        labelMinutes.Text = minutes.ToString();
                        if(seconds >= HOUR)
                        {
                            hours = seconds / HOUR;
                            labelHours.Text = hours.ToString();
                            if (seconds >= DAY)
                            {
                                days = seconds / DAY; 
                                labelDays.Text = days.ToString();
                                textBoxSeconds.Focus();
                            }
                            else
                            {
                                days = 0;
                                labelDays.Text = days.ToString();
                            }
                        }
                        else
                        {
                            hours = 0;
                            labelHours.Text = hours.ToString();
                        }
                    }
                    else
                    {
                        minutes = 0;
                        labelMinutes.Text = minutes.ToString();
                    }
                }
                else
                {
                    MessageBox.Show("Please enter positive number.");
                    textBoxSeconds.Focus();
                }
            }
            else
            {
                MessageBox.Show("Please enter a number");
                textBoxSeconds.Focus();
            }
        }

        private void buttonReset_Click(object sender, EventArgs e)
        {
            textBoxSeconds.Focus();
            textBoxSeconds.Text = "0";
            labelDays.Text = "0";
            labelHours.Text = "0";
            labelMinutes.Text = "0";
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
