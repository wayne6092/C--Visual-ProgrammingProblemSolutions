﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mass_and_Weight
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private const double VAR_RATE = 9.8;
        private const double TOO_HIGH = 1000;
        private const double TOO_LOW = 10;
        private void buttonCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                double mass;
                if (double.TryParse(textBoxMass.Text, out mass))
                {
                    double weight = mass * VAR_RATE;
                    labelWeight.Text = weight.ToString("n1");

                    if (weight > TOO_HIGH)
                    {
                        MessageBox.Show("Weight is too high!");
                    }

                    if (weight < TOO_LOW)
                    {
                        MessageBox.Show("Weight is too light!");
                    }
                    textBoxMass.Focus();
                }
                else
                {
                    MessageBox.Show("Please enter a number");
                    textBoxMass.Focus();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("-Error! Please enter a number.-");
            }
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBoxMass.Text = "0";
            labelWeight.Text = "0";
            textBoxMass.Focus();
        }
    }
}
