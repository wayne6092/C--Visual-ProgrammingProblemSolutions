﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Body_Mass_Index_Enhanced
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            double weight;
            double height;
            double bmi;
            if (double.TryParse(weightTextBox.Text, out weight))
            {
                if (double.TryParse(heightTextBox.Text, out height))
                {
                    bmi = (weight * 703) / (height * height);
                    bmiLabel.Text = bmi.ToString("n1");
                    if (bmi < 18.5 && bmi >= 0)
                    {
                        labelDiagnosis.Text = "You are Underweight.";
                    }
                    else if (bmi >= 18.5 && bmi < 25)
                    {
                        labelDiagnosis.Text = "You are at Optimal weight.";
                    }
                    
                    else if (bmi >= 25 && bmi < 30)
                    {
                        labelDiagnosis.Text = "You are at Overweight.";
                    }
                    //I added this because it is part of the standard BMI calculation
                    else if (bmi >= 30.0)
                    {
                        labelDiagnosis.Text = "You are Obese.";
                    }
                    weightTextBox.Focus();

                }
                else
                {
                    MessageBox.Show("Please enter valid data!");
                    heightTextBox.Focus();
                }
            }
            else
            {
                MessageBox.Show("Please enter valid data!");
                weightTextBox.Focus();
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            weightTextBox.Text = "0";
            heightTextBox.Text = "0";
            labelDiagnosis.Text = "0";
            bmiLabel.Text = "0";
            weightTextBox.Focus();
        }

        private void quitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
