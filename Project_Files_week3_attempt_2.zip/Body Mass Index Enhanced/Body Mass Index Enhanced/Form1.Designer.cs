﻿namespace Body_Mass_Index_Enhanced
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.clearButton = new System.Windows.Forms.Button();
            this.calculateButton = new System.Windows.Forms.Button();
            this.quitButton = new System.Windows.Forms.Button();
            this.heightTextBox = new System.Windows.Forms.TextBox();
            this.weightTextBox = new System.Windows.Forms.TextBox();
            this.bmiLabel = new System.Windows.Forms.Label();
            this.BmiTitleLabel = new System.Windows.Forms.Label();
            this.heightTitleLabel = new System.Windows.Forms.Label();
            this.weightTitleLabel = new System.Windows.Forms.Label();
            this.labelTitleDiagnosis = new System.Windows.Forms.Label();
            this.labelDiagnosis = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(314, 85);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(100, 36);
            this.clearButton.TabIndex = 3;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // calculateButton
            // 
            this.calculateButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.calculateButton.Location = new System.Drawing.Point(314, 30);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(100, 36);
            this.calculateButton.TabIndex = 2;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // quitButton
            // 
            this.quitButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.quitButton.Location = new System.Drawing.Point(314, 143);
            this.quitButton.Name = "quitButton";
            this.quitButton.Size = new System.Drawing.Size(100, 36);
            this.quitButton.TabIndex = 4;
            this.quitButton.Text = "&Quit";
            this.quitButton.UseVisualStyleBackColor = true;
            this.quitButton.Click += new System.EventHandler(this.quitButton_Click);
            // 
            // heightTextBox
            // 
            this.heightTextBox.Location = new System.Drawing.Point(187, 54);
            this.heightTextBox.Name = "heightTextBox";
            this.heightTextBox.Size = new System.Drawing.Size(100, 26);
            this.heightTextBox.TabIndex = 1;
            this.heightTextBox.Text = "0";
            // 
            // weightTextBox
            // 
            this.weightTextBox.Location = new System.Drawing.Point(187, 5);
            this.weightTextBox.Name = "weightTextBox";
            this.weightTextBox.Size = new System.Drawing.Size(100, 26);
            this.weightTextBox.TabIndex = 0;
            this.weightTextBox.Text = "0";
            // 
            // bmiLabel
            // 
            this.bmiLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.bmiLabel.Location = new System.Drawing.Point(187, 101);
            this.bmiLabel.Name = "bmiLabel";
            this.bmiLabel.Size = new System.Drawing.Size(100, 23);
            this.bmiLabel.TabIndex = 6;
            this.bmiLabel.Text = "0";
            // 
            // BmiTitleLabel
            // 
            this.BmiTitleLabel.AutoSize = true;
            this.BmiTitleLabel.Location = new System.Drawing.Point(8, 101);
            this.BmiTitleLabel.Name = "BmiTitleLabel";
            this.BmiTitleLabel.Size = new System.Drawing.Size(173, 20);
            this.BmiTitleLabel.TabIndex = 8;
            this.BmiTitleLabel.Text = "BMI (Body Mass Index)";
            // 
            // heightTitleLabel
            // 
            this.heightTitleLabel.AutoSize = true;
            this.heightTitleLabel.Location = new System.Drawing.Point(63, 58);
            this.heightTitleLabel.Name = "heightTitleLabel";
            this.heightTitleLabel.Size = new System.Drawing.Size(118, 20);
            this.heightTitleLabel.TabIndex = 9;
            this.heightTitleLabel.Text = "Height (Inches)";
            // 
            // weightTitleLabel
            // 
            this.weightTitleLabel.AutoSize = true;
            this.weightTitleLabel.Location = new System.Drawing.Point(82, 11);
            this.weightTitleLabel.Name = "weightTitleLabel";
            this.weightTitleLabel.Size = new System.Drawing.Size(99, 20);
            this.weightTitleLabel.TabIndex = 10;
            this.weightTitleLabel.Text = "Weight (Lbs)";
            // 
            // labelTitleDiagnosis
            // 
            this.labelTitleDiagnosis.AutoSize = true;
            this.labelTitleDiagnosis.Location = new System.Drawing.Point(14, 143);
            this.labelTitleDiagnosis.Name = "labelTitleDiagnosis";
            this.labelTitleDiagnosis.Size = new System.Drawing.Size(79, 20);
            this.labelTitleDiagnosis.TabIndex = 7;
            this.labelTitleDiagnosis.Text = "Diagnosis";
            // 
            // labelDiagnosis
            // 
            this.labelDiagnosis.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelDiagnosis.Location = new System.Drawing.Point(95, 143);
            this.labelDiagnosis.Name = "labelDiagnosis";
            this.labelDiagnosis.Size = new System.Drawing.Size(192, 55);
            this.labelDiagnosis.TabIndex = 5;
            // 
            // Form1
            // 
            this.AcceptButton = this.calculateButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.quitButton;
            this.ClientSize = new System.Drawing.Size(433, 212);
            this.Controls.Add(this.labelDiagnosis);
            this.Controls.Add(this.labelTitleDiagnosis);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.quitButton);
            this.Controls.Add(this.heightTextBox);
            this.Controls.Add(this.weightTextBox);
            this.Controls.Add(this.bmiLabel);
            this.Controls.Add(this.BmiTitleLabel);
            this.Controls.Add(this.heightTitleLabel);
            this.Controls.Add(this.weightTitleLabel);
            this.Name = "Form1";
            this.Text = "BMI Calculator Enhanced";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Button quitButton;
        private System.Windows.Forms.TextBox heightTextBox;
        private System.Windows.Forms.TextBox weightTextBox;
        private System.Windows.Forms.Label bmiLabel;
        private System.Windows.Forms.Label BmiTitleLabel;
        private System.Windows.Forms.Label heightTitleLabel;
        private System.Windows.Forms.Label weightTitleLabel;
        private System.Windows.Forms.Label labelTitleDiagnosis;
        private System.Windows.Forms.Label labelDiagnosis;
    }
}

