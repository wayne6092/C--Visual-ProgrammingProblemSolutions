﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Distance_Converter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonConvert_Click(object sender, EventArgs e)
        {
            double measurement;
            if (double.TryParse(textBoxDistance.Text, out measurement))
            {
                if (listBoxFrom.SelectedIndex != -1 && 
                    listBoxTo.SelectedIndex != -1)
                {
                    //Inch to inch
                    if (listBoxFrom.SelectedIndex == 0 &&
                    listBoxTo.SelectedIndex == 0)
                    {
                        labelConvertedDistance.Text = measurement.ToString("n2");
                    }
                    //Inch to foot
                    else if(listBoxFrom.SelectedIndex == 0 &&
                    listBoxTo.SelectedIndex == 1)
                    {
                        double result = measurement / 12;
                        labelConvertedDistance.Text = result.ToString("n2");
                    }
                    //Inch to yard
                    else if(listBoxFrom.SelectedIndex == 0 &&
                    listBoxTo.SelectedIndex == 2)
                    {
                        double result = measurement / 36;
                        labelConvertedDistance.Text = result.ToString("n2");
                    }
                    //Foot to inch
                    else if(listBoxFrom.SelectedIndex == 1 &&
                    listBoxTo.SelectedIndex == 0)
                    {
                        double result = measurement * 12;
                        labelConvertedDistance.Text = result.ToString("n2");
                    }
                    //Foot to Foot
                    else if (listBoxFrom.SelectedIndex == 1 &&
                    listBoxTo.SelectedIndex == 1)
                    {
                        labelConvertedDistance.Text = measurement.ToString("n2");
                    }
                    //Foot to Yard
                    else if (listBoxFrom.SelectedIndex == 1 &&
                    listBoxTo.SelectedIndex == 2)
                    {
                        double result = measurement / 3;
                        labelConvertedDistance.Text = result.ToString("n2");
                    }
                    //Yard to inch
                    else if (listBoxFrom.SelectedIndex == 2 &&
                    listBoxTo.SelectedIndex == 0)
                    {
                        double result = measurement * 36;
                        labelConvertedDistance.Text = result.ToString("n2");
                    }
                    //Yard to Foot
                    else if (listBoxFrom.SelectedIndex == 2 &&
                    listBoxTo.SelectedIndex == 1)
                    {
                        double result = measurement * 3;
                        labelConvertedDistance.Text = result.ToString("n2");
                    }
                    //Foot to inch
                    else if (listBoxFrom.SelectedIndex == 2 &&
                    listBoxTo.SelectedIndex == 2)
                    {
                        labelConvertedDistance.Text = measurement.ToString("n2");
                    }
                    textBoxDistance.Focus();

                }
                else
                {
                    MessageBox.Show("Please select two measurement types.");
                    listBoxFrom.Focus();
                }
            }
            else
            {
                MessageBox.Show("Please enter a number!");
                textBoxDistance.Focus();
            }
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Clear_Click(object sender, EventArgs e)
        {
            textBoxDistance.Text = "0";
            labelConvertedDistance.Text = "0";
            
        }
    }
}
