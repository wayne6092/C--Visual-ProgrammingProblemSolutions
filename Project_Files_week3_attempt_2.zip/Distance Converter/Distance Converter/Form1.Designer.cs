﻿namespace Distance_Converter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonExit = new System.Windows.Forms.Button();
            this.buttonConvert = new System.Windows.Forms.Button();
            this.labelTitleDistance = new System.Windows.Forms.Label();
            this.labelConvertedDistance = new System.Windows.Forms.Label();
            this.labelTitleConvert = new System.Windows.Forms.Label();
            this.textBoxDistance = new System.Windows.Forms.TextBox();
            this.groupBoxFrom = new System.Windows.Forms.GroupBox();
            this.listBoxFrom = new System.Windows.Forms.ListBox();
            this.groupBoxTo = new System.Windows.Forms.GroupBox();
            this.listBoxTo = new System.Windows.Forms.ListBox();
            this.Clear = new System.Windows.Forms.Button();
            this.groupBoxFrom.SuspendLayout();
            this.groupBoxTo.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonExit
            // 
            this.buttonExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonExit.Location = new System.Drawing.Point(57, 272);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(83, 38);
            this.buttonExit.TabIndex = 5;
            this.buttonExit.Text = "&Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // buttonConvert
            // 
            this.buttonConvert.Location = new System.Drawing.Point(284, 272);
            this.buttonConvert.Name = "buttonConvert";
            this.buttonConvert.Size = new System.Drawing.Size(98, 38);
            this.buttonConvert.TabIndex = 3;
            this.buttonConvert.Text = "Convert";
            this.buttonConvert.UseVisualStyleBackColor = true;
            this.buttonConvert.Click += new System.EventHandler(this.buttonConvert_Click);
            // 
            // labelTitleDistance
            // 
            this.labelTitleDistance.AutoSize = true;
            this.labelTitleDistance.Location = new System.Drawing.Point(95, 14);
            this.labelTitleDistance.Name = "labelTitleDistance";
            this.labelTitleDistance.Size = new System.Drawing.Size(115, 20);
            this.labelTitleDistance.TabIndex = 2;
            this.labelTitleDistance.Text = "Enter Distance";
            // 
            // labelConvertedDistance
            // 
            this.labelConvertedDistance.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelConvertedDistance.Location = new System.Drawing.Point(230, 226);
            this.labelConvertedDistance.Name = "labelConvertedDistance";
            this.labelConvertedDistance.Size = new System.Drawing.Size(100, 23);
            this.labelConvertedDistance.TabIndex = 4;
            this.labelConvertedDistance.Text = "0";
            // 
            // labelTitleConvert
            // 
            this.labelTitleConvert.AutoSize = true;
            this.labelTitleConvert.Location = new System.Drawing.Point(66, 229);
            this.labelTitleConvert.Name = "labelTitleConvert";
            this.labelTitleConvert.Size = new System.Drawing.Size(149, 20);
            this.labelTitleConvert.TabIndex = 5;
            this.labelTitleConvert.Text = "Converted Distance";
            // 
            // textBoxDistance
            // 
            this.textBoxDistance.Location = new System.Drawing.Point(225, 10);
            this.textBoxDistance.Name = "textBoxDistance";
            this.textBoxDistance.Size = new System.Drawing.Size(100, 26);
            this.textBoxDistance.TabIndex = 0;
            this.textBoxDistance.Text = "0";
            // 
            // groupBoxFrom
            // 
            this.groupBoxFrom.Controls.Add(this.listBoxFrom);
            this.groupBoxFrom.Location = new System.Drawing.Point(12, 60);
            this.groupBoxFrom.Name = "groupBoxFrom";
            this.groupBoxFrom.Size = new System.Drawing.Size(205, 147);
            this.groupBoxFrom.TabIndex = 1;
            this.groupBoxFrom.TabStop = false;
            this.groupBoxFrom.Text = "From";
            // 
            // listBoxFrom
            // 
            this.listBoxFrom.FormattingEnabled = true;
            this.listBoxFrom.ItemHeight = 20;
            this.listBoxFrom.Items.AddRange(new object[] {
            "Inches",
            "Feet",
            "Yards"});
            this.listBoxFrom.Location = new System.Drawing.Point(45, 37);
            this.listBoxFrom.Name = "listBoxFrom";
            this.listBoxFrom.Size = new System.Drawing.Size(120, 84);
            this.listBoxFrom.TabIndex = 1;
            // 
            // groupBoxTo
            // 
            this.groupBoxTo.Controls.Add(this.listBoxTo);
            this.groupBoxTo.Location = new System.Drawing.Point(223, 60);
            this.groupBoxTo.Name = "groupBoxTo";
            this.groupBoxTo.Size = new System.Drawing.Size(200, 147);
            this.groupBoxTo.TabIndex = 1;
            this.groupBoxTo.TabStop = false;
            this.groupBoxTo.Text = "To";
            // 
            // listBoxTo
            // 
            this.listBoxTo.FormattingEnabled = true;
            this.listBoxTo.ItemHeight = 20;
            this.listBoxTo.Items.AddRange(new object[] {
            "Inches",
            "Feet",
            "Yards"});
            this.listBoxTo.Location = new System.Drawing.Point(39, 37);
            this.listBoxTo.Name = "listBoxTo";
            this.listBoxTo.Size = new System.Drawing.Size(120, 84);
            this.listBoxTo.TabIndex = 2;
            // 
            // Clear
            // 
            this.Clear.Location = new System.Drawing.Point(169, 272);
            this.Clear.Name = "Clear";
            this.Clear.Size = new System.Drawing.Size(84, 38);
            this.Clear.TabIndex = 4;
            this.Clear.Text = "Clear";
            this.Clear.UseVisualStyleBackColor = true;
            this.Clear.Click += new System.EventHandler(this.Clear_Click);
            // 
            // Form1
            // 
            this.AcceptButton = this.buttonConvert;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.buttonExit;
            this.ClientSize = new System.Drawing.Size(438, 327);
            this.Controls.Add(this.Clear);
            this.Controls.Add(this.groupBoxTo);
            this.Controls.Add(this.groupBoxFrom);
            this.Controls.Add(this.textBoxDistance);
            this.Controls.Add(this.labelTitleConvert);
            this.Controls.Add(this.labelConvertedDistance);
            this.Controls.Add(this.labelTitleDistance);
            this.Controls.Add(this.buttonConvert);
            this.Controls.Add(this.buttonExit);
            this.Name = "Form1";
            this.Text = "Distance Converter";
            this.groupBoxFrom.ResumeLayout(false);
            this.groupBoxTo.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Button buttonConvert;
        private System.Windows.Forms.Label labelTitleDistance;
        private System.Windows.Forms.Label labelConvertedDistance;
        private System.Windows.Forms.Label labelTitleConvert;
        private System.Windows.Forms.TextBox textBoxDistance;
        private System.Windows.Forms.GroupBox groupBoxFrom;
        private System.Windows.Forms.ListBox listBoxFrom;
        private System.Windows.Forms.GroupBox groupBoxTo;
        private System.Windows.Forms.ListBox listBoxTo;
        private System.Windows.Forms.Button Clear;
    }
}

