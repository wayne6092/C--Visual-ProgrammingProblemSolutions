﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Magic_Dates
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonCalculate_Click(object sender, EventArgs e)
        {
            int month;
            int day;
            int year;

            //If I added try and catch statements it would be redundant
            //Code below is error proof
            if (int.TryParse(textBoxMonth.Text, out month))
            {
                if (month >= 0 && month <= 12)
                {
                    if (int.TryParse(textBoxDay.Text, out day))
                    {
                        if (day >= 0 && day <= 31)
                        {
                            int result = month * day;
                            if (int.TryParse(textBoxYear.Text, out year))
                            {
                                if(year >= 0 && year <= 99)
                                {
                                    if (year == result)
                                    {
                                        labelMagicDate.Text = 
                                            "You entered a Magic Date! Congratulations!!!";
                                        textBoxMonth.Focus();
                                    }
                                    else
                                    {
                                        labelMagicDate.Text = "Sorry, this is not a Magic Date.";
                                        textBoxMonth.Focus();
                                    }
                                }
                                else
                                {
                                    labelMagicDate.Text =
                                    "Please enter a date. Invalid year";
                                    textBoxYear.Focus();
                                }
                            }
                            else
                            {
                                labelMagicDate.Text =
                                "Please enter a date. Invalid year";
                                textBoxYear.Focus();
                            }
                        }
                        else
                        {
                            labelMagicDate.Text =
                            "Please enter a date. Invalid day";
                            textBoxDay.Focus();
                        }
                    }
                    else
                    {
                        labelMagicDate.Text =
                        "Please enter a date. Invalid day";
                        textBoxDay.Focus();
                    }
                }
                else
                {
                    labelMagicDate.Text = 
                        "Please enter a date. Invalid month";
                    textBoxMonth.Focus();
                }
            }
            else
            {
                labelMagicDate.Text = 
                    "Please enter a date. Invalid month.";
                textBoxMonth.Focus();
            }
            
            
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBoxDay.Text = "00";
            textBoxMonth.Text = "00";
            textBoxYear.Text = "00";
            textBoxMonth.Focus();
        }
    }
}
