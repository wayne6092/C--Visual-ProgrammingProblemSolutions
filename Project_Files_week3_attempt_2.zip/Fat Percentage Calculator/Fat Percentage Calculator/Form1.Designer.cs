﻿namespace Fat_Percentage_Calculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonExit = new System.Windows.Forms.Button();
            this.buttonClear = new System.Windows.Forms.Button();
            this.buttonCalculate = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxFatGrams = new System.Windows.Forms.TextBox();
            this.textBoxTotalCal = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.labelFatCalories = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.labelFatPercent = new System.Windows.Forms.Label();
            this.checkBoxLowFat = new System.Windows.Forms.CheckBox();
            this.labelLowFat = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonExit
            // 
            this.buttonExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonExit.Location = new System.Drawing.Point(53, 199);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(74, 39);
            this.buttonExit.TabIndex = 5;
            this.buttonExit.Text = "&Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // buttonClear
            // 
            this.buttonClear.Location = new System.Drawing.Point(133, 199);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(91, 39);
            this.buttonClear.TabIndex = 4;
            this.buttonClear.Text = "Clear";
            this.buttonClear.UseVisualStyleBackColor = true;
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // buttonCalculate
            // 
            this.buttonCalculate.Location = new System.Drawing.Point(230, 199);
            this.buttonCalculate.Name = "buttonCalculate";
            this.buttonCalculate.Size = new System.Drawing.Size(100, 39);
            this.buttonCalculate.TabIndex = 3;
            this.buttonCalculate.Text = "Calculate";
            this.buttonCalculate.UseVisualStyleBackColor = true;
            this.buttonCalculate.Click += new System.EventHandler(this.buttonCalculate_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(88, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(136, 20);
            this.label1.TabIndex = 12;
            this.label1.Text = "Total # of Calories";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(108, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(116, 20);
            this.label2.TabIndex = 11;
            this.label2.Text = "# of Fat Grams";
            // 
            // textBoxFatGrams
            // 
            this.textBoxFatGrams.Location = new System.Drawing.Point(230, 45);
            this.textBoxFatGrams.Name = "textBoxFatGrams";
            this.textBoxFatGrams.Size = new System.Drawing.Size(100, 26);
            this.textBoxFatGrams.TabIndex = 1;
            this.textBoxFatGrams.Text = "0";
            // 
            // textBoxTotalCal
            // 
            this.textBoxTotalCal.Location = new System.Drawing.Point(230, 13);
            this.textBoxTotalCal.Name = "textBoxTotalCal";
            this.textBoxTotalCal.Size = new System.Drawing.Size(100, 26);
            this.textBoxTotalCal.TabIndex = 0;
            this.textBoxTotalCal.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(58, 80);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(166, 20);
            this.label3.TabIndex = 10;
            this.label3.Text = "# of Calories From Fat";
            // 
            // labelFatCalories
            // 
            this.labelFatCalories.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelFatCalories.Location = new System.Drawing.Point(230, 80);
            this.labelFatCalories.Name = "labelFatCalories";
            this.labelFatCalories.Size = new System.Drawing.Size(100, 23);
            this.labelFatCalories.TabIndex = 8;
            this.labelFatCalories.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(105, 111);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(119, 20);
            this.label5.TabIndex = 9;
            this.label5.Text = "Fat Percentage";
            // 
            // labelFatPercent
            // 
            this.labelFatPercent.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelFatPercent.Location = new System.Drawing.Point(230, 110);
            this.labelFatPercent.Name = "labelFatPercent";
            this.labelFatPercent.Size = new System.Drawing.Size(100, 23);
            this.labelFatPercent.TabIndex = 7;
            this.labelFatPercent.Text = "0%";
            // 
            // checkBoxLowFat
            // 
            this.checkBoxLowFat.AutoSize = true;
            this.checkBoxLowFat.Location = new System.Drawing.Point(228, 159);
            this.checkBoxLowFat.Name = "checkBoxLowFat";
            this.checkBoxLowFat.Size = new System.Drawing.Size(102, 24);
            this.checkBoxLowFat.TabIndex = 2;
            this.checkBoxLowFat.Text = "Low-Fat?";
            this.checkBoxLowFat.UseVisualStyleBackColor = true;
            // 
            // labelLowFat
            // 
            this.labelLowFat.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelLowFat.Location = new System.Drawing.Point(47, 150);
            this.labelLowFat.Name = "labelLowFat";
            this.labelLowFat.Size = new System.Drawing.Size(162, 33);
            this.labelLowFat.TabIndex = 6;
            this.labelLowFat.Visible = false;
            // 
            // Form1
            // 
            this.AcceptButton = this.buttonCalculate;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.buttonExit;
            this.ClientSize = new System.Drawing.Size(387, 252);
            this.Controls.Add(this.labelLowFat);
            this.Controls.Add(this.checkBoxLowFat);
            this.Controls.Add(this.labelFatPercent);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.labelFatCalories);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBoxTotalCal);
            this.Controls.Add(this.textBoxFatGrams);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonCalculate);
            this.Controls.Add(this.buttonClear);
            this.Controls.Add(this.buttonExit);
            this.Name = "Form1";
            this.Text = "Fat Percentage Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Button buttonClear;
        private System.Windows.Forms.Button buttonCalculate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxFatGrams;
        private System.Windows.Forms.TextBox textBoxTotalCal;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label labelFatCalories;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label labelFatPercent;
        private System.Windows.Forms.CheckBox checkBoxLowFat;
        private System.Windows.Forms.Label labelLowFat;
    }
}

