﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fat_Percentage_Calculator
{
    public partial class Form1 : Form
    {
        private const double CONVERSION = 9;
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonCalculate_Click(object sender, EventArgs e)
        {
            double fatGrams;
            double totalCalories;
            double fatPercent;
            double fatCalories;
            double fatPercentFormat;

            if (double.TryParse(textBoxFatGrams.Text, out fatGrams))
            {
                if(fatGrams > 0)
                {
                    fatCalories = fatGrams * CONVERSION;
                    if (double.TryParse(textBoxTotalCal.Text, out totalCalories))
                    {
                        if(totalCalories > 0 && fatCalories < totalCalories)
                        {
                            fatPercent = fatCalories / totalCalories;
                            fatPercentFormat = fatPercent * 100;
                            labelFatCalories.Text = fatCalories.ToString("n2");
                            labelFatPercent.Text = 
                                fatPercentFormat.ToString("n1") + "%";

                            if (checkBoxLowFat.Checked)
                            {
                                labelLowFat.Visible = true;
                                if(fatPercentFormat >= 30)
                                {
                                    labelLowFat.Text = "IS NOT LOW FAT";
                                }
                                else
                                {
                                    labelLowFat.Text = "IS LOW FAT";
                                }
                            }
                            else
                            {
                                labelLowFat.Visible = false;
                            }
                        }
                        else
                        {
                            MessageBox.Show("Fat calories cannot be more than total calories.");
                            textBoxTotalCal.Focus();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please enter a valid number.");
                        textBoxTotalCal.Focus();
                    }
                }
                else
                {
                    MessageBox.Show("Please enter a positive number.");
                    textBoxFatGrams.Focus();
                }
            }
            else
            {
                MessageBox.Show("Please enter a valid number.");
                textBoxFatGrams.Focus();
            }
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBoxFatGrams.Text = "0";
            textBoxTotalCal.Text = "0";
            labelLowFat.Text = "0";
            labelFatPercent.Text = "0%";
            labelFatCalories.Text = "0";
            textBoxTotalCal.Focus();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
