﻿namespace Change_For_a_Dollar_Game
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonExit = new System.Windows.Forms.Button();
            this.buttonClear = new System.Windows.Forms.Button();
            this.buttonCheck = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxPennies = new System.Windows.Forms.TextBox();
            this.textBoxNickles = new System.Windows.Forms.TextBox();
            this.textBoxDimes = new System.Windows.Forms.TextBox();
            this.textBoxQuarters = new System.Windows.Forms.TextBox();
            this.labelResult = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonExit
            // 
            this.buttonExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonExit.Location = new System.Drawing.Point(247, 88);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(95, 32);
            this.buttonExit.TabIndex = 6;
            this.buttonExit.Text = "&Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // buttonClear
            // 
            this.buttonClear.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonClear.Location = new System.Drawing.Point(247, 50);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(95, 32);
            this.buttonClear.TabIndex = 5;
            this.buttonClear.Text = "Clear";
            this.buttonClear.UseVisualStyleBackColor = true;
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // buttonCheck
            // 
            this.buttonCheck.Location = new System.Drawing.Point(247, 12);
            this.buttonCheck.Name = "buttonCheck";
            this.buttonCheck.Size = new System.Drawing.Size(95, 32);
            this.buttonCheck.TabIndex = 4;
            this.buttonCheck.Text = "Check";
            this.buttonCheck.UseVisualStyleBackColor = true;
            this.buttonCheck.Click += new System.EventHandler(this.buttonCheck_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(5, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 20);
            this.label1.TabIndex = 3;
            this.label1.Text = "# of Pennies";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 20);
            this.label2.TabIndex = 4;
            this.label2.Text = "# of Nickles";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(17, 77);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 20);
            this.label3.TabIndex = 5;
            this.label3.Text = "# of Dimes";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(0, 109);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(102, 20);
            this.label4.TabIndex = 6;
            this.label4.Text = "# of Quarters";
            // 
            // textBoxPennies
            // 
            this.textBoxPennies.Location = new System.Drawing.Point(123, 7);
            this.textBoxPennies.Name = "textBoxPennies";
            this.textBoxPennies.Size = new System.Drawing.Size(100, 26);
            this.textBoxPennies.TabIndex = 0;
            this.textBoxPennies.Text = "0";
            // 
            // textBoxNickles
            // 
            this.textBoxNickles.Location = new System.Drawing.Point(123, 39);
            this.textBoxNickles.Name = "textBoxNickles";
            this.textBoxNickles.Size = new System.Drawing.Size(100, 26);
            this.textBoxNickles.TabIndex = 1;
            this.textBoxNickles.Text = "0";
            // 
            // textBoxDimes
            // 
            this.textBoxDimes.Location = new System.Drawing.Point(123, 71);
            this.textBoxDimes.Name = "textBoxDimes";
            this.textBoxDimes.Size = new System.Drawing.Size(100, 26);
            this.textBoxDimes.TabIndex = 2;
            this.textBoxDimes.Text = "0";
            // 
            // textBoxQuarters
            // 
            this.textBoxQuarters.Location = new System.Drawing.Point(123, 103);
            this.textBoxQuarters.Name = "textBoxQuarters";
            this.textBoxQuarters.Size = new System.Drawing.Size(100, 26);
            this.textBoxQuarters.TabIndex = 3;
            this.textBoxQuarters.Text = "0";
            // 
            // labelResult
            // 
            this.labelResult.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelResult.Location = new System.Drawing.Point(4, 143);
            this.labelResult.Name = "labelResult";
            this.labelResult.Size = new System.Drawing.Size(231, 64);
            this.labelResult.TabIndex = 7;
            // 
            // Form1
            // 
            this.AcceptButton = this.buttonCheck;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.buttonClear;
            this.ClientSize = new System.Drawing.Size(351, 223);
            this.Controls.Add(this.labelResult);
            this.Controls.Add(this.textBoxQuarters);
            this.Controls.Add(this.textBoxDimes);
            this.Controls.Add(this.textBoxNickles);
            this.Controls.Add(this.textBoxPennies);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonCheck);
            this.Controls.Add(this.buttonClear);
            this.Controls.Add(this.buttonExit);
            this.Name = "Form1";
            this.Text = "Change For a Dollar";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Button buttonClear;
        private System.Windows.Forms.Button buttonCheck;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxPennies;
        private System.Windows.Forms.TextBox textBoxNickles;
        private System.Windows.Forms.TextBox textBoxDimes;
        private System.Windows.Forms.TextBox textBoxQuarters;
        private System.Windows.Forms.Label labelResult;
    }
}

