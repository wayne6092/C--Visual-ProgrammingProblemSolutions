﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Change_For_a_Dollar_Game
{
    public partial class Form1 : Form
    {

        private const int NICKLE = 5;
        private const int DIME = 10;
        private const int QUARTER = 25;
        private const int DOLLAR = 100;

        public Form1()
        {
            InitializeComponent();
        }

        private void buttonCheck_Click(object sender, EventArgs e)
        {
            decimal pennies;
            decimal nickles;
            decimal dimes;
            decimal quarters;

            if (decimal.TryParse(textBoxPennies.Text, out pennies))
            {
                if(pennies >= 0)
                {
                    if (decimal.TryParse(textBoxNickles.Text, out nickles))
                    {
                        if (nickles >= 0)
                        {
                            decimal nickleResult = nickles * NICKLE;
                            if (decimal.TryParse(textBoxDimes.Text, out dimes))
                            {
                                if (dimes >= 0)
                                {
                                    decimal dimesResult = dimes * DIME;
                                    if (decimal.TryParse(textBoxQuarters.Text, out quarters))
                                    {
                                        if (quarters >= 0)
                                        {
                                            decimal quarterResult = quarters * QUARTER;
                                            decimal finalResult = pennies + nickleResult + dimesResult + quarterResult;
                                            if (finalResult == DOLLAR)
                                            {
                                                labelResult.Text = "Congratulations you did it!!!";
                                            }
                                            else if (finalResult > DOLLAR)
                                            {
                                                labelResult.Text = "This amount is more than a dollar.";
                                            }
                                            else if (finalResult < DOLLAR)
                                            {
                                                labelResult.Text = "This amount is less than a dollar.";
                                            }
                                            textBoxPennies.Focus();
                                        }
                                        else
                                        {
                                            MessageBox.Show("Please enter a positive number.");
                                            textBoxQuarters.Focus();
                                        }
                                    }
                                    else
                                    {
                                        MessageBox.Show("Please enter a valid number.");
                                        textBoxQuarters.Focus();
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Please enter a positive number.");
                                    textBoxDimes.Focus();
                                }
                            }
                            else
                            {
                                MessageBox.Show("Please enter a valid number.");
                                textBoxDimes.Focus();
                            }
                        }
                        else
                        {
                            MessageBox.Show("Please enter a positive number.");
                            textBoxNickles.Focus();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please enter a valid number.");
                        textBoxNickles.Focus();
                    }
                }
                else
                {
                    MessageBox.Show("Please enter a positive number.");
                    textBoxPennies.Focus();
                }
            }
            else
            {
                MessageBox.Show("Please enter a valid number.");
                textBoxPennies.Focus();
            }
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBoxPennies.Text = "0";
            textBoxNickles.Text = "0";
            textBoxDimes.Text = "0";
            textBoxQuarters.Text = "0";
            labelResult.Text = "";
            textBoxPennies.Focus();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
