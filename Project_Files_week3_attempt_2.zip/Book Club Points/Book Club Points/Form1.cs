﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Book_Club_Points
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonCalculate_Click(object sender, EventArgs e)
        {
            int numberOfBooks;
            if (int.TryParse(textBoxBooksBought.Text, out numberOfBooks))
            {
                if(numberOfBooks >= 0)
                {
                    if (numberOfBooks == 0)
                    {
                        labelPointsEarned.Text = "0";
                    }
                    else if (numberOfBooks == 1)
                    {
                        labelPointsEarned.Text = "5";
                    }
                    else if (numberOfBooks == 2)
                    {
                        labelPointsEarned.Text = "15";
                    }
                    else if (numberOfBooks == 3)
                    {
                        labelPointsEarned.Text = "30";
                    }
                    else if (numberOfBooks >= 4)
                    {
                        labelPointsEarned.Text = "60";
                    }
                    else
                    {
                        MessageBox.Show("Please enter number 0 or more!");
                    }
                    textBoxBooksBought.Focus();
                }
                else
                {
                    MessageBox.Show("Books purchased must be 0 or more!");
                    textBoxBooksBought.Focus();
                }
            }
            else
            {
                MessageBox.Show("Please enter a number!");
                textBoxBooksBought.Focus();
            }
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
