﻿namespace Software_Sales
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonExit = new System.Windows.Forms.Button();
            this.buttonCalculate = new System.Windows.Forms.Button();
            this.buttonClear = new System.Windows.Forms.Button();
            this.labelTiltlePackages = new System.Windows.Forms.Label();
            this.labelTitleDiscount = new System.Windows.Forms.Label();
            this.labelDiscount = new System.Windows.Forms.Label();
            this.labelTitleTotal = new System.Windows.Forms.Label();
            this.labelSubTotal = new System.Windows.Forms.Label();
            this.textBoxPackageAmount = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // buttonExit
            // 
            this.buttonExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonExit.Location = new System.Drawing.Point(12, 175);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(87, 40);
            this.buttonExit.TabIndex = 3;
            this.buttonExit.Text = "&Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // buttonCalculate
            // 
            this.buttonCalculate.Location = new System.Drawing.Point(195, 175);
            this.buttonCalculate.Name = "buttonCalculate";
            this.buttonCalculate.Size = new System.Drawing.Size(106, 40);
            this.buttonCalculate.TabIndex = 1;
            this.buttonCalculate.Text = "Calculate";
            this.buttonCalculate.UseVisualStyleBackColor = true;
            this.buttonCalculate.Click += new System.EventHandler(this.buttonCalculate_Click);
            // 
            // buttonClear
            // 
            this.buttonClear.Location = new System.Drawing.Point(102, 175);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(89, 40);
            this.buttonClear.TabIndex = 2;
            this.buttonClear.Text = "Clear";
            this.buttonClear.UseVisualStyleBackColor = true;
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // labelTiltlePackages
            // 
            this.labelTiltlePackages.AutoSize = true;
            this.labelTiltlePackages.Location = new System.Drawing.Point(69, 22);
            this.labelTiltlePackages.Name = "labelTiltlePackages";
            this.labelTiltlePackages.Size = new System.Drawing.Size(110, 20);
            this.labelTiltlePackages.TabIndex = 6;
            this.labelTiltlePackages.Text = "# of Packages";
            // 
            // labelTitleDiscount
            // 
            this.labelTitleDiscount.AutoSize = true;
            this.labelTitleDiscount.Location = new System.Drawing.Point(31, 78);
            this.labelTitleDiscount.Name = "labelTitleDiscount";
            this.labelTitleDiscount.Size = new System.Drawing.Size(148, 20);
            this.labelTitleDiscount.TabIndex = 7;
            this.labelTitleDiscount.Text = "Discount Total (0%)";
            // 
            // labelDiscount
            // 
            this.labelDiscount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelDiscount.Location = new System.Drawing.Point(198, 77);
            this.labelDiscount.Name = "labelDiscount";
            this.labelDiscount.Size = new System.Drawing.Size(100, 23);
            this.labelDiscount.TabIndex = 4;
            this.labelDiscount.Text = "$0.00";
            // 
            // labelTitleTotal
            // 
            this.labelTitleTotal.AutoSize = true;
            this.labelTitleTotal.Location = new System.Drawing.Point(110, 128);
            this.labelTitleTotal.Name = "labelTitleTotal";
            this.labelTitleTotal.Size = new System.Drawing.Size(69, 20);
            this.labelTitleTotal.TabIndex = 8;
            this.labelTitleTotal.Text = "Subtotal";
            // 
            // labelSubTotal
            // 
            this.labelSubTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelSubTotal.Location = new System.Drawing.Point(198, 127);
            this.labelSubTotal.Name = "labelSubTotal";
            this.labelSubTotal.Size = new System.Drawing.Size(100, 23);
            this.labelSubTotal.TabIndex = 5;
            this.labelSubTotal.Text = "$0.00";
            // 
            // textBoxPackageAmount
            // 
            this.textBoxPackageAmount.Location = new System.Drawing.Point(198, 19);
            this.textBoxPackageAmount.Name = "textBoxPackageAmount";
            this.textBoxPackageAmount.Size = new System.Drawing.Size(100, 26);
            this.textBoxPackageAmount.TabIndex = 0;
            this.textBoxPackageAmount.Text = "0";
            // 
            // Form1
            // 
            this.AcceptButton = this.buttonCalculate;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.buttonExit;
            this.ClientSize = new System.Drawing.Size(326, 238);
            this.Controls.Add(this.textBoxPackageAmount);
            this.Controls.Add(this.labelSubTotal);
            this.Controls.Add(this.labelTitleTotal);
            this.Controls.Add(this.labelDiscount);
            this.Controls.Add(this.labelTitleDiscount);
            this.Controls.Add(this.labelTiltlePackages);
            this.Controls.Add(this.buttonClear);
            this.Controls.Add(this.buttonCalculate);
            this.Controls.Add(this.buttonExit);
            this.Name = "Form1";
            this.Text = "Software Sales";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Button buttonCalculate;
        private System.Windows.Forms.Button buttonClear;
        private System.Windows.Forms.Label labelTiltlePackages;
        private System.Windows.Forms.Label labelTitleDiscount;
        private System.Windows.Forms.Label labelDiscount;
        private System.Windows.Forms.Label labelTitleTotal;
        private System.Windows.Forms.Label labelSubTotal;
        private System.Windows.Forms.TextBox textBoxPackageAmount;
    }
}

