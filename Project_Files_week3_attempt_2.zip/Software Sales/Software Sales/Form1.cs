﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Software_Sales
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private const int PACKAGE_PRICE = 90;

        private void buttonCalculate_Click(object sender, EventArgs e)
        {
            int packageAmount;
            if (int.TryParse(textBoxPackageAmount.Text, out packageAmount))
            {
                if (packageAmount >= 0)
                {
                    if (packageAmount >= 1 && packageAmount <= 9)
                    {
                        
                        decimal result = packageAmount * PACKAGE_PRICE;
                        
                        labelTitleDiscount.Text = "Discount Total (0%)";
                        labelDiscount.Text = "0.00";
                        labelSubTotal.Text = result.ToString("c");
                    }

                    else if(packageAmount >=10 && packageAmount <= 19)
                    {
                        decimal discountPercent = 0.2m;
                        decimal result = packageAmount * PACKAGE_PRICE;
                        decimal discount = result * discountPercent;
                        decimal subTotal = result - discount;
                        labelTitleDiscount.Text = "Discount Total (20%)";
                        labelDiscount.Text = discount.ToString("c");
                        labelSubTotal.Text = subTotal.ToString("c");
                    }
                    else if (packageAmount >= 20 && packageAmount <= 49)
                    {
                        decimal discountPercent = 0.3m;
                        decimal result = packageAmount * PACKAGE_PRICE;
                        decimal discount = result * discountPercent;
                        decimal subTotal = result - discount;
                        labelTitleDiscount.Text = "Discount Total (30%)";
                        labelDiscount.Text = discount.ToString("c");
                        labelSubTotal.Text = subTotal.ToString("c");
                    }
                    else if (packageAmount >= 50 && packageAmount <= 99)
                    {
                        decimal discountPercent = 0.4m;
                        decimal result = packageAmount * PACKAGE_PRICE;
                        decimal discount = result * discountPercent;
                        decimal subTotal = result - discount;
                        labelTitleDiscount.Text = "Discount Total (40%)";
                        labelDiscount.Text = discount.ToString("c");
                        labelSubTotal.Text = subTotal.ToString("c");
                    }
                    else if (packageAmount >= 100)
                    {
                        decimal discountPercent = 0.5m;
                        decimal result = packageAmount * PACKAGE_PRICE;
                        decimal discount = result * discountPercent;
                        decimal subTotal = result - discount;
                        labelTitleDiscount.Text = "Discount Total (50%)";
                        labelDiscount.Text = discount.ToString("c");
                        labelSubTotal.Text = subTotal.ToString("c");
                    }
                    
                    else
                    {
                        MessageBox.Show("Please enter valid number!");
                    }
                    textBoxPackageAmount.Focus();
                }
                else
                {
                    MessageBox.Show("Please enter number 0 or more!");
                    textBoxPackageAmount.Focus();
                }
            }
            else
            {
                MessageBox.Show("Please enter number!");
                textBoxPackageAmount.Focus();
            }
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            labelDiscount.Text = "$0.00";
            labelSubTotal.Text = "$0.00";
            labelTitleDiscount.Text = "Discount Total (0%)";
            textBoxPackageAmount.Text = "0";
            textBoxPackageAmount.Focus();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
