﻿namespace Magic_Dates_Revisited
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dateTimePickerMagic = new System.Windows.Forms.DateTimePicker();
            this.labelMagicDate = new System.Windows.Forms.Label();
            this.buttonClear = new System.Windows.Forms.Button();
            this.buttonExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // dateTimePickerMagic
            // 
            this.dateTimePickerMagic.Location = new System.Drawing.Point(139, 12);
            this.dateTimePickerMagic.Name = "dateTimePickerMagic";
            this.dateTimePickerMagic.Size = new System.Drawing.Size(337, 26);
            this.dateTimePickerMagic.TabIndex = 0;
            this.dateTimePickerMagic.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // labelMagicDate
            // 
            this.labelMagicDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelMagicDate.Location = new System.Drawing.Point(139, 56);
            this.labelMagicDate.Name = "labelMagicDate";
            this.labelMagicDate.Size = new System.Drawing.Size(337, 32);
            this.labelMagicDate.TabIndex = 3;
            // 
            // buttonClear
            // 
            this.buttonClear.Location = new System.Drawing.Point(12, 12);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(99, 31);
            this.buttonClear.TabIndex = 1;
            this.buttonClear.Text = "Clear";
            this.buttonClear.UseVisualStyleBackColor = true;
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // buttonExit
            // 
            this.buttonExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonExit.Location = new System.Drawing.Point(12, 57);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(99, 31);
            this.buttonExit.TabIndex = 2;
            this.buttonExit.Text = "&Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // Form1
            // 
            this.AcceptButton = this.buttonClear;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.buttonExit;
            this.ClientSize = new System.Drawing.Size(488, 105);
            this.Controls.Add(this.buttonClear);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.labelMagicDate);
            this.Controls.Add(this.dateTimePickerMagic);
            this.Name = "Form1";
            this.Text = "Magic Dates Revisited";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dateTimePickerMagic;
        private System.Windows.Forms.Label labelMagicDate;
        private System.Windows.Forms.Button buttonClear;
        private System.Windows.Forms.Button buttonExit;
    }
}

