﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Magic_Dates_Revisited
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            try
            {
                DateTime selected = dateTimePickerMagic.Value;
                int day = selected.Day;
                int month = selected.Month;
                string year = selected.Year.ToString();
                int yearTwo = int.Parse(year.Substring(2, 2));
                if (day * month == yearTwo)
                {
                    labelMagicDate.Text = "This is a MAGIC DATE!";
                }
                else
                {
                    labelMagicDate.Text = "This is NOT a magic date.";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Something went wrong." + ex.Message);
            }
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            labelMagicDate.Text = "";
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
