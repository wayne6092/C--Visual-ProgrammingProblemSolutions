﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Time_Clock
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public DateTime currentDateTime;
        public DateTime clockOutTime;
        public TimeSpan tSpan;
        public bool clockedIn = false; //Flag
        private void buttonClockIn_Click(object sender, EventArgs e)
        {
            try
            {
                clockedIn = true; //Turn on clockedIn
                currentDateTime = DateTime.Now;
                buttonClockOut.Focus();
                MessageBox.Show("Clock in time has been reset to start from 00:00:00.00.");
            }
            catch(Exception ex)
            {
                MessageBox.Show("Something went wrong: " + ex.Message);
            }
        }

        
        private void buttonClockOut_Click(object sender, EventArgs e)
        {
            try
            {
                if (clockedIn) // If flag is True
                {
                    clockOutTime = DateTime.Now;
                    TimeSpan tSpan = clockOutTime - currentDateTime;
                    labelTimeWorked.Text = tSpan.ToString();
                    buttonClockIn.Focus();
                    clockedIn = false; // Turn flag off
                }
                else
                {
                    MessageBox.Show("You must clock in before clocking out");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("Something went wrong: " + ex.Message);
            }
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            clockedIn = false;
            labelTimeWorked.Text = "00:00:00.00";
            buttonClockIn.Focus();
        }
    }
}
