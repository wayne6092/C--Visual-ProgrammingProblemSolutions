﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Course_Information
{
    public partial class Form1 : Form
    {
        Dictionary<string, string> courseRoom = new Dictionary<string, string>()
        {
            { "CS101", "3004" }, { "CS102", "4501" },
            { "CS103", "6755" }, { "NT110", "1244" },
            { "CM241", "1411" }
        };

        Dictionary<string, string> courseInstructor = new Dictionary<string, string>()
        {
            { "CS101", "Haynes" }, { "CS102", "Alvarado" },
            { "CS103", "Rich" }, { "NT110", "Burke" },
            { "CM241", "Lee" }
        };

        Dictionary<string, string> courseTimes = new Dictionary<string, string>()
        {
            { "CS101", "8:00 A.M." }, { "CS102", "9:00 A.M." },
            { "CS103", "10:00 A.M." }, { "NT110", "11:00 A.M." },
            { "CM241", "1:00 P.M." }
        };


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            foreach(var course in courseRoom)
            {
                listBoxCourses.Items.Add(course.Key);
            }
        }

        private void buttonGetInfo_Click(object sender, EventArgs e)
        {
            try
            {
                if (listBoxCourses.SelectedItem != null)
                {
                    string courseNum = listBoxCourses.SelectedItem.ToString();

                    listBoxInfo.Items.Clear();

                    //Display Room Number
                    if (courseRoom.ContainsKey(courseNum))
                    {
                        listBoxInfo.Items.Add("Room Number: " + courseRoom[courseNum]);
                    }

                    //Display Instructor
                    if (courseInstructor.ContainsKey(courseNum))
                    {
                        listBoxInfo.Items.Add("Instructor: " + courseInstructor[courseNum]);
                    }

                    //Display Meeting Time
                    if (courseTimes.ContainsKey(courseNum))
                    {
                        listBoxInfo.Items.Add("Meeting Time: " + courseTimes[courseNum]);
                    }
                }
                else
                {
                    MessageBox.Show("Please choose a Course Number.");
                    listBoxCourses.Focus();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Something went wrong: " + ex.Message);
                listBoxCourses.Focus();
            }
        }

        private void buttonReset_Click(object sender, EventArgs e)
        {
            listBoxInfo.Items.Clear();
            buttonGetInfo.Focus();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
