﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Slot_Machine
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public decimal totalSpent = 0;
        public decimal won = 0;
        public decimal insertedAmount;

        private void buttonSpin_Click(object sender, EventArgs e)
        {
            if (decimal.TryParse(textBoxInserted.Text, out insertedAmount) && 
                insertedAmount > 0)
            {
                //Get inserted money, add to total
                totalSpent += insertedAmount;

                //Create random object
                Random rand = new Random();

                //Instantiate variables with random values up to the amount of
                //images in the imageList
                int index1 = rand.Next(imageListFruits.Images.Count);
                int index2 = rand.Next(imageListFruits.Images.Count);
                int index3 = rand.Next(imageListFruits.Images.Count);

                //Assign random indexes to get random fruits from image list to picturebox
                pictureBoxOne.Image = imageListFruits.Images[index1];
                pictureBoxTwo.Image = imageListFruits.Images[index2];
                pictureBoxThree.Image = imageListFruits.Images[index3];

                //If all three match, mutiply money entered by 3
                if(index1 == index2 && index2 == index3)
                {
                    decimal winnings = insertedAmount * 3.0m;
                    MessageBox.Show("You have won: " + winnings.ToString("c"));
                    won += winnings;
                }
                //If any two match, mutiply money entered by 2
                else if (index1 == index2 || index2 == index3 || index1 == index3)
                {
                    decimal winnings = insertedAmount * 2.0m;
                    MessageBox.Show("You have won: " + winnings.ToString("c"));
                    won += winnings;
                }
                //If none match, no money is won
                else
                {
                    MessageBox.Show("You won $0.");
                    textBoxInserted.Focus();
                }
                labelSpent.Text = totalSpent.ToString("c");
                labelWon.Text = won.ToString("c");

                //Determine where the negative symbol needs to go
                if (totalSpent > won)
                {
                    labelResult.Text = "- " + (won - totalSpent).ToString("c");
                }
                else
                {
                    labelResult.Text = (won - totalSpent).ToString("c");
                }
                buttonSpin.Focus();
            }
            else
            {
                MessageBox.Show("You have to PAY to PLAY!");
            }
        }

        private void buttonReset_Click(object sender, EventArgs e)
        {
            textBoxInserted.Text = "";
            labelResult.Text = "";
            labelSpent.Text = "";
            labelWon.Text = "";
            won = 0;
            totalSpent = 0;
            textBoxInserted.Focus();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            //Determine where the negative symbol needs to go
            if(totalSpent > won)
            {
                MessageBox.Show("Your Total Winnings Are: " + "- " + (won - totalSpent).ToString("c"));
                this.Close();
            }
            else
            {
                MessageBox.Show("Your Total Winnings Are: " + (won - totalSpent).ToString("c"));
                this.Close();
            }
            
        }
    }
}
