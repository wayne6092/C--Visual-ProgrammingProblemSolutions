﻿namespace Slot_Machine
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.labelSpent = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.labelWon = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.buttonReset = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonSpin = new System.Windows.Forms.Button();
            this.buttonExit = new System.Windows.Forms.Button();
            this.pictureBoxTwo = new System.Windows.Forms.PictureBox();
            this.pictureBoxOne = new System.Windows.Forms.PictureBox();
            this.pictureBoxThree = new System.Windows.Forms.PictureBox();
            this.imageListFruits = new System.Windows.Forms.ImageList(this.components);
            this.textBoxInserted = new System.Windows.Forms.TextBox();
            this.labelResult = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTwo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOne)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxThree)).BeginInit();
            this.SuspendLayout();
            // 
            // labelSpent
            // 
            this.labelSpent.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelSpent.Location = new System.Drawing.Point(230, 211);
            this.labelSpent.Name = "labelSpent";
            this.labelSpent.Size = new System.Drawing.Size(153, 25);
            this.labelSpent.TabIndex = 23;
            this.labelSpent.Text = "0";
            this.labelSpent.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(116, 213);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(108, 20);
            this.label5.TabIndex = 22;
            this.label5.Text = "Total Spent: $";
            // 
            // labelWon
            // 
            this.labelWon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelWon.Location = new System.Drawing.Point(230, 177);
            this.labelWon.Name = "labelWon";
            this.labelWon.Size = new System.Drawing.Size(153, 25);
            this.labelWon.TabIndex = 21;
            this.labelWon.Text = "0";
            this.labelWon.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(165, 182);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 20);
            this.label3.TabIndex = 20;
            this.label3.Text = "Won: $";
            // 
            // buttonReset
            // 
            this.buttonReset.Location = new System.Drawing.Point(155, 328);
            this.buttonReset.Name = "buttonReset";
            this.buttonReset.Size = new System.Drawing.Size(108, 48);
            this.buttonReset.TabIndex = 2;
            this.buttonReset.Text = "Reset";
            this.buttonReset.UseVisualStyleBackColor = true;
            this.buttonReset.Click += new System.EventHandler(this.buttonReset_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(79, 151);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(145, 20);
            this.label1.TabIndex = 17;
            this.label1.Text = "Amount Inserted: $";
            // 
            // buttonSpin
            // 
            this.buttonSpin.Location = new System.Drawing.Point(334, 328);
            this.buttonSpin.Name = "buttonSpin";
            this.buttonSpin.Size = new System.Drawing.Size(75, 48);
            this.buttonSpin.TabIndex = 1;
            this.buttonSpin.Text = "Spin";
            this.buttonSpin.UseVisualStyleBackColor = true;
            this.buttonSpin.Click += new System.EventHandler(this.buttonSpin_Click);
            // 
            // buttonExit
            // 
            this.buttonExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonExit.Location = new System.Drawing.Point(12, 328);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(87, 48);
            this.buttonExit.TabIndex = 3;
            this.buttonExit.Text = "&Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // pictureBoxTwo
            // 
            this.pictureBoxTwo.Image = global::Slot_Machine.Properties.Resources.Apple;
            this.pictureBoxTwo.Location = new System.Drawing.Point(148, 12);
            this.pictureBoxTwo.Name = "pictureBoxTwo";
            this.pictureBoxTwo.Size = new System.Drawing.Size(127, 129);
            this.pictureBoxTwo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxTwo.TabIndex = 24;
            this.pictureBoxTwo.TabStop = false;
            // 
            // pictureBoxOne
            // 
            this.pictureBoxOne.Image = global::Slot_Machine.Properties.Resources.Banana;
            this.pictureBoxOne.Location = new System.Drawing.Point(12, 12);
            this.pictureBoxOne.Name = "pictureBoxOne";
            this.pictureBoxOne.Size = new System.Drawing.Size(130, 129);
            this.pictureBoxOne.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxOne.TabIndex = 13;
            this.pictureBoxOne.TabStop = false;
            // 
            // pictureBoxThree
            // 
            this.pictureBoxThree.Image = global::Slot_Machine.Properties.Resources.Cherries;
            this.pictureBoxThree.Location = new System.Drawing.Point(281, 12);
            this.pictureBoxThree.Name = "pictureBoxThree";
            this.pictureBoxThree.Size = new System.Drawing.Size(128, 129);
            this.pictureBoxThree.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxThree.TabIndex = 12;
            this.pictureBoxThree.TabStop = false;
            // 
            // imageListFruits
            // 
            this.imageListFruits.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageListFruits.ImageStream")));
            this.imageListFruits.TransparentColor = System.Drawing.Color.Transparent;
            this.imageListFruits.Images.SetKeyName(0, "Apple.bmp");
            this.imageListFruits.Images.SetKeyName(1, "Banana.bmp");
            this.imageListFruits.Images.SetKeyName(2, "Cherries.bmp");
            this.imageListFruits.Images.SetKeyName(3, "Grapes.bmp");
            this.imageListFruits.Images.SetKeyName(4, "Lemon.bmp");
            // 
            // textBoxInserted
            // 
            this.textBoxInserted.Location = new System.Drawing.Point(230, 148);
            this.textBoxInserted.Name = "textBoxInserted";
            this.textBoxInserted.Size = new System.Drawing.Size(153, 26);
            this.textBoxInserted.TabIndex = 0;
            // 
            // labelResult
            // 
            this.labelResult.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelResult.Location = new System.Drawing.Point(230, 279);
            this.labelResult.Name = "labelResult";
            this.labelResult.Size = new System.Drawing.Size(153, 25);
            this.labelResult.TabIndex = 27;
            this.labelResult.Text = "0";
            this.labelResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(47, 284);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(177, 20);
            this.label4.TabIndex = 26;
            this.label4.Text = "Take Home Winnings: $";
            // 
            // Form1
            // 
            this.AcceptButton = this.buttonSpin;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.buttonExit;
            this.ClientSize = new System.Drawing.Size(442, 399);
            this.Controls.Add(this.labelResult);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBoxInserted);
            this.Controls.Add(this.pictureBoxTwo);
            this.Controls.Add(this.labelSpent);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.labelWon);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.buttonReset);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonSpin);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.pictureBoxOne);
            this.Controls.Add(this.pictureBoxThree);
            this.Name = "Form1";
            this.Text = "Slot Machine";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTwo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOne)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxThree)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelSpent;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label labelWon;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button buttonReset;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonSpin;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.PictureBox pictureBoxOne;
        private System.Windows.Forms.PictureBox pictureBoxThree;
        private System.Windows.Forms.PictureBox pictureBoxTwo;
        private System.Windows.Forms.ImageList imageListFruits;
        private System.Windows.Forms.TextBox textBoxInserted;
        private System.Windows.Forms.Label labelResult;
        private System.Windows.Forms.Label label4;
    }
}

