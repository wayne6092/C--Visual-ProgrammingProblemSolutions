﻿namespace Vending_Machine
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel4 = new System.Windows.Forms.Panel();
            this.labelTotalSales = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.labelDrinksLeftGrape = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.labelGrapeCost = new System.Windows.Forms.Label();
            this.pictureBoxGrapeSoda = new System.Windows.Forms.PictureBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.labelDrinksLeftRb = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.labelRBCost = new System.Windows.Forms.Label();
            this.pictureBoxRootBeer = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.labelDrinksLeftCream = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.labelCreamCost = new System.Windows.Forms.Label();
            this.pictureBoxCreamSoda = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.labelDrinksLeftLemon = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.labelLemonCost = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.labelDrinksLeftCola = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.labelColaCost = new System.Windows.Forms.Label();
            this.pictureBoxCola = new System.Windows.Forms.PictureBox();
            this.buttonExit = new System.Windows.Forms.Button();
            this.buttonReset = new System.Windows.Forms.Button();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxGrapeSoda)).BeginInit();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxRootBeer)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCreamSoda)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCola)).BeginInit();
            this.SuspendLayout();
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.labelTotalSales);
            this.panel4.Controls.Add(this.label9);
            this.panel4.Location = new System.Drawing.Point(290, 272);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(272, 124);
            this.panel4.TabIndex = 5;
            // 
            // labelTotalSales
            // 
            this.labelTotalSales.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelTotalSales.Location = new System.Drawing.Point(78, 63);
            this.labelTotalSales.Name = "labelTotalSales";
            this.labelTotalSales.Size = new System.Drawing.Size(101, 35);
            this.labelTotalSales.TabIndex = 3;
            this.labelTotalSales.Text = "$0.00";
            this.labelTotalSales.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(78, 32);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(99, 20);
            this.label9.TabIndex = 2;
            this.label9.Text = "Total Sales";
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.labelDrinksLeftGrape);
            this.panel5.Controls.Add(this.label12);
            this.panel5.Controls.Add(this.labelGrapeCost);
            this.panel5.Controls.Add(this.pictureBoxGrapeSoda);
            this.panel5.Location = new System.Drawing.Point(290, 142);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(272, 124);
            this.panel5.TabIndex = 4;
            // 
            // labelDrinksLeftGrape
            // 
            this.labelDrinksLeftGrape.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelDrinksLeftGrape.Location = new System.Drawing.Point(170, 74);
            this.labelDrinksLeftGrape.Name = "labelDrinksLeftGrape";
            this.labelDrinksLeftGrape.Size = new System.Drawing.Size(51, 35);
            this.labelDrinksLeftGrape.TabIndex = 3;
            this.labelDrinksLeftGrape.Text = "20";
            this.labelDrinksLeftGrape.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(148, 45);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(107, 20);
            this.label12.TabIndex = 2;
            this.label12.Text = "Drinks Left: ";
            // 
            // labelGrapeCost
            // 
            this.labelGrapeCost.AutoSize = true;
            this.labelGrapeCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelGrapeCost.Location = new System.Drawing.Point(166, 15);
            this.labelGrapeCost.Name = "labelGrapeCost";
            this.labelGrapeCost.Size = new System.Drawing.Size(54, 20);
            this.labelGrapeCost.TabIndex = 1;
            this.labelGrapeCost.Text = "$1.50";
            // 
            // pictureBoxGrapeSoda
            // 
            this.pictureBoxGrapeSoda.Image = global::Vending_Machine.Properties.Resources.GrapeSoda;
            this.pictureBoxGrapeSoda.Location = new System.Drawing.Point(14, 15);
            this.pictureBoxGrapeSoda.Name = "pictureBoxGrapeSoda";
            this.pictureBoxGrapeSoda.Size = new System.Drawing.Size(100, 94);
            this.pictureBoxGrapeSoda.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxGrapeSoda.TabIndex = 0;
            this.pictureBoxGrapeSoda.TabStop = false;
            this.pictureBoxGrapeSoda.Click += new System.EventHandler(this.pictureBoxGrapeSoda_Click);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.labelDrinksLeftRb);
            this.panel6.Controls.Add(this.label15);
            this.panel6.Controls.Add(this.labelRBCost);
            this.panel6.Controls.Add(this.pictureBoxRootBeer);
            this.panel6.Location = new System.Drawing.Point(290, 12);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(272, 124);
            this.panel6.TabIndex = 3;
            // 
            // labelDrinksLeftRb
            // 
            this.labelDrinksLeftRb.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelDrinksLeftRb.Location = new System.Drawing.Point(170, 74);
            this.labelDrinksLeftRb.Name = "labelDrinksLeftRb";
            this.labelDrinksLeftRb.Size = new System.Drawing.Size(51, 35);
            this.labelDrinksLeftRb.TabIndex = 3;
            this.labelDrinksLeftRb.Text = "20";
            this.labelDrinksLeftRb.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(148, 45);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(107, 20);
            this.label15.TabIndex = 2;
            this.label15.Text = "Drinks Left: ";
            // 
            // labelRBCost
            // 
            this.labelRBCost.AutoSize = true;
            this.labelRBCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelRBCost.Location = new System.Drawing.Point(166, 15);
            this.labelRBCost.Name = "labelRBCost";
            this.labelRBCost.Size = new System.Drawing.Size(54, 20);
            this.labelRBCost.TabIndex = 1;
            this.labelRBCost.Text = "$1.00";
            // 
            // pictureBoxRootBeer
            // 
            this.pictureBoxRootBeer.Image = global::Vending_Machine.Properties.Resources.RootBeer;
            this.pictureBoxRootBeer.Location = new System.Drawing.Point(14, 15);
            this.pictureBoxRootBeer.Name = "pictureBoxRootBeer";
            this.pictureBoxRootBeer.Size = new System.Drawing.Size(100, 94);
            this.pictureBoxRootBeer.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxRootBeer.TabIndex = 0;
            this.pictureBoxRootBeer.TabStop = false;
            this.pictureBoxRootBeer.Click += new System.EventHandler(this.pictureBoxRootBeer_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.labelDrinksLeftCream);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.labelCreamCost);
            this.panel3.Controls.Add(this.pictureBoxCreamSoda);
            this.panel3.Location = new System.Drawing.Point(12, 272);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(272, 124);
            this.panel3.TabIndex = 2;
            // 
            // labelDrinksLeftCream
            // 
            this.labelDrinksLeftCream.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelDrinksLeftCream.Location = new System.Drawing.Point(170, 74);
            this.labelDrinksLeftCream.Name = "labelDrinksLeftCream";
            this.labelDrinksLeftCream.Size = new System.Drawing.Size(51, 35);
            this.labelDrinksLeftCream.TabIndex = 3;
            this.labelDrinksLeftCream.Text = "20";
            this.labelDrinksLeftCream.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(148, 45);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(107, 20);
            this.label6.TabIndex = 2;
            this.label6.Text = "Drinks Left: ";
            // 
            // labelCreamCost
            // 
            this.labelCreamCost.AutoSize = true;
            this.labelCreamCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCreamCost.Location = new System.Drawing.Point(166, 15);
            this.labelCreamCost.Name = "labelCreamCost";
            this.labelCreamCost.Size = new System.Drawing.Size(54, 20);
            this.labelCreamCost.TabIndex = 1;
            this.labelCreamCost.Text = "$1.50";
            // 
            // pictureBoxCreamSoda
            // 
            this.pictureBoxCreamSoda.Image = global::Vending_Machine.Properties.Resources.CreamSoda;
            this.pictureBoxCreamSoda.Location = new System.Drawing.Point(14, 15);
            this.pictureBoxCreamSoda.Name = "pictureBoxCreamSoda";
            this.pictureBoxCreamSoda.Size = new System.Drawing.Size(100, 94);
            this.pictureBoxCreamSoda.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxCreamSoda.TabIndex = 0;
            this.pictureBoxCreamSoda.TabStop = false;
            this.pictureBoxCreamSoda.Click += new System.EventHandler(this.pictureBoxCreamSoda_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.labelDrinksLeftLemon);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.labelLemonCost);
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Location = new System.Drawing.Point(12, 142);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(272, 124);
            this.panel2.TabIndex = 1;
            // 
            // labelDrinksLeftLemon
            // 
            this.labelDrinksLeftLemon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelDrinksLeftLemon.Location = new System.Drawing.Point(170, 74);
            this.labelDrinksLeftLemon.Name = "labelDrinksLeftLemon";
            this.labelDrinksLeftLemon.Size = new System.Drawing.Size(51, 35);
            this.labelDrinksLeftLemon.TabIndex = 3;
            this.labelDrinksLeftLemon.Text = "20";
            this.labelDrinksLeftLemon.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(148, 45);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(107, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Drinks Left: ";
            // 
            // labelLemonCost
            // 
            this.labelLemonCost.AutoSize = true;
            this.labelLemonCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelLemonCost.Location = new System.Drawing.Point(166, 15);
            this.labelLemonCost.Name = "labelLemonCost";
            this.labelLemonCost.Size = new System.Drawing.Size(54, 20);
            this.labelLemonCost.TabIndex = 1;
            this.labelLemonCost.Text = "$1.00";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Vending_Machine.Properties.Resources.LemonLime;
            this.pictureBox2.Location = new System.Drawing.Point(14, 15);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(100, 94);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.labelDrinksLeftCola);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.labelColaCost);
            this.panel1.Controls.Add(this.pictureBoxCola);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(272, 124);
            this.panel1.TabIndex = 0;
            // 
            // labelDrinksLeftCola
            // 
            this.labelDrinksLeftCola.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelDrinksLeftCola.Location = new System.Drawing.Point(170, 74);
            this.labelDrinksLeftCola.Name = "labelDrinksLeftCola";
            this.labelDrinksLeftCola.Size = new System.Drawing.Size(51, 35);
            this.labelDrinksLeftCola.TabIndex = 3;
            this.labelDrinksLeftCola.Text = "20";
            this.labelDrinksLeftCola.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(148, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Drinks Left: ";
            // 
            // labelColaCost
            // 
            this.labelColaCost.AutoSize = true;
            this.labelColaCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelColaCost.Location = new System.Drawing.Point(166, 15);
            this.labelColaCost.Name = "labelColaCost";
            this.labelColaCost.Size = new System.Drawing.Size(54, 20);
            this.labelColaCost.TabIndex = 1;
            this.labelColaCost.Text = "$1.00";
            // 
            // pictureBoxCola
            // 
            this.pictureBoxCola.Image = global::Vending_Machine.Properties.Resources.Cola;
            this.pictureBoxCola.Location = new System.Drawing.Point(14, 15);
            this.pictureBoxCola.Name = "pictureBoxCola";
            this.pictureBoxCola.Size = new System.Drawing.Size(100, 94);
            this.pictureBoxCola.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxCola.TabIndex = 0;
            this.pictureBoxCola.TabStop = false;
            this.pictureBoxCola.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // buttonExit
            // 
            this.buttonExit.Location = new System.Drawing.Point(87, 402);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(120, 54);
            this.buttonExit.TabIndex = 1;
            this.buttonExit.Text = "&Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // buttonReset
            // 
            this.buttonReset.Location = new System.Drawing.Point(358, 402);
            this.buttonReset.Name = "buttonReset";
            this.buttonReset.Size = new System.Drawing.Size(120, 54);
            this.buttonReset.TabIndex = 0;
            this.buttonReset.Text = "Reset";
            this.buttonReset.UseVisualStyleBackColor = true;
            this.buttonReset.Click += new System.EventHandler(this.buttonReset_Click);
            // 
            // Form1
            // 
            this.AcceptButton = this.buttonReset;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.buttonExit;
            this.ClientSize = new System.Drawing.Size(601, 468);
            this.Controls.Add(this.buttonReset);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Vending Machine";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxGrapeSoda)).EndInit();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxRootBeer)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCreamSoda)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCola)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label labelTotalSales;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label labelDrinksLeftGrape;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label labelGrapeCost;
        private System.Windows.Forms.PictureBox pictureBoxGrapeSoda;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label labelDrinksLeftRb;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label labelRBCost;
        private System.Windows.Forms.PictureBox pictureBoxRootBeer;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label labelDrinksLeftCream;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label labelCreamCost;
        private System.Windows.Forms.PictureBox pictureBoxCreamSoda;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label labelDrinksLeftLemon;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label labelLemonCost;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label labelDrinksLeftCola;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label labelColaCost;
        private System.Windows.Forms.PictureBox pictureBoxCola;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Button buttonReset;
    }
}

