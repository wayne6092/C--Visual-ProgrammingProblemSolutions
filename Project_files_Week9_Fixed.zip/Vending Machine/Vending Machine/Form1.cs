﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vending_Machine
{
    struct VendingMachine
    {
        public string Name;
        public decimal Cost;
        public int Quantity;
    }

    public partial class Form1 : Form
    {
        private List<VendingMachine> drinks = 
            new List<VendingMachine>();
        public Form1()
        {
            InitializeComponent();
        }
        decimal total = 0;
        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                VendingMachine cola = new VendingMachine();
                cola.Name = "Cola";
                cola.Cost = 1.00m;
                cola.Quantity = int.Parse(labelDrinksLeftCola.Text);

                drinks.Add(cola); //index 0

                VendingMachine lemon = new VendingMachine();
                lemon.Name = "Lemon Lime";
                lemon.Cost = 1.00m;
                lemon.Quantity = int.Parse(labelDrinksLeftLemon.Text);

                drinks.Add(lemon); //index 1

                VendingMachine cream = new VendingMachine();
                cream.Name = "Cream Soda";
                cream.Cost = 1.50m;
                cream.Quantity = int.Parse(labelDrinksLeftCream.Text);

                drinks.Add(cream); //index 2

                VendingMachine rbeer = new VendingMachine();
                rbeer.Name = "Root Beer";
                rbeer.Cost = 1.00m;
                rbeer.Quantity = int.Parse(labelDrinksLeftRb.Text);

                drinks.Add(rbeer); //index 3

                VendingMachine grape = new VendingMachine();
                grape.Name = "Grape Soda";
                grape.Cost = 1.50m;
                grape.Quantity = int.Parse(labelDrinksLeftGrape.Text);

                drinks.Add(grape); //index 4
            }
            catch(Exception ex)
            {
                MessageBox.Show("Something went wrong: " + ex.Message);
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e) //Cola
        {
            int newQuant = int.Parse(labelDrinksLeftCola.Text) - 1;
            if (newQuant > -1)
            {
                total += drinks[0].Cost;
                labelDrinksLeftCola.Text = (newQuant).ToString();
                labelTotalSales.Text = total.ToString("c");
            }
            else
            {
                MessageBox.Show("Sold Out!");
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e) //Lemon Lime
        {
            int newQuant = int.Parse(labelDrinksLeftLemon.Text) - 1;
            if (newQuant > -1)
            {
                labelDrinksLeftLemon.Text = (newQuant).ToString();
                total += drinks[1].Cost;
                labelTotalSales.Text = total.ToString("c");
            }
            else
            {
                MessageBox.Show("Sold Out!");
            }
        }

        private void pictureBoxCreamSoda_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(labelDrinksLeftCream.Text) - 1;
            if (newQuant > -1)
            {
                labelDrinksLeftCream.Text = (newQuant).ToString();
                total += drinks[2].Cost;
                labelTotalSales.Text = total.ToString("c");
            }
            else
            {
                MessageBox.Show("Sold Out!");
            }
        }

        private void pictureBoxRootBeer_Click(object sender, EventArgs e)
        {
            int newQuant = int.Parse(labelDrinksLeftRb.Text) - 1;
            if (newQuant > -1)
            {
                labelDrinksLeftRb.Text = (newQuant).ToString();
                total += drinks[3].Cost;
                labelTotalSales.Text = total.ToString("c");
            }
            else
            {
                MessageBox.Show("Sold Out!");
            }
        }

        private void pictureBoxGrapeSoda_Click(object sender, EventArgs e)
        {
            int count = 0;
            count++;
            int newQuant = int.Parse(labelDrinksLeftGrape.Text) - 1;
            if (newQuant > -1)
            {
                labelDrinksLeftGrape.Text = (newQuant).ToString();
                total += drinks[4].Cost;
                labelTotalSales.Text = total.ToString("c");
            }
            else
            {
                MessageBox.Show("Sold Out!");
            }
        }

        private void buttonReset_Click(object sender, EventArgs e)
        {
            labelDrinksLeftCola.Text = "20";
            labelDrinksLeftCream.Text = "20";
            labelDrinksLeftGrape.Text = "20";
            labelDrinksLeftLemon.Text = "20";
            labelDrinksLeftRb.Text = "20";
            labelTotalSales.Text = "$0.00";
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
