﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Weather_Data
{
    struct WeatherData
    {
        public string date;
        public string precipitation;
        public string highTemp;
        public string lowTemp;
    }
    public partial class Form1 : Form
    {
        private List<WeatherData> dataList = 
            new List<WeatherData>();

        public Form1()
        {
            InitializeComponent();
        }

        private void ReadFile()
        {
            try
            {
                StreamReader inputFile; // Read from file
                string line;

                WeatherData entry = new WeatherData();

                char[] delim = { ';' };

                inputFile = File.OpenText("weather.txt");

                while (!inputFile.EndOfStream)
                {
                    //Read a line from the file
                    line = inputFile.ReadLine();

                    //Tokenize the line
                    string[] tokens = line.Split(delim);

                    entry.date = tokens[0];
                    entry.precipitation = tokens[1];
                    entry.highTemp = tokens[2];
                    entry.lowTemp = tokens[3];
                    dataList.Add(entry);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Sorry, something went wrong.");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ReadFile();
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            DateTime selected = dateTimePickerData.Value;
            listBoxData.Items.Clear();
            listBoxData.Items.Add("Date: " + dataList[selected.Day - 1].date);
            listBoxData.Items.Add("Precipitation: " + dataList[selected.Day - 1].precipitation);
            listBoxData.Items.Add("Highest Temperature: " + dataList[selected.Day - 1].highTemp);
            listBoxData.Items.Add("Lowest Temperatue: " + dataList[selected.Day - 1].lowTemp);
            buttonReset.Focus();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonReset_Click(object sender, EventArgs e)
        {
            listBoxData.Items.Clear();
            dateTimePickerData.Focus();
        }
    }
}
