﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prime_Numbers
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private bool IsPrime(int number)
        {
            bool numberIsPrime = true;
            if (number < 2)
            {
                numberIsPrime = false;
            }
            for (int i = 2; i < number - 1; i++)
            {
                if(number % i == 0)
                {
                    numberIsPrime = false ;
                    
                }
            }
            return numberIsPrime;

        }

        private void buttonCheck_Click(object sender, EventArgs e)
        {
            int number;
            if(int.TryParse(textBoxNumber.Text, out number) && number >= 0)
            {
                if (IsPrime(number))
                {
                    labelResult.Text = "Number is a Prime Number";
                }
                else
                {
                    labelResult.Text = "Number is Not a Prime Number";
                }
                textBoxNumber.Focus();
            }
            else
            {
                labelResult.Text = "Please enter a valid number.";
                textBoxNumber.Focus();
            }

            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBoxNumber.Text = "";
            labelResult.Text = "";
            textBoxNumber.Focus();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
