﻿namespace Prime_Number_List
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonClear = new System.Windows.Forms.Button();
            this.buttonDisplayPrimes = new System.Windows.Forms.Button();
            this.buttonExit = new System.Windows.Forms.Button();
            this.listBoxPrime = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.listBoxNonPrime = new System.Windows.Forms.ListBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.labelPrime = new System.Windows.Forms.Label();
            this.labelNonPrime = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonClear
            // 
            this.buttonClear.Location = new System.Drawing.Point(161, 381);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(97, 57);
            this.buttonClear.TabIndex = 1;
            this.buttonClear.Text = "Clear";
            this.buttonClear.UseVisualStyleBackColor = true;
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // buttonDisplayPrimes
            // 
            this.buttonDisplayPrimes.Location = new System.Drawing.Point(278, 381);
            this.buttonDisplayPrimes.Name = "buttonDisplayPrimes";
            this.buttonDisplayPrimes.Size = new System.Drawing.Size(97, 57);
            this.buttonDisplayPrimes.TabIndex = 0;
            this.buttonDisplayPrimes.Text = "Display Primes";
            this.buttonDisplayPrimes.UseVisualStyleBackColor = true;
            this.buttonDisplayPrimes.Click += new System.EventHandler(this.buttonDisplayPrimes_Click);
            // 
            // buttonExit
            // 
            this.buttonExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonExit.Location = new System.Drawing.Point(42, 381);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(101, 57);
            this.buttonExit.TabIndex = 2;
            this.buttonExit.Text = "&Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // listBoxPrime
            // 
            this.listBoxPrime.FormattingEnabled = true;
            this.listBoxPrime.ItemHeight = 20;
            this.listBoxPrime.Location = new System.Drawing.Point(45, 34);
            this.listBoxPrime.Name = "listBoxPrime";
            this.listBoxPrime.Size = new System.Drawing.Size(93, 224);
            this.listBoxPrime.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(172, 20);
            this.label1.TabIndex = 10;
            this.label1.Text = "Prime Numbers (1-100)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(215, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(206, 20);
            this.label2.TabIndex = 9;
            this.label2.Text = "Non-Prime Numbers (1-100)";
            // 
            // listBoxNonPrime
            // 
            this.listBoxNonPrime.FormattingEnabled = true;
            this.listBoxNonPrime.ItemHeight = 20;
            this.listBoxNonPrime.Location = new System.Drawing.Point(266, 34);
            this.listBoxNonPrime.Name = "listBoxNonPrime";
            this.listBoxNonPrime.Size = new System.Drawing.Size(93, 224);
            this.listBoxNonPrime.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(42, 261);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 20);
            this.label3.TabIndex = 8;
            this.label3.Text = "Prime Count";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(248, 261);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(130, 20);
            this.label4.TabIndex = 7;
            this.label4.Text = "Non-Prime Count";
            // 
            // labelPrime
            // 
            this.labelPrime.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelPrime.Location = new System.Drawing.Point(41, 290);
            this.labelPrime.Name = "labelPrime";
            this.labelPrime.Size = new System.Drawing.Size(100, 23);
            this.labelPrime.TabIndex = 6;
            this.labelPrime.Text = "0";
            // 
            // labelNonPrime
            // 
            this.labelNonPrime.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelNonPrime.Location = new System.Drawing.Point(263, 290);
            this.labelNonPrime.Name = "labelNonPrime";
            this.labelNonPrime.Size = new System.Drawing.Size(100, 23);
            this.labelNonPrime.TabIndex = 5;
            this.labelNonPrime.Text = "0";
            // 
            // Form1
            // 
            this.AcceptButton = this.buttonDisplayPrimes;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.buttonExit;
            this.ClientSize = new System.Drawing.Size(424, 450);
            this.Controls.Add(this.labelNonPrime);
            this.Controls.Add(this.labelPrime);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.listBoxNonPrime);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listBoxPrime);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.buttonDisplayPrimes);
            this.Controls.Add(this.buttonClear);
            this.Name = "Form1";
            this.Text = "Prime Number List";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonClear;
        private System.Windows.Forms.Button buttonDisplayPrimes;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.ListBox listBoxPrime;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListBox listBoxNonPrime;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label labelPrime;
        private System.Windows.Forms.Label labelNonPrime;
    }
}

