﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prime_Number_List
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private bool IsPrime(int number)
        {
            bool numberIsPrime = true;
            if (number < 2)
            {
                numberIsPrime = false;
            }
            for (int i = 2; i < number - 1; i++)
            {
                if (number % i == 0)
                {
                    numberIsPrime = false;

                }
            }
            return numberIsPrime;

        }

        private void buttonDisplayPrimes_Click(object sender, EventArgs e)
        {
            int countPrime = 0;
            int countNonPrime = 0;
            int number;
            for(number = 0; number <= 100; number++)
            {
                if (IsPrime(number))
                {
                    listBoxPrime.Items.Add(number);
                    countPrime++;
                }
                else
                {
                    listBoxNonPrime.Items.Add(number);
                    countNonPrime++;
                }
                labelPrime.Text = countPrime.ToString();
                labelNonPrime.Text = countNonPrime.ToString();
                buttonDisplayPrimes.Focus();
            }
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            listBoxNonPrime.Items.Clear();
            listBoxPrime.Items.Clear();
            labelNonPrime.Text = "0";
            labelPrime.Text = "0";
            buttonDisplayPrimes.Focus();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
