﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Drivers_License_Exam
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            int correctNum = 0;
            int incorrectNum = 0;
            const int SIZE = 20;
            int index = 0;
            int index2 = 0;
           
            
            const int TOPASS = 15;

            string[] correctGrades = 
                {"B","D", "A", "A", "C", "A", "B", 
                "A", "C", "D", "B", "C", "D", "A", 
                "D", "C", "C", "B", "D", "A"
            };

            //Array to hold the sales amounts
            string[] studentGrades = new string[SIZE];
            try
            {
                //Open file
                StreamReader inputFile = File.OpenText("answers1.txt");
                //Read the contents of the file into the array
                while (!inputFile.EndOfStream && index < studentGrades.Length)
                {
                    studentGrades[index] = inputFile.ReadLine();
                    index++;
                }
                inputFile.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Cannot find file.");
                studentGrades = new string[SIZE]
                {   
                    "D","A","B","C","C","C","A","A","C","D","B",
                    "B","D","A","B","A","C","B","D","C"
                };
            }

            //Compare Arrays
            while(index2 < correctGrades.Length)
            {
                
                if (correctGrades[index2] == studentGrades[index2])
                {
                    //Count correct answers
                    correctNum++;
                }
                else
                {
                    //Count incorrect answers
                    incorrectNum++;
                }
                index2++;
            }

            //Display if Pass, incorrect/correct number of answers to questions
            labelCorrect.Text = correctNum.ToString();
            labelIncorrect.Text = incorrectNum.ToString();
            
            if (correctNum >= TOPASS)
            {
                labelResult.Text = "PASSED!";
            }
            else
            {
                labelResult.Text = "FAILED!";
            }
            

        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
