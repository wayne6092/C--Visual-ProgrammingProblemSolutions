﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Name_Search
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private int SequentialSearch(string[] sArray, string value)
        {
            int indexThree = 0;       // Used to step through the array
            int position = -1;   // Position of value, if found->position > 0;
            bool found = false;

            while (!found && indexThree < sArray.Length)
            {
                if (sArray[indexThree] == value)
                {
                    position = indexThree;
                    found = true;
                }
                indexThree++;
            }
            return position;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //Constants for array size
            const int SIZE = 200;

            string[] boys = new string[SIZE]; //Array 1

            string[] girls = new string[SIZE]; //Array 2
            string boyName = textBoxBoys.Text;
            string girlName = textBoxGirls.Text;

            int index = 0;  //To step through array 1
            int indexTwo = 0; //To step through array 2
            try
            {
                //Open file
                StreamReader inputFile = File.OpenText("BoyNames.txt");

                //Read the contents of the file into the array
                while (!inputFile.EndOfStream && index < boys.Length)
                {
                    boys[index] = inputFile.ReadLine();
                    index++;

                }
                inputFile.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Cannot find file.");
            }
            foreach (string b in boys)
            {
                listBoxBoys.Items.Add(b);
            }

            try
            {
                StreamReader inputFileTwo = File.OpenText("GirlNames.txt");
                while (!inputFileTwo.EndOfStream && indexTwo < girls.Length)
                {
                    girls[indexTwo] = inputFileTwo.ReadLine();
                    indexTwo++;
                }
                inputFileTwo.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Cannot find WorldSeries.txt");
            }

            foreach (string g in girls)
            {
                listBoxGirls.Items.Add(g);
            }

            if (girlName != "" && boyName != "")
            {
                //Sequential search flags whether the name is popular or not
                //Nested if loops to determine posibilities
                if (SequentialSearch(girls, girlName) != -1 && SequentialSearch(boys, boyName) != -1)
                {
                    labelResult.Text = "Both names are Popular.";
                }
                else if (SequentialSearch(girls, girlName) != -1 && SequentialSearch(boys, boyName) == -1)
                {
                    labelResult.Text = "Girl name is Popular. Boy name is not.";
                }
                else if (SequentialSearch(girls, girlName) == -1 && SequentialSearch(boys, boyName) != -1)
                {
                    labelResult.Text = "Boy name is Popular. Girl name is not.";
                }
                else if (SequentialSearch(girls, girlName) == -1 && SequentialSearch(boys, boyName) == -1)
                {
                    labelResult.Text = "Neither boy name or girl name is popular.";
                }
                textBoxBoys.Focus();
            }


            else if (boyName != "")
            {
                if (SequentialSearch(boys, boyName) != -1)
                {
                    labelResult.Text = "Boy name is Popular.";
                }
                else
                {
                    labelResult.Text = "Boy name is not Popular.";
                }
                textBoxBoys.Focus();
            }
            else if (girlName != "")
            {
                if (SequentialSearch(girls, girlName) != -1)
                {
                    labelResult.Text = "Girl name is Popular.";
                }
                else
                {
                    labelResult.Text = "Girl name is not Popular.";
                }
                textBoxGirls.Focus();
            }
            else if(girlName == "" || boyName == "")
            {
                labelResult.Text = "Missing Info.";
            }
            textBoxBoys.Focus();
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBoxBoys.Text = "";
            textBoxGirls.Text = "";
            labelResult.Text = "";
            textBoxBoys.Focus();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
