﻿namespace Name_Search
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonExit = new System.Windows.Forms.Button();
            this.buttonClear = new System.Windows.Forms.Button();
            this.buttonCheck = new System.Windows.Forms.Button();
            this.listBoxGirls = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxGirls = new System.Windows.Forms.TextBox();
            this.textBoxBoys = new System.Windows.Forms.TextBox();
            this.labelResult = new System.Windows.Forms.Label();
            this.listBoxBoys = new System.Windows.Forms.ListBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonExit
            // 
            this.buttonExit.Location = new System.Drawing.Point(50, 340);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(83, 53);
            this.buttonExit.TabIndex = 4;
            this.buttonExit.Text = "&Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // buttonClear
            // 
            this.buttonClear.Location = new System.Drawing.Point(139, 340);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(84, 53);
            this.buttonClear.TabIndex = 3;
            this.buttonClear.Text = "Clear";
            this.buttonClear.UseVisualStyleBackColor = true;
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // buttonCheck
            // 
            this.buttonCheck.Location = new System.Drawing.Point(229, 340);
            this.buttonCheck.Name = "buttonCheck";
            this.buttonCheck.Size = new System.Drawing.Size(110, 53);
            this.buttonCheck.TabIndex = 2;
            this.buttonCheck.Text = "Check Name(s)";
            this.buttonCheck.UseVisualStyleBackColor = true;
            this.buttonCheck.Click += new System.EventHandler(this.button3_Click);
            // 
            // listBoxGirls
            // 
            this.listBoxGirls.FormattingEnabled = true;
            this.listBoxGirls.ItemHeight = 20;
            this.listBoxGirls.Location = new System.Drawing.Point(194, 55);
            this.listBoxGirls.Name = "listBoxGirls";
            this.listBoxGirls.Size = new System.Drawing.Size(154, 84);
            this.listBoxGirls.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(66, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 20);
            this.label2.TabIndex = 6;
            this.label2.Text = "Boys";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.listBoxBoys);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.listBoxGirls);
            this.groupBox1.Location = new System.Drawing.Point(14, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(364, 181);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Popular Names";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(244, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 20);
            this.label1.TabIndex = 8;
            this.label1.Text = "Girls";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(46, 247);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(130, 20);
            this.label3.TabIndex = 6;
            this.label3.Text = "Enter Girls Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(46, 207);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(133, 20);
            this.label4.TabIndex = 7;
            this.label4.Text = "Enter Boys Name";
            // 
            // textBoxGirls
            // 
            this.textBoxGirls.Location = new System.Drawing.Point(208, 244);
            this.textBoxGirls.Name = "textBoxGirls";
            this.textBoxGirls.Size = new System.Drawing.Size(131, 26);
            this.textBoxGirls.TabIndex = 1;
            // 
            // textBoxBoys
            // 
            this.textBoxBoys.Location = new System.Drawing.Point(208, 204);
            this.textBoxBoys.Name = "textBoxBoys";
            this.textBoxBoys.Size = new System.Drawing.Size(131, 26);
            this.textBoxBoys.TabIndex = 0;
            // 
            // labelResult
            // 
            this.labelResult.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelResult.Location = new System.Drawing.Point(14, 288);
            this.labelResult.Name = "labelResult";
            this.labelResult.Size = new System.Drawing.Size(366, 31);
            this.labelResult.TabIndex = 5;
            // 
            // listBoxBoys
            // 
            this.listBoxBoys.FormattingEnabled = true;
            this.listBoxBoys.ItemHeight = 20;
            this.listBoxBoys.Location = new System.Drawing.Point(20, 55);
            this.listBoxBoys.Name = "listBoxBoys";
            this.listBoxBoys.Size = new System.Drawing.Size(154, 84);
            this.listBoxBoys.TabIndex = 7;
            // 
            // Form1
            // 
            this.AcceptButton = this.buttonCheck;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.buttonExit;
            this.ClientSize = new System.Drawing.Size(392, 450);
            this.Controls.Add(this.labelResult);
            this.Controls.Add(this.textBoxBoys);
            this.Controls.Add(this.textBoxGirls);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.buttonCheck);
            this.Controls.Add(this.buttonClear);
            this.Controls.Add(this.buttonExit);
            this.Name = "Form1";
            this.Text = "Name Search";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Button buttonClear;
        private System.Windows.Forms.Button buttonCheck;
        private System.Windows.Forms.ListBox listBoxGirls;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxGirls;
        private System.Windows.Forms.TextBox textBoxBoys;
        private System.Windows.Forms.Label labelResult;
        private System.Windows.Forms.ListBox listBoxBoys;
    }
}

