﻿namespace World_Series_Champions
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBoxTeams = new System.Windows.Forms.ListBox();
            this.buttonExit = new System.Windows.Forms.Button();
            this.buttonOk = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.labelWins = new System.Windows.Forms.Label();
            this.listBoxSeriesWins = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // listBoxTeams
            // 
            this.listBoxTeams.FormattingEnabled = true;
            this.listBoxTeams.ItemHeight = 20;
            this.listBoxTeams.Location = new System.Drawing.Point(19, 35);
            this.listBoxTeams.Name = "listBoxTeams";
            this.listBoxTeams.Size = new System.Drawing.Size(288, 184);
            this.listBoxTeams.TabIndex = 0;
            // 
            // buttonExit
            // 
            this.buttonExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonExit.Location = new System.Drawing.Point(19, 364);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(116, 52);
            this.buttonExit.TabIndex = 2;
            this.buttonExit.Text = "&Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // buttonOk
            // 
            this.buttonOk.Location = new System.Drawing.Point(183, 364);
            this.buttonOk.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonOk.Name = "buttonOk";
            this.buttonOk.Size = new System.Drawing.Size(124, 52);
            this.buttonOk.TabIndex = 1;
            this.buttonOk.Text = "Check Wins";
            this.buttonOk.UseVisualStyleBackColor = true;
            this.buttonOk.Click += new System.EventHandler(this.buttonOk_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(43, 242);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(122, 20);
            this.label1.TabIndex = 4;
            this.label1.Text = "Number of Wins";
            // 
            // labelWins
            // 
            this.labelWins.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelWins.Location = new System.Drawing.Point(183, 242);
            this.labelWins.Name = "labelWins";
            this.labelWins.Size = new System.Drawing.Size(100, 23);
            this.labelWins.TabIndex = 3;
            this.labelWins.Text = "0";
            // 
            // listBoxSeriesWins
            // 
            this.listBoxSeriesWins.FormattingEnabled = true;
            this.listBoxSeriesWins.ItemHeight = 20;
            this.listBoxSeriesWins.Location = new System.Drawing.Point(342, 32);
            this.listBoxSeriesWins.Name = "listBoxSeriesWins";
            this.listBoxSeriesWins.Size = new System.Drawing.Size(246, 384);
            this.listBoxSeriesWins.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(338, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(252, 20);
            this.label2.TabIndex = 5;
            this.label2.Text = "World Series Winners (1903-2012)";
            // 
            // Form1
            // 
            this.AcceptButton = this.buttonOk;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.buttonExit;
            this.ClientSize = new System.Drawing.Size(600, 450);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.listBoxSeriesWins);
            this.Controls.Add(this.labelWins);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonOk);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.listBoxTeams);
            this.Name = "Form1";
            this.Text = "World Series Champions";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBoxTeams;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Button buttonOk;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelWins;
        private System.Windows.Forms.ListBox listBoxSeriesWins;
        private System.Windows.Forms.Label label2;
    }
}

