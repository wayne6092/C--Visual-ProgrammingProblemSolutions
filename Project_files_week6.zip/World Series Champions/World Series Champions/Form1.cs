﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace World_Series_Champions
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private int SequentialSearch(string[] sArray, string value)
        {
            int indexThree = 0;       // Used to step through the array
            int position = -1;   // Position of value, if found
            int wins = 0;

            while (indexThree < sArray.Length)
            {
                if (sArray[indexThree] == value)
                {
                    position = indexThree;
                    wins++;
                }

                indexThree++;
            }
            return wins;
         
        }


        private void buttonOk_Click(object sender, EventArgs e)
        {
            const int SIZE = 28;
            const int SIZETWO = 104;
            string[] teams = new string[SIZE]; //Array 1
            string[] seriesWins = new string[SIZETWO]; //Array 2
            int index = 0;  //To step through array 1
            int indexTwo = 0; //To step through array 2
            string selection; //Hold users listBox selection

            try
            {
                //Open file
                StreamReader inputFile = File.OpenText("Teams.txt");

                //Read the contents of the file into the array
                while (!inputFile.EndOfStream && index < teams.Length)
                {
                    teams[index] = inputFile.ReadLine();
                    index++;
                 
                }
                inputFile.Close();

                
            }
            catch (Exception)
            {
                MessageBox.Show("Cannot find file.");
                teams = new string[SIZE]
                {
                    "Anaheim Angels", "Arizona Diamondbacks", "Atlanta BravesBaltimore", 
                    "Orioles", "Boston Americans", "Boston Braves", "Boston Red Sox", 
                    "Brooklyn Dodgers", "Chicago Cubs", "Chicago White Sox", "Cincinnati Reds",
                    "Cleveland Indians", "Detroit Tigers", "Florida Marlins", "Kansas City Royals",
                    "Los Angeles Dodgers", "Milwaukee Braves", "Minnesota Twins", "New York Giants", 
                    "New York Mets", "New York Yankees", "Oakland Athletics", "Philadelphia Athletics", 
                    "Philadelphia Phillies", "Pittsburgh Pirates", "St. Louis Cardinals", "Toronto Blue Jays", 
                    "Washington Senators"
                };
            }
            foreach (string team in teams)
            {
                listBoxTeams.Items.Add(team);
            }
            try
            {
                StreamReader inputFileTwo = File.OpenText("WorldSeries.txt");
                while (!inputFileTwo.EndOfStream && indexTwo < seriesWins.Length)
                {
                    seriesWins[indexTwo] = inputFileTwo.ReadLine();
                    indexTwo++;
                }
                inputFileTwo.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Cannot find WorldSeries.txt");
            }
            foreach (string wins in seriesWins)
            {
                listBoxSeriesWins.Items.Add(wins);
            }

            if (listBoxTeams.SelectedIndex != -1)
            {
                selection = listBoxTeams.SelectedItem.ToString();

                int wins = SequentialSearch(seriesWins, selection);
                labelWins.Text = wins.ToString();
            }
            else
            {
                MessageBox.Show("Please select a team.");
            }
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
