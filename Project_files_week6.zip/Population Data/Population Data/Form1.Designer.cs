﻿namespace Population_Data
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonExit = new System.Windows.Forms.Button();
            this.listBoxPopulation = new System.Windows.Forms.ListBox();
            this.labelLowest = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.labelHighest = new System.Windows.Forms.Label();
            this.labelAverage = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.listBoxIncreases = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.labelGreatestYear = new System.Windows.Forms.Label();
            this.labelLowestYear = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonExit
            // 
            this.buttonExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonExit.Location = new System.Drawing.Point(16, 395);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(191, 43);
            this.buttonExit.TabIndex = 4;
            this.buttonExit.Text = "&Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // listBoxPopulation
            // 
            this.listBoxPopulation.FormattingEnabled = true;
            this.listBoxPopulation.ItemHeight = 20;
            this.listBoxPopulation.Location = new System.Drawing.Point(16, 12);
            this.listBoxPopulation.Name = "listBoxPopulation";
            this.listBoxPopulation.Size = new System.Drawing.Size(242, 204);
            this.listBoxPopulation.TabIndex = 5;
            // 
            // labelLowest
            // 
            this.labelLowest.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelLowest.Location = new System.Drawing.Point(220, 326);
            this.labelLowest.Name = "labelLowest";
            this.labelLowest.Size = new System.Drawing.Size(100, 23);
            this.labelLowest.TabIndex = 6;
            this.labelLowest.Text = "0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(20, 237);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(182, 20);
            this.label2.TabIndex = 7;
            this.label2.Text = "Average Annual Change";
            // 
            // labelHighest
            // 
            this.labelHighest.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelHighest.Location = new System.Drawing.Point(220, 283);
            this.labelHighest.Name = "labelHighest";
            this.labelHighest.Size = new System.Drawing.Size(100, 23);
            this.labelHighest.TabIndex = 8;
            this.labelHighest.Text = "0";
            // 
            // labelAverage
            // 
            this.labelAverage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelAverage.Location = new System.Drawing.Point(220, 237);
            this.labelAverage.Name = "labelAverage";
            this.labelAverage.Size = new System.Drawing.Size(100, 23);
            this.labelAverage.TabIndex = 9;
            this.labelAverage.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(55, 327);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(147, 20);
            this.label5.TabIndex = 10;
            this.label5.Text = "Least Pop Increase";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(32, 284);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(170, 20);
            this.label6.TabIndex = 11;
            this.label6.Text = "Greatest Pop Increase";
            // 
            // listBoxIncreases
            // 
            this.listBoxIncreases.FormattingEnabled = true;
            this.listBoxIncreases.ItemHeight = 20;
            this.listBoxIncreases.Location = new System.Drawing.Point(264, 12);
            this.listBoxIncreases.Name = "listBoxIncreases";
            this.listBoxIncreases.Size = new System.Drawing.Size(282, 204);
            this.listBoxIncreases.TabIndex = 12;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(326, 329);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 20);
            this.label1.TabIndex = 13;
            this.label1.Text = "Year";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(326, 283);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 20);
            this.label3.TabIndex = 14;
            this.label3.Text = "Year";
            // 
            // labelGreatestYear
            // 
            this.labelGreatestYear.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelGreatestYear.Location = new System.Drawing.Point(375, 283);
            this.labelGreatestYear.Name = "labelGreatestYear";
            this.labelGreatestYear.Size = new System.Drawing.Size(100, 23);
            this.labelGreatestYear.TabIndex = 16;
            this.labelGreatestYear.Text = "0";
            // 
            // labelLowestYear
            // 
            this.labelLowestYear.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelLowestYear.Location = new System.Drawing.Point(375, 327);
            this.labelLowestYear.Name = "labelLowestYear";
            this.labelLowestYear.Size = new System.Drawing.Size(100, 23);
            this.labelLowestYear.TabIndex = 15;
            this.labelLowestYear.Text = "0";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(558, 450);
            this.Controls.Add(this.labelGreatestYear);
            this.Controls.Add(this.labelLowestYear);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listBoxIncreases);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.labelAverage);
            this.Controls.Add(this.labelHighest);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.labelLowest);
            this.Controls.Add(this.listBoxPopulation);
            this.Controls.Add(this.buttonExit);
            this.Name = "Form1";
            this.Text = "Population Data";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.ListBox listBoxPopulation;
        private System.Windows.Forms.Label labelLowest;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label labelHighest;
        private System.Windows.Forms.Label labelAverage;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ListBox listBoxIncreases;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label labelGreatestYear;
        private System.Windows.Forms.Label labelLowestYear;
    }
}

