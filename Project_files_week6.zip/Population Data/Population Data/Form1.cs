﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Population_Data
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private double Average(int[] iArray)
        {
            int total = 0;
            double average;

            for(int index = 0; index < iArray.Length; index++)
            {
                total += iArray[index];
            }
            average = (double) total / iArray.Length;

            return average;
        }

        private int Highest(int[] iArray)
        {
            //Start-this is the highest so far
            int highest = iArray[0];

            //loop to step through values of array
            for(int index = 1; index < iArray.Length; index++)
            {
                if (iArray[index] > highest)
                {
                    highest = iArray[index];
                }
            }
            return highest;
        }

        private int Lowest(int[] iArray)
        {
            int lowest = iArray[0];
            
            for(int index = 1; index < iArray.Length; index++)
            {
                if (iArray[index] < lowest)
                {
                    lowest = iArray[index];
                }
                index++;
            }
            
            return lowest;
        }

        private int SequentialSearch(int[] iArray, int value)
        {
            int year = 1951;
            int index = 0;
            bool found = false;
            int position = 0;
            while(!found && index < iArray.Length)
            {
                if(iArray[index] == value)
                {
                    position = year;
                    found = true;
                }
                index++;
                year++;
            }
            return position;
        }
        

        private void Form1_Load(object sender, EventArgs e)
        {
            const int SIZE = 41; //Number of populations per year
            const int SIZETWO = 40; //Number of population increase per year (Excludes 1950)
            int index = 0; //To step through array
            double average;
            int highest;
            int lowest;
            int year = 1950;
            int lowYear;
            int highYear;

            //Array to hold the sales amounts
            int[] popPerYear = new int[SIZE];
            int[] popIncreases = new int[SIZETWO];

            try
            {
                //Open file
                StreamReader inputFile = File.OpenText("USPopulation.txt");
                //Read the contents of the file into the array
                while (!inputFile.EndOfStream && index < popPerYear.Length)
                {
                    popPerYear[index] = int.Parse(inputFile.ReadLine());
                    index++;
                }
                inputFile.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Cannot find file.");
            }

            //Display the array elements in the ListBox
            for (int pop = 0; pop < popPerYear.Length; pop++)
            {
                listBoxPopulation.Items.Add(year + " Population: " + popPerYear[pop].ToString());
                //Year is decorative
                year++;
            }

            
            year = 1950;//Restart the years

            //Loop counter AND used for subtraction
            int count = 1;

            //Counter for subtraction
            int count2 = 0;

            //Create population difference array
            //Loop starts at second year, because there is no pop increase for first year
            while (count < popPerYear.Length)
            {
                //Year is Decorative, placed first because we skip 1950
                year++;

                //Subtract population between years to find increase
                //popIncrease = Year1 - Year2
                popIncreases[count2] = popPerYear[count] - popPerYear[count2];

                //Display in listBox (Optional)
                listBoxIncreases.Items.Add("Year: " + year + " Pop-Increase: " + popIncreases[count2]);
                count++;
                count2++;
            }


            //Get Average, Highest and Lowest
            //Calling Average, Lowest, and Highest methods
            average = Average(popIncreases);
            lowest = Lowest(popIncreases);
            highest = Highest(popIncreases);

            //Display the Values
            labelAverage.Text = average.ToString();
            labelLowest.Text = lowest.ToString();
            labelHighest.Text = highest.ToString();

            //Get year for highest/lowest pop increase
            //Calling SequentialSearch method
            lowYear = SequentialSearch(popIncreases, lowest);
            highYear = SequentialSearch(popIncreases, highest);

            //Display lowYear and highYear
            labelGreatestYear.Text = highYear.ToString();
            labelLowestYear.Text = lowYear.ToString();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
