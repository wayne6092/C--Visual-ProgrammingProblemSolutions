﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Charge_Account_Validation_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonCheck_Click(object sender, EventArgs e)
        {
            const int SIZE = 18;
            int[] numbers = new int[SIZE];
            int index = 0;//To step through array

            try
            {
                //Open file
                StreamReader inputFile = File.OpenText("ChargeAccounts.txt");

                //Read the contents of the file into the array
                while (!inputFile.EndOfStream && index < numbers.Length)
                {
                    numbers[index] = int.Parse(inputFile.ReadLine());
                    index++;
                }
                inputFile.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Cannot find file.");
                numbers = new int[SIZE]
                {
                    5658845, 4520125, 7895122, 8777541, 8451277, 1302850, 8080152,
                    4562555, 5552012, 5050552, 7825877, 1250255, 1005231, 6545231,
                    3852085, 7576651, 7881200, 4581002
                };
            }

            if (int.TryParse(textBoxNumber.Text, out int numberValue) && numberValue > 999999
                && numberValue < 10000000)
            {
                //Display the array elements in the ListBox
                foreach (int n in numbers)
                {
                    if (n == numberValue)
                    {
                        labelResult.Text = "*******Valid*******";
                        break;
                    }
                    else
                    {
                        labelResult.Text = "**Charge Account Number is Not Valid**";
                    }
                }
                textBoxNumber.Focus();
            }
            else
            {
                MessageBox.Show("Please Enter a valid Charge Account Number!");
                textBoxNumber.Focus();
            }

        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBoxNumber.Text = "0000000";
            labelResult.Text = "";
            textBoxNumber.Focus();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
