﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;

namespace Tic_Tac_Toe_Simulator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonNewGame_Click(object sender, EventArgs e)
        {
            const int ROWS = 3;
            const int COLS = 3;
            int[,]values = new int[ROWS, COLS];
            int countY = 0;
            int countX = 0;

            Random rand = new Random();

            for(int row = 0; row < ROWS; row++)
            {
                for(int col = 0; col < COLS; col++)
                {
                    values[row, col] = rand.Next(2);
                }

            }
            //Check board for winner/loser/tie
            //check rows
            for(int row = 0; row < ROWS; row++)
            {
                if (values[row, 0] == values[row, 1] 
                    && values[row, 0] == values[row, 2])
                {
                    if(values[row, 0] == 0)
                    {
                        countY = 1;
                    }
                    else
                    {
                        countX = 1;
                    }
                }
            }
            //Check Columns
            for(int col = 0; col < COLS; col++)
            {
                if (values[0, col] == values[1, col] 
                    && values[1, col] == values[2, col])
                {
                    if (values[1, col] == 0)
                    {
                        countY = 1;
                    }
                    else
                    {
                        countX = 1;
                    }

                }
            }
            //Check Diagnals
            if (values[0,0] == values[1,1]
                && values[0,0] == values[2, 2])
            {
                if (values[0,0] == 0)
                {
                    countY = 1;
                }
                else
                {
                    countX = 1;
                }
            }

            if (values[0,2] == values[1,1] 
                && values[0,2] == values[2, 0])
            {
                if(values[0,2] == 0)
                {
                    countY = 1;
                }
                else
                {
                    countX = 1;
                }
               
            }
            //Display winner 

            if(countY == 1 && countX == 1)
            {
                labelResult.Text = "The Game Is A TIE!";
            }
            else if(countY == 1 && countX == 0)
            {
                labelResult.Text = "Player Y is the Winner!";
            }
            else if(countX == 1 && countY == 0)
            {
                labelResult.Text = "Player X is the Winner!";
            }
            else
            {
                labelResult.Text = "The Game Is A TIE!";
            }



            // Row 0 column 0
            if (values[0,0] == 0)
            {
                label1.Text = "O";
            }
            else
            {
                label1.Text = "X";
            }

            // Row 0 column 1
            if (values[0, 1] == 0)
            {
                label2.Text = "O";
            }
            else
            {
                label2.Text = "X";
            }

            // Row 0 column 2
            if (values[0, 2] == 0)
            {
                label3.Text = "O";
            }
            else
            {
                label3.Text = "X";
            }

            // Row 1 column 0
            if (values[1, 0] == 0)
            {
                label4.Text = "O";
            }
            else
            {
                label4.Text = "X";
            }

            // Row 1 column 1
            if (values[1, 1] == 0)
            {
                label5.Text = "O";
            }
            else
            {
                label5.Text = "X";
            }

            // Row 1 column 2
            if (values[1, 2] == 0)
            {
                label6.Text = "O";
            }
            else
            {
                label6.Text = "X";
            }
            // Row 2 column 0
            if (values[2, 0] == 0)
            {
                label7.Text = "O";
            }
            else
            {
                label7.Text = "X";
            }

            // Row 2 column 1
            if (values[2, 1] == 0)
            {
                label8.Text = "O";
            }
            else
            {
                label8.Text = "X";
            }
            // Row 2 column 2
            if (values[2, 2] == 0)
            {
                label9.Text = "O";
            }
            else
            {
                label9.Text = "X";
            }
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
