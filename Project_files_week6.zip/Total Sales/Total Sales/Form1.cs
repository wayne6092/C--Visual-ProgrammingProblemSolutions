﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Total_Sales
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            const int SIZE = 7; //Number of sales amounts
            int index = 0;      //To step through array
            decimal total = 0m; //Accumualator for sales amounts

            //Array to hold the sales amounts
            decimal[] sales = new decimal[SIZE];
            try
            {
                //Open file
                StreamReader inputFile = File.OpenText("Sales.txt");
                //Read the contents of the file into the array
                while (!inputFile.EndOfStream && index < sales.Length)
                {
                    sales[index] = decimal.Parse(inputFile.ReadLine());
                    index++;
                }
                inputFile.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show("Cannot find file.");
                sales = new decimal[SIZE]
                { 1245.67m, 1189.55m, 1098.72m, 1456.88m, 2109.34m, 1987.55m, 1872.36m};
            }

            //Display the array elements in the ListBox
            foreach(decimal s in sales)
            {
                salesListBox.Items.Add(s.ToString("c"));
            }

            //Calculate the total of the sales
            foreach(decimal s in sales)
            {
                total += s;
            }
            //Display total
            labelTotal.Text = total.ToString("c");
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
