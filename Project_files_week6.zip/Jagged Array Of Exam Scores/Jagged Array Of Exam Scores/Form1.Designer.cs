﻿namespace Jagged_Array_Of_Exam_Scores
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonExit = new System.Windows.Forms.Button();
            this.listBoxSectionOne = new System.Windows.Forms.ListBox();
            this.listBoxSection2 = new System.Windows.Forms.ListBox();
            this.listBoxSectionThree = new System.Windows.Forms.ListBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.labelAvgOne = new System.Windows.Forms.Label();
            this.labelAvgTwo = new System.Windows.Forms.Label();
            this.labelAvgThree = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.labelHighest = new System.Windows.Forms.Label();
            this.labelLowest = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonExit
            // 
            this.buttonExit.Location = new System.Drawing.Point(12, 319);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(99, 52);
            this.buttonExit.TabIndex = 1;
            this.buttonExit.Text = "&Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // listBoxSectionOne
            // 
            this.listBoxSectionOne.FormattingEnabled = true;
            this.listBoxSectionOne.ItemHeight = 20;
            this.listBoxSectionOne.Location = new System.Drawing.Point(35, 25);
            this.listBoxSectionOne.Name = "listBoxSectionOne";
            this.listBoxSectionOne.Size = new System.Drawing.Size(120, 184);
            this.listBoxSectionOne.TabIndex = 2;
            // 
            // listBoxSection2
            // 
            this.listBoxSection2.FormattingEnabled = true;
            this.listBoxSection2.ItemHeight = 20;
            this.listBoxSection2.Location = new System.Drawing.Point(39, 25);
            this.listBoxSection2.Name = "listBoxSection2";
            this.listBoxSection2.Size = new System.Drawing.Size(120, 184);
            this.listBoxSection2.TabIndex = 3;
            // 
            // listBoxSectionThree
            // 
            this.listBoxSectionThree.FormattingEnabled = true;
            this.listBoxSectionThree.ItemHeight = 20;
            this.listBoxSectionThree.Location = new System.Drawing.Point(44, 25);
            this.listBoxSectionThree.Name = "listBoxSectionThree";
            this.listBoxSectionThree.Size = new System.Drawing.Size(120, 184);
            this.listBoxSectionThree.TabIndex = 4;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.listBoxSection2);
            this.groupBox1.Location = new System.Drawing.Point(244, 22);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 219);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Section 2";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.listBoxSectionOne);
            this.groupBox2.Location = new System.Drawing.Point(8, 22);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(200, 219);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Section 1";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.listBoxSectionThree);
            this.groupBox3.Location = new System.Drawing.Point(491, 22);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(200, 219);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Section 3";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(4, 261);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 20);
            this.label1.TabIndex = 6;
            this.label1.Text = "Average:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(240, 261);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 20);
            this.label2.TabIndex = 7;
            this.label2.Text = "Average:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(487, 261);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 20);
            this.label3.TabIndex = 8;
            this.label3.Text = "Average:";
            // 
            // labelAvgOne
            // 
            this.labelAvgOne.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelAvgOne.Location = new System.Drawing.Point(82, 261);
            this.labelAvgOne.Name = "labelAvgOne";
            this.labelAvgOne.Size = new System.Drawing.Size(100, 23);
            this.labelAvgOne.TabIndex = 9;
            this.labelAvgOne.Text = "0.0";
            // 
            // labelAvgTwo
            // 
            this.labelAvgTwo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelAvgTwo.Location = new System.Drawing.Point(318, 261);
            this.labelAvgTwo.Name = "labelAvgTwo";
            this.labelAvgTwo.Size = new System.Drawing.Size(100, 23);
            this.labelAvgTwo.TabIndex = 10;
            this.labelAvgTwo.Text = "0.0";
            // 
            // labelAvgThree
            // 
            this.labelAvgThree.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelAvgThree.Location = new System.Drawing.Point(565, 261);
            this.labelAvgThree.Name = "labelAvgThree";
            this.labelAvgThree.Size = new System.Drawing.Size(100, 23);
            this.labelAvgThree.TabIndex = 11;
            this.labelAvgThree.Text = "0.0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(419, 351);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(64, 20);
            this.label7.TabIndex = 12;
            this.label7.Text = "Highest";
            // 
            // labelHighest
            // 
            this.labelHighest.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelHighest.Location = new System.Drawing.Point(491, 351);
            this.labelHighest.Name = "labelHighest";
            this.labelHighest.Size = new System.Drawing.Size(176, 20);
            this.labelHighest.TabIndex = 13;
            this.labelHighest.Text = "0 Section#";
            // 
            // labelLowest
            // 
            this.labelLowest.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelLowest.Location = new System.Drawing.Point(491, 319);
            this.labelLowest.Name = "labelLowest";
            this.labelLowest.Size = new System.Drawing.Size(176, 20);
            this.labelLowest.TabIndex = 14;
            this.labelLowest.Text = "0 Section#";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(419, 319);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(60, 20);
            this.label10.TabIndex = 15;
            this.label10.Text = "Lowest";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(716, 391);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.labelLowest);
            this.Controls.Add(this.labelHighest);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.labelAvgThree);
            this.Controls.Add(this.labelAvgTwo);
            this.Controls.Add(this.labelAvgOne);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.buttonExit);
            this.Name = "Form1";
            this.Text = "Jagged Exams";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.ListBox listBoxSectionOne;
        private System.Windows.Forms.ListBox listBoxSection2;
        private System.Windows.Forms.ListBox listBoxSectionThree;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label labelAvgOne;
        private System.Windows.Forms.Label labelAvgTwo;
        private System.Windows.Forms.Label labelAvgThree;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label labelHighest;
        private System.Windows.Forms.Label labelLowest;
        private System.Windows.Forms.Label label10;
    }
}

