﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Jagged_Array_Of_Exam_Scores
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private int Lowest(int[] iArray)
        {
            int lowest = iArray[0];

            for (int index = 0; index < iArray.Length; index++)
            {
                if (iArray[index] < lowest)
                {
                    lowest = iArray[index];
                }
                index++;
            }

            return lowest;
        }

        private int Highest(int[] iArray)
        {
            //Start-this is the highest so far
            int highest = iArray[0];

            //loop to step through values of array
            for (int index = 0; index < iArray.Length; index++)
            {
                if (iArray[index] > highest)
                {
                    highest = iArray[index];
                }
            }
            return highest;
        }

        private double Average(int[] iArray)
        {
            int total = 0;
            double average;

            for (int index = 0; index < iArray.Length; index++)
            {
                total += iArray[index];
            }
            average = (double)total / iArray.Length;

            return average;
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            int[][] jaggedArray = new int[3][];
            jaggedArray[0] = new int[12];
            jaggedArray[1] = new int[8];
            jaggedArray[2] = new int[10]; 
            try
            {
                //Open file
                StreamReader inputFile = File.OpenText("Section1.txt");
                //Read the contents of the file into the array
                while (!inputFile.EndOfStream)
                {
                    for (int col = 0; col < jaggedArray[0].Length; col++)
                    {
                        //for(int list = 0; list < jaggedArray.Length; list++)
                        jaggedArray[0][col] = int.Parse(inputFile.ReadLine());
                        listBoxSectionOne.Items.Add(jaggedArray[0][col]);
                    }
                }
                inputFile.Close();

            }
            catch (Exception)
            {
                MessageBox.Show("Cannot find file1.");
            }

            try
            {
                //Open second file to read from
                //Open file

                StreamReader inputFile2 = File.OpenText("Section2.txt");
                //Read the contents of the file into the array
                while (!inputFile2.EndOfStream)
                {
                    for (int col = 0; col < jaggedArray[1].Length; col++)
                    {
                        jaggedArray[1][col] = int.Parse(inputFile2.ReadLine());
                        listBoxSection2.Items.Add(jaggedArray[1][col]);
                    }
                }
                inputFile2.Close();

            }
            catch (Exception)
            {
                MessageBox.Show("Can't find file2");
                MessageBox.Show(e.ToString());
            }
            try
            {
                //Open third file to read from
                //Open file

                StreamReader inputFile3 = File.OpenText("Section3.txt");
                //Read the contents of the file into the array
                while (!inputFile3.EndOfStream)
                {
                    for (int col = 0; col < jaggedArray[2].Length; col++)
                    {
                        jaggedArray[2][col] = int.Parse(inputFile3.ReadLine());
                        listBoxSectionThree.Items.Add(jaggedArray[2][col]);
                    }
                }
                inputFile3.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Can't find file3");
                MessageBox.Show(e.ToString());
            }
            //Get averages for each section of the JaggedArray
            double average1 = Average(jaggedArray[0]);
            double average2 = Average(jaggedArray[1]);
            double average3 = Average(jaggedArray[2]);

            //Display the average for each section
            labelAvgOne.Text = average1.ToString("n2");
            labelAvgTwo.Text = average2.ToString();
            labelAvgThree.Text = average3.ToString();

            int highest = Highest(jaggedArray[0]);
            int highest2 = Highest(jaggedArray[1]);
            int highest3 = Highest(jaggedArray[2]);
            int highestOfAll;
            int section = 0;

            //Loops to test highest scores
            if (highest == highest2 && highest > highest3)
            {
                section = 1;
                highestOfAll = highest;
                labelHighest.Text = highestOfAll.ToString() +
                     " Section: " + section.ToString() + " And 2";
            }
            else if (highest == highest3 && highest > highest2)
            {
                section = 1;
                highestOfAll = highest;
                labelHighest.Text = highestOfAll.ToString() +
                     " Section: " + section.ToString() + " And 3";
            }
            else if (highest > highest2 && highest > highest3)
            {
                section = 1;
                highestOfAll = highest;
                labelHighest.Text = highestOfAll.ToString() +
                     " Section: " + section.ToString();
            }
            else if (highest2 > highest && highest2 > highest3)
            {
                section = 2;
                highestOfAll = highest2;
                labelHighest.Text = highestOfAll.ToString() +
                     " Section: " + section.ToString();
            }
            else if (highest3 > highest && highest3 > highest2)
            {
                section = 3;
                highestOfAll = highest3;
                labelHighest.Text = highestOfAll.ToString() +
                     " Section: " + section.ToString();
            }

            //Or you can use a for loop to iterate through each element
            //Example below for the lowest number
            int lowest = Lowest(jaggedArray[0]);
            for(int i = 0; i < 3; i++)
            {
                if (Lowest(jaggedArray[i]) < lowest)
                {
                    lowest = Lowest(jaggedArray[i]);
                    section = i + 1;
                }
                labelLowest.Text = lowest.ToString() + " Section: " + section.ToString();
            }
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
    }
