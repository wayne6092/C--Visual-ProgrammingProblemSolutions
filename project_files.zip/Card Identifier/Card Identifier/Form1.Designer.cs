﻿namespace Card_Identifier
{
    partial class cardIdentifierForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tenClubsPictureBox = new System.Windows.Forms.PictureBox();
            this.aceHeartsPictureBox = new System.Windows.Forms.PictureBox();
            this.kingSpadesPictureBox = new System.Windows.Forms.PictureBox();
            this.queenClubsPictureBox = new System.Windows.Forms.PictureBox();
            this.queenDiamondsPictureBox = new System.Windows.Forms.PictureBox();
            this.cardIndicatorLabel = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.tenClubsPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aceHeartsPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kingSpadesPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.queenClubsPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.queenDiamondsPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // tenClubsPictureBox
            // 
            this.tenClubsPictureBox.Image = global::Card_Identifier.Properties.Resources._10_Clubs;
            this.tenClubsPictureBox.Location = new System.Drawing.Point(12, 52);
            this.tenClubsPictureBox.Name = "tenClubsPictureBox";
            this.tenClubsPictureBox.Size = new System.Drawing.Size(112, 134);
            this.tenClubsPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.tenClubsPictureBox.TabIndex = 0;
            this.tenClubsPictureBox.TabStop = false;
            this.tenClubsPictureBox.Click += new System.EventHandler(this.tenClubsPictureBox_Click);
            // 
            // aceHeartsPictureBox
            // 
            this.aceHeartsPictureBox.Image = global::Card_Identifier.Properties.Resources.Ace_Hearts;
            this.aceHeartsPictureBox.Location = new System.Drawing.Point(147, 52);
            this.aceHeartsPictureBox.Name = "aceHeartsPictureBox";
            this.aceHeartsPictureBox.Size = new System.Drawing.Size(112, 134);
            this.aceHeartsPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.aceHeartsPictureBox.TabIndex = 1;
            this.aceHeartsPictureBox.TabStop = false;
            this.aceHeartsPictureBox.Click += new System.EventHandler(this.aceHeartsPictureBox_Click);
            // 
            // kingSpadesPictureBox
            // 
            this.kingSpadesPictureBox.Image = global::Card_Identifier.Properties.Resources.King_Spades;
            this.kingSpadesPictureBox.Location = new System.Drawing.Point(282, 52);
            this.kingSpadesPictureBox.Name = "kingSpadesPictureBox";
            this.kingSpadesPictureBox.Size = new System.Drawing.Size(112, 134);
            this.kingSpadesPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.kingSpadesPictureBox.TabIndex = 2;
            this.kingSpadesPictureBox.TabStop = false;
            this.kingSpadesPictureBox.Click += new System.EventHandler(this.kingSpadesPictureBox_Click);
            // 
            // queenClubsPictureBox
            // 
            this.queenClubsPictureBox.Image = global::Card_Identifier.Properties.Resources.Queen_Clubs;
            this.queenClubsPictureBox.Location = new System.Drawing.Point(416, 52);
            this.queenClubsPictureBox.Name = "queenClubsPictureBox";
            this.queenClubsPictureBox.Size = new System.Drawing.Size(112, 134);
            this.queenClubsPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.queenClubsPictureBox.TabIndex = 3;
            this.queenClubsPictureBox.TabStop = false;
            this.queenClubsPictureBox.Click += new System.EventHandler(this.queenClubsPictureBox_Click);
            // 
            // queenDiamondsPictureBox
            // 
            this.queenDiamondsPictureBox.Image = global::Card_Identifier.Properties.Resources.Queen_Diamonds;
            this.queenDiamondsPictureBox.Location = new System.Drawing.Point(554, 52);
            this.queenDiamondsPictureBox.Name = "queenDiamondsPictureBox";
            this.queenDiamondsPictureBox.Size = new System.Drawing.Size(112, 134);
            this.queenDiamondsPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.queenDiamondsPictureBox.TabIndex = 4;
            this.queenDiamondsPictureBox.TabStop = false;
            this.queenDiamondsPictureBox.Click += new System.EventHandler(this.queenDiamondsPictureBox_Click);
            // 
            // cardIndicatorLabel
            // 
            this.cardIndicatorLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.cardIndicatorLabel.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cardIndicatorLabel.Location = new System.Drawing.Point(105, 225);
            this.cardIndicatorLabel.Name = "cardIndicatorLabel";
            this.cardIndicatorLabel.Size = new System.Drawing.Size(464, 49);
            this.cardIndicatorLabel.TabIndex = 5;
            this.cardIndicatorLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(298, 308);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(96, 34);
            this.exitButton.TabIndex = 6;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // cardIdentifierForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(678, 390);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.cardIndicatorLabel);
            this.Controls.Add(this.queenDiamondsPictureBox);
            this.Controls.Add(this.queenClubsPictureBox);
            this.Controls.Add(this.kingSpadesPictureBox);
            this.Controls.Add(this.aceHeartsPictureBox);
            this.Controls.Add(this.tenClubsPictureBox);
            this.Name = "cardIdentifierForm";
            this.Text = "Card Identifer";
            ((System.ComponentModel.ISupportInitialize)(this.tenClubsPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aceHeartsPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kingSpadesPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.queenClubsPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.queenDiamondsPictureBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox tenClubsPictureBox;
        private System.Windows.Forms.PictureBox aceHeartsPictureBox;
        private System.Windows.Forms.PictureBox kingSpadesPictureBox;
        private System.Windows.Forms.PictureBox queenClubsPictureBox;
        private System.Windows.Forms.PictureBox queenDiamondsPictureBox;
        private System.Windows.Forms.Label cardIndicatorLabel;
        private System.Windows.Forms.Button exitButton;
    }
}

