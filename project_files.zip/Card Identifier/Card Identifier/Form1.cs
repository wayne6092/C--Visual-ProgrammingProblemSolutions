﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Card_Identifier
{
    public partial class cardIdentifierForm : Form
    {
        public cardIdentifierForm()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void tenClubsPictureBox_Click(object sender, EventArgs e)
        {
            cardIndicatorLabel.Text = "Ten of Clubs";
        }

        private void aceHeartsPictureBox_Click(object sender, EventArgs e)
        {
            cardIndicatorLabel.Text = "Ace of Hearts";
        }

        private void kingSpadesPictureBox_Click(object sender, EventArgs e)
        {
            cardIndicatorLabel.Text = "King of Spades";
        }

        private void queenClubsPictureBox_Click(object sender, EventArgs e)
        {
            cardIndicatorLabel.Text = "Queen of Clubs";
        }

        private void queenDiamondsPictureBox_Click(object sender, EventArgs e)
        {
            cardIndicatorLabel.Text = "Queen of Diamonds";
        }
    }
}
