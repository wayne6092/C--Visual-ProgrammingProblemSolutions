﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Joke_and_Punchline
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            jokeLabel.Text = "How many programmers does it take to change a lightbulb?";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            jokeLabel.Text = "None. That's a hardware problem.";
        }
    }
}
