﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Distance_Calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonCalculate_Click(object sender, EventArgs e)
        {
            int speed;
            int hours;
            int result;

            if (int.TryParse(textBoxSpeed.Text, out speed) && speed > 0)
            {
                if(int.TryParse(textBoxHours.Text, out hours) && hours > 0)
                {
                    int count;
                    for(count = 1; count <= hours; count++)
                    {
                        result = speed * count;
                        listBoxResult.Items.Add("After Hour: " + 
                            count.ToString() + " Distance is: " + 
                            result.ToString());
                    }
                    textBoxSpeed.Focus();
                }
                else
                {
                    MessageBox.Show("Please enter valid number.");
                }
            }
            else
            {
                MessageBox.Show("Please enter valid number.");
            }
            
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
