﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Distance_File
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonCalculate_Click(object sender, EventArgs e)
        {
            int speed;
            int hours;
            int result;

            if (int.TryParse(textBoxSpeed.Text, out speed) && speed > 0)
            {
                try
                {
                    StreamWriter outputFile;
                    outputFile = File.CreateText("DistanceFile.txt");
                    if (int.TryParse(textBoxHours.Text, out hours) && hours > 0)
                    {
                        int count;
                        for (count = 1; count <= hours; count++)
                        {
                            result = speed * count;
                            string strings = ("After Hour: " +
                                count.ToString() + " Distance is: " +
                                result.ToString());


                            outputFile.WriteLine(strings);
                        }
                        MessageBox.Show("Distances per time have been written to DistanceFile.txt");
                        outputFile.Close();
                        textBoxSpeed.Focus();
                    }
                    else
                    {
                        MessageBox.Show("Please enter valid number.");
                    }
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Please enter valid number.");
            }
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
