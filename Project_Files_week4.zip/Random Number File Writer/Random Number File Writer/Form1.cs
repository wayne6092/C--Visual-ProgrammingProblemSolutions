﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Random_Number_File_Writer
{
    public partial class Form1 : Form
    {
        Random rand = new Random();
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonWriteToFile_Click(object sender, EventArgs e)
        {
            int numberOfRandoms;
            int number;

            if(int.TryParse(textBoxRandomNumbers.Text, out numberOfRandoms)
                && numberOfRandoms > 0)
            {
                //Create StreamWriter object "outputFile"
                StreamWriter outputFile;

                //saveFileRandom.ShowDialog();
                //Using if conditions to determine which button is pressed
                //Save or Cancel
                try
                {
                    //If Ok (Save) button is clicked
                    if (saveFileRandom.ShowDialog() == DialogResult.OK)
                    {
                        //Write to created text file
                        outputFile = File.CreateText(saveFileRandom.FileName);

                        //Loop = Number of Random numbers
                        for (int i = 1; i <= numberOfRandoms; i++)
                        {
                            number = rand.Next(1, 100);
                            outputFile.WriteLine(number.ToString());
                        }
                        outputFile.Close();
                        textBoxRandomNumbers.Focus();

                    }
                    //If cancel button is clicked
                    else
                    {
                        MessageBox.Show("Operation Cancelled.");
                        textBoxRandomNumbers.Focus();
                    }
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    textBoxRandomNumbers.Focus();
                }

            }
            else
            {
                MessageBox.Show("Please enter a valid number.");
                textBoxRandomNumbers.Focus();
            }
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
