﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;

namespace Celsius_to_Farenheit_Table
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonDisplayTable_Click(object sender, EventArgs e)
        {
            double c;
            double f;

            for (c = 0; c <= 20; c++)
            {
                f = (c * 9 / 5) + 32;
                listBoxResults.Items.Add("°C: " +
                            c.ToString() + " = °F: " +
                            f.ToString());
            }
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
