﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tuition_Increase
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonDisplayTable_Click(object sender, EventArgs e)
        {
            const int YEARS = 5;
            const decimal RATE = 0.02m;
            const decimal TUITION = 6000;
            decimal total = TUITION;

            listBoxResult.Items.Add("Year    Tuition");
            for(int count = 0; count <= YEARS; count++)
            {
                listBoxResult.Items.Add(count.ToString() +
                    "          " + total.ToString());
                total += total * RATE;
            }
            buttonDisplayTable.Focus();
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            listBoxResult.Items.Clear();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
