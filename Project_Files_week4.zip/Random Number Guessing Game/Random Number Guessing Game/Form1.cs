﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Random_Number_Guessing_Game
{
    public partial class Form1 : Form
    {
        private Random rand = new Random();
        private int number;
        private int guess;
        private int guesses;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            number = rand.Next(0, 100);
            
        }

        private void buttonCheckGuess_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBoxGuess.Text, out guess) && guess >= 0)
            {
                if (guess == number)
                {
                    //Increase guesses
                    guesses = guesses + 1;
                    labelResult.Text = "Congrats! You guessed my number " +
                        number + " in " + guesses + " guesses";

                    //New random number
                    number = rand.Next(0, 100);
                    
                    //Reset Guesses
                    guesses = 0;

                }
                else if (guess > number)
                {
                    labelResult.Text = "Your guess is too high, try again.";
                    

                    //Increase guesses
                    guesses = guesses + 1;
                }
                else if (guess < number)
                {
                    labelResult.Text = "Your guess is too low, try again.";
                    

                    //Increase guesses
                    guesses = guesses + 1;
                }
                textBoxGuess.Focus();
                labelGuessesTaken.Text = guesses.ToString();
            }
            else
            {
                MessageBox.Show("Please enter a valid number.");
                textBoxGuess.Focus();
            }
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBoxGuess.Text = "0";
            labelGuessesTaken.Text = "0";
            labelResult.Text = "";
            textBoxGuess.Focus();
        }
    }
}
