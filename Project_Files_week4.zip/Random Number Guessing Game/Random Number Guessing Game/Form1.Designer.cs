﻿namespace Random_Number_Guessing_Game
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonExit = new System.Windows.Forms.Button();
            this.buttonCheckGuess = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.labelResult = new System.Windows.Forms.Label();
            this.textBoxGuess = new System.Windows.Forms.TextBox();
            this.labelTitleGuessesTaken = new System.Windows.Forms.Label();
            this.labelGuessesTaken = new System.Windows.Forms.Label();
            this.buttonClear = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonExit
            // 
            this.buttonExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonExit.Location = new System.Drawing.Point(342, 127);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(123, 37);
            this.buttonExit.TabIndex = 3;
            this.buttonExit.Text = "&Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            // 
            // buttonCheckGuess
            // 
            this.buttonCheckGuess.Location = new System.Drawing.Point(342, 23);
            this.buttonCheckGuess.Name = "buttonCheckGuess";
            this.buttonCheckGuess.Size = new System.Drawing.Size(123, 37);
            this.buttonCheckGuess.TabIndex = 1;
            this.buttonCheckGuess.Text = "Check Guess";
            this.buttonCheckGuess.UseVisualStyleBackColor = true;
            this.buttonCheckGuess.Click += new System.EventHandler(this.buttonCheckGuess_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(199, 20);
            this.label1.TabIndex = 7;
            this.label1.Text = "Guess My Number (1-100):";
            // 
            // labelResult
            // 
            this.labelResult.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelResult.Location = new System.Drawing.Point(117, 119);
            this.labelResult.Name = "labelResult";
            this.labelResult.Size = new System.Drawing.Size(200, 45);
            this.labelResult.TabIndex = 4;
            // 
            // textBoxGuess
            // 
            this.textBoxGuess.Location = new System.Drawing.Point(217, 23);
            this.textBoxGuess.Name = "textBoxGuess";
            this.textBoxGuess.Size = new System.Drawing.Size(100, 26);
            this.textBoxGuess.TabIndex = 0;
            this.textBoxGuess.Text = "0";
            // 
            // labelTitleGuessesTaken
            // 
            this.labelTitleGuessesTaken.AutoSize = true;
            this.labelTitleGuessesTaken.Location = new System.Drawing.Point(90, 67);
            this.labelTitleGuessesTaken.Name = "labelTitleGuessesTaken";
            this.labelTitleGuessesTaken.Size = new System.Drawing.Size(121, 20);
            this.labelTitleGuessesTaken.TabIndex = 6;
            this.labelTitleGuessesTaken.Text = "Guesses Taken";
            // 
            // labelGuessesTaken
            // 
            this.labelGuessesTaken.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelGuessesTaken.Location = new System.Drawing.Point(217, 67);
            this.labelGuessesTaken.Name = "labelGuessesTaken";
            this.labelGuessesTaken.Size = new System.Drawing.Size(100, 23);
            this.labelGuessesTaken.TabIndex = 5;
            this.labelGuessesTaken.Text = "0";
            // 
            // buttonClear
            // 
            this.buttonClear.Location = new System.Drawing.Point(342, 77);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(123, 35);
            this.buttonClear.TabIndex = 2;
            this.buttonClear.Text = "Clear";
            this.buttonClear.UseVisualStyleBackColor = true;
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // Form1
            // 
            this.AcceptButton = this.buttonCheckGuess;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.buttonExit;
            this.ClientSize = new System.Drawing.Size(491, 182);
            this.Controls.Add(this.buttonClear);
            this.Controls.Add(this.labelGuessesTaken);
            this.Controls.Add(this.labelTitleGuessesTaken);
            this.Controls.Add(this.textBoxGuess);
            this.Controls.Add(this.labelResult);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonCheckGuess);
            this.Controls.Add(this.buttonExit);
            this.Name = "Form1";
            this.Text = "Random Number Guessing Game";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Button buttonCheckGuess;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelResult;
        private System.Windows.Forms.TextBox textBoxGuess;
        private System.Windows.Forms.Label labelTitleGuessesTaken;
        private System.Windows.Forms.Label labelGuessesTaken;
        private System.Windows.Forms.Button buttonClear;
    }
}

