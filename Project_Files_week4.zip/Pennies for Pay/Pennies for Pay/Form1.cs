﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pennies_for_Pay
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonCalculate_Click(object sender, EventArgs e)
        {
            int days;
            decimal result = 0.01m;

            if(int.TryParse(textBoxDays.Text, out days) && days >= 0)
            {
                for(int i = 2; i <= days; i++)
                {
                    result = result * 2;
                }
                if (days == 1)
                {
                    result = 0.01m;
                }
                else if (days == 0)
                {
                    result = 0.00m;
                }
                labelTotal.Text = result.ToString("c");
                textBoxDays.Focus();
            }
            else
            {
                MessageBox.Show("Please enter a valid number.");
                textBoxDays.Focus();
            }
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBoxDays.Text = "0";
            labelTotal.Text = "$0.00";
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
