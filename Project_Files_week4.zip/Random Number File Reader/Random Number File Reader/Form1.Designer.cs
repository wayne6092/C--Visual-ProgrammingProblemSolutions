﻿namespace Random_Number_File_Reader
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.openFile = new System.Windows.Forms.OpenFileDialog();
            this.buttonExit = new System.Windows.Forms.Button();
            this.buttonReadFromFile = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.labelRandomTotal = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.labelRandomCount = new System.Windows.Forms.Label();
            this.listBoxRandomResult = new System.Windows.Forms.ListBox();
            this.buttonClear = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonExit
            // 
            this.buttonExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonExit.Location = new System.Drawing.Point(12, 195);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(100, 38);
            this.buttonExit.TabIndex = 2;
            this.buttonExit.Text = "&Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // buttonReadFromFile
            // 
            this.buttonReadFromFile.Location = new System.Drawing.Point(238, 195);
            this.buttonReadFromFile.Name = "buttonReadFromFile";
            this.buttonReadFromFile.Size = new System.Drawing.Size(100, 38);
            this.buttonReadFromFile.TabIndex = 0;
            this.buttonReadFromFile.Text = "Read File";
            this.buttonReadFromFile.UseVisualStyleBackColor = true;
            this.buttonReadFromFile.Click += new System.EventHandler(this.buttonReadFromFile_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(27, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(169, 20);
            this.label1.TabIndex = 5;
            this.label1.Text = "Random Number Total";
            // 
            // labelRandomTotal
            // 
            this.labelRandomTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelRandomTotal.Location = new System.Drawing.Point(232, 22);
            this.labelRandomTotal.Name = "labelRandomTotal";
            this.labelRandomTotal.Size = new System.Drawing.Size(100, 23);
            this.labelRandomTotal.TabIndex = 4;
            this.labelRandomTotal.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(19, 100);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(177, 20);
            this.label3.TabIndex = 6;
            this.label3.Text = "Random Number Count";
            // 
            // labelRandomCount
            // 
            this.labelRandomCount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelRandomCount.Location = new System.Drawing.Point(232, 100);
            this.labelRandomCount.Name = "labelRandomCount";
            this.labelRandomCount.Size = new System.Drawing.Size(100, 23);
            this.labelRandomCount.TabIndex = 3;
            this.labelRandomCount.Text = "0";
            // 
            // listBoxRandomResult
            // 
            this.listBoxRandomResult.FormattingEnabled = true;
            this.listBoxRandomResult.ItemHeight = 20;
            this.listBoxRandomResult.Location = new System.Drawing.Point(350, 22);
            this.listBoxRandomResult.Name = "listBoxRandomResult";
            this.listBoxRandomResult.Size = new System.Drawing.Size(82, 204);
            this.listBoxRandomResult.TabIndex = 7;
            // 
            // buttonClear
            // 
            this.buttonClear.Location = new System.Drawing.Point(127, 195);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(97, 38);
            this.buttonClear.TabIndex = 1;
            this.buttonClear.Text = "Clear";
            this.buttonClear.UseVisualStyleBackColor = true;
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // Form1
            // 
            this.AcceptButton = this.buttonReadFromFile;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.buttonExit;
            this.ClientSize = new System.Drawing.Size(454, 289);
            this.Controls.Add(this.buttonClear);
            this.Controls.Add(this.listBoxRandomResult);
            this.Controls.Add(this.labelRandomCount);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.labelRandomTotal);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonReadFromFile);
            this.Controls.Add(this.buttonExit);
            this.Name = "Form1";
            this.Text = "Random Number File Reader";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog openFile;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Button buttonReadFromFile;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelRandomTotal;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label labelRandomCount;
        private System.Windows.Forms.ListBox listBoxRandomResult;
        private System.Windows.Forms.Button buttonClear;
    }
}

