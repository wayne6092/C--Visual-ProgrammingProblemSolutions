﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Random_Number_File_Reader
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonReadFromFile_Click(object sender, EventArgs e)
        {
            int count = 0;
            int randomNumber;
            int total = 0;
            try
            {
                StreamReader inputFile;
                //openFile.ShowDialog();

                if (openFile.ShowDialog() == DialogResult.OK)
                {
                    inputFile = File.OpenText(openFile.FileName);
                    while(inputFile.EndOfStream == false)
                    {
                        count++;
                        randomNumber = int.Parse(inputFile.ReadLine());
                        total += randomNumber;
                        listBoxRandomResult.Items.Add
                            (count + ".   " + randomNumber);

                    }
                    labelRandomCount.Text = count.ToString();
                    labelRandomTotal.Text = total.ToString();
                    inputFile.Close();
                    buttonReadFromFile.Focus();
                }
                else
                {
                    MessageBox.Show("Operation has been cancelled.");
                    buttonReadFromFile.Focus();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
                buttonReadFromFile.Focus();
            }
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            listBoxRandomResult.Items.Clear();
            labelRandomCount.Text = "0";
            labelRandomTotal.Text = "0";
            buttonReadFromFile.Focus();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
