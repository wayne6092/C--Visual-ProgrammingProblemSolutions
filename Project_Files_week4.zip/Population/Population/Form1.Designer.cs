﻿namespace Population
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonClear = new System.Windows.Forms.Button();
            this.buttonExit = new System.Windows.Forms.Button();
            this.buttonCalculate = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxStartNumOrg = new System.Windows.Forms.TextBox();
            this.textBoxAvgDayPopIncr = new System.Windows.Forms.TextBox();
            this.textBoxNumDays = new System.Windows.Forms.TextBox();
            this.listBoxResults = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // buttonClear
            // 
            this.buttonClear.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonClear.Location = new System.Drawing.Point(139, 341);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(103, 45);
            this.buttonClear.TabIndex = 4;
            this.buttonClear.Text = "Clear";
            this.buttonClear.UseVisualStyleBackColor = true;
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // buttonExit
            // 
            this.buttonExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonExit.Location = new System.Drawing.Point(29, 341);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(103, 45);
            this.buttonExit.TabIndex = 5;
            this.buttonExit.Text = "&Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // buttonCalculate
            // 
            this.buttonCalculate.Location = new System.Drawing.Point(248, 341);
            this.buttonCalculate.Name = "buttonCalculate";
            this.buttonCalculate.Size = new System.Drawing.Size(103, 45);
            this.buttonCalculate.TabIndex = 3;
            this.buttonCalculate.Text = "Calculate";
            this.buttonCalculate.UseVisualStyleBackColor = true;
            this.buttonCalculate.Click += new System.EventHandler(this.buttonCalculate_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(38, 124);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(197, 20);
            this.label1.TabIndex = 7;
            this.label1.Text = "Number of Days to Multiply";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(35, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(200, 20);
            this.label2.TabIndex = 8;
            this.label2.Text = "Average Daily Increase (%)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 25);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(223, 20);
            this.label3.TabIndex = 9;
            this.label3.Text = "Starting Number of Organisms";
            // 
            // textBoxStartNumOrg
            // 
            this.textBoxStartNumOrg.Location = new System.Drawing.Point(251, 22);
            this.textBoxStartNumOrg.Name = "textBoxStartNumOrg";
            this.textBoxStartNumOrg.Size = new System.Drawing.Size(100, 26);
            this.textBoxStartNumOrg.TabIndex = 0;
            this.textBoxStartNumOrg.Text = "0";
            // 
            // textBoxAvgDayPopIncr
            // 
            this.textBoxAvgDayPopIncr.Location = new System.Drawing.Point(251, 72);
            this.textBoxAvgDayPopIncr.Name = "textBoxAvgDayPopIncr";
            this.textBoxAvgDayPopIncr.Size = new System.Drawing.Size(100, 26);
            this.textBoxAvgDayPopIncr.TabIndex = 1;
            this.textBoxAvgDayPopIncr.Text = "0";
            // 
            // textBoxNumDays
            // 
            this.textBoxNumDays.Location = new System.Drawing.Point(251, 121);
            this.textBoxNumDays.Name = "textBoxNumDays";
            this.textBoxNumDays.Size = new System.Drawing.Size(100, 26);
            this.textBoxNumDays.TabIndex = 2;
            this.textBoxNumDays.Text = "0";
            // 
            // listBoxResults
            // 
            this.listBoxResults.FormattingEnabled = true;
            this.listBoxResults.ItemHeight = 20;
            this.listBoxResults.Location = new System.Drawing.Point(29, 170);
            this.listBoxResults.Name = "listBoxResults";
            this.listBoxResults.Size = new System.Drawing.Size(322, 144);
            this.listBoxResults.TabIndex = 6;
            // 
            // Form1
            // 
            this.AcceptButton = this.buttonCalculate;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.buttonExit;
            this.ClientSize = new System.Drawing.Size(379, 404);
            this.Controls.Add(this.listBoxResults);
            this.Controls.Add(this.textBoxNumDays);
            this.Controls.Add(this.textBoxAvgDayPopIncr);
            this.Controls.Add(this.textBoxStartNumOrg);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonCalculate);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.buttonClear);
            this.Name = "Form1";
            this.Text = "Population";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonClear;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Button buttonCalculate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxStartNumOrg;
        private System.Windows.Forms.TextBox textBoxAvgDayPopIncr;
        private System.Windows.Forms.TextBox textBoxNumDays;
        private System.Windows.Forms.ListBox listBoxResults;
    }
}

