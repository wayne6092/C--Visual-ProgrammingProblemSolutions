﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Population
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonCalculate_Click(object sender, EventArgs e)
        {
            int orgStartNum;
            int days;
            double averageDailyPopIncrease;
            double aproxPop;
            int count;


            if (int.TryParse(textBoxStartNumOrg.Text, 
                out orgStartNum) 
                && orgStartNum >= 0)
            {
                aproxPop = orgStartNum;
                if (double.TryParse(textBoxAvgDayPopIncr.Text, 
                    out averageDailyPopIncrease) && 
                    averageDailyPopIncrease >= 0)
                {
                    
                    if(int.TryParse(textBoxNumDays.Text, out days) && days >= 0)
                    {
                        listBoxResults.Items.Add("Day   Approximate Population");

                        for (count = 1; count <= days; count++)
                        {
                            listBoxResults.Items.Add(count + "        " + aproxPop);
                            aproxPop += (aproxPop * (averageDailyPopIncrease / 100));
                        }
                        
                    }
                    else
                    {
                        MessageBox.Show("Please enter a valid number.");
                        textBoxNumDays.Focus();
                    }
                }
                else
                {
                    MessageBox.Show("Please enter a valid number.");
                    textBoxAvgDayPopIncr.Focus();
                }
            }
            else
            {
                MessageBox.Show("Please enter a valid population size.");
                textBoxStartNumOrg.Focus();
            }
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBoxAvgDayPopIncr.Text = "0";
            textBoxNumDays.Text = "0";
            textBoxStartNumOrg.Text = "0";
            listBoxResults.Items.Clear();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
