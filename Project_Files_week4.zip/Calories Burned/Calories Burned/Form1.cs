﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calories_Burned
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonDisplayTable_Click(object sender, EventArgs e)
        {
            const double CALORIES = 3.9;
            const int MAX_TIME = 30;
            double result;

            listBoxResult.Items.Add("Minutes  Calories Lost");
            for(int count = 10; count <= MAX_TIME; count += 5)
            {
                result = count * CALORIES;
                listBoxResult.Items.Add(count.ToString() + 
                    "    " + result.ToString());
            }
            buttonDisplayTable.Focus();
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            listBoxResult.Items.Clear();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
