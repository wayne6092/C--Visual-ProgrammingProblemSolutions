﻿namespace Calculate_Factoral_of_Number
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonExit = new System.Windows.Forms.Button();
            this.buttonClear = new System.Windows.Forms.Button();
            this.buttonCalculate = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.labelFactorial = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxNonNegativeInteger = new System.Windows.Forms.TextBox();
            this.labelTitleFactorial = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonExit
            // 
            this.buttonExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonExit.Location = new System.Drawing.Point(12, 157);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(104, 48);
            this.buttonExit.TabIndex = 3;
            this.buttonExit.Text = "&Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // buttonClear
            // 
            this.buttonClear.Location = new System.Drawing.Point(122, 157);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(104, 48);
            this.buttonClear.TabIndex = 2;
            this.buttonClear.Text = "Clear";
            this.buttonClear.UseVisualStyleBackColor = true;
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // buttonCalculate
            // 
            this.buttonCalculate.Location = new System.Drawing.Point(232, 157);
            this.buttonCalculate.Name = "buttonCalculate";
            this.buttonCalculate.Size = new System.Drawing.Size(104, 48);
            this.buttonCalculate.TabIndex = 1;
            this.buttonCalculate.Text = "Calculate";
            this.buttonCalculate.UseVisualStyleBackColor = true;
            this.buttonCalculate.Click += new System.EventHandler(this.buttonCalculate_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(66, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(160, 20);
            this.label1.TabIndex = 6;
            this.label1.Text = "Non-Negative Integer";
            // 
            // labelFactorial
            // 
            this.labelFactorial.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelFactorial.Location = new System.Drawing.Point(236, 80);
            this.labelFactorial.Name = "labelFactorial";
            this.labelFactorial.Size = new System.Drawing.Size(100, 23);
            this.labelFactorial.TabIndex = 4;
            this.labelFactorial.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(40, 81);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(149, 20);
            this.label3.TabIndex = 5;
            this.label3.Text = "Calculated Factorial";
            // 
            // textBoxNonNegativeInteger
            // 
            this.textBoxNonNegativeInteger.Location = new System.Drawing.Point(236, 26);
            this.textBoxNonNegativeInteger.Name = "textBoxNonNegativeInteger";
            this.textBoxNonNegativeInteger.Size = new System.Drawing.Size(100, 26);
            this.textBoxNonNegativeInteger.TabIndex = 0;
            this.textBoxNonNegativeInteger.Text = "0";
            // 
            // labelTitleFactorial
            // 
            this.labelTitleFactorial.AutoSize = true;
            this.labelTitleFactorial.Location = new System.Drawing.Point(195, 81);
            this.labelTitleFactorial.Name = "labelTitleFactorial";
            this.labelTitleFactorial.Size = new System.Drawing.Size(35, 20);
            this.labelTitleFactorial.TabIndex = 7;
            this.labelTitleFactorial.Text = "n! =";
            // 
            // Form1
            // 
            this.AcceptButton = this.buttonCalculate;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.buttonExit;
            this.ClientSize = new System.Drawing.Size(374, 229);
            this.Controls.Add(this.labelTitleFactorial);
            this.Controls.Add(this.textBoxNonNegativeInteger);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.labelFactorial);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonCalculate);
            this.Controls.Add(this.buttonClear);
            this.Controls.Add(this.buttonExit);
            this.Name = "Form1";
            this.Text = "Factorial Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Button buttonClear;
        private System.Windows.Forms.Button buttonCalculate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelFactorial;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxNonNegativeInteger;
        private System.Windows.Forms.Label labelTitleFactorial;
    }
}

