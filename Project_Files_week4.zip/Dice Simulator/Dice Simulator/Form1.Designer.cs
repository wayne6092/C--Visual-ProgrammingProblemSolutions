﻿namespace Dice_Simulator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonExit = new System.Windows.Forms.Button();
            this.buttonRoll = new System.Windows.Forms.Button();
            this.groupBoxDice = new System.Windows.Forms.GroupBox();
            this.pictureBoxDie2 = new System.Windows.Forms.PictureBox();
            this.pictureBoxDie1 = new System.Windows.Forms.PictureBox();
            this.groupBoxDice.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDie2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDie1)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonExit
            // 
            this.buttonExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonExit.Location = new System.Drawing.Point(18, 216);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(103, 42);
            this.buttonExit.TabIndex = 1;
            this.buttonExit.Text = "&Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.button1_Click);
            // 
            // buttonRoll
            // 
            this.buttonRoll.Location = new System.Drawing.Point(203, 216);
            this.buttonRoll.Name = "buttonRoll";
            this.buttonRoll.Size = new System.Drawing.Size(103, 42);
            this.buttonRoll.TabIndex = 0;
            this.buttonRoll.Text = "Roll Dice";
            this.buttonRoll.UseVisualStyleBackColor = true;
            this.buttonRoll.Click += new System.EventHandler(this.buttonRoll_Click);
            // 
            // groupBoxDice
            // 
            this.groupBoxDice.Controls.Add(this.pictureBoxDie2);
            this.groupBoxDice.Controls.Add(this.pictureBoxDie1);
            this.groupBoxDice.Location = new System.Drawing.Point(12, 25);
            this.groupBoxDice.Name = "groupBoxDice";
            this.groupBoxDice.Size = new System.Drawing.Size(300, 174);
            this.groupBoxDice.TabIndex = 2;
            this.groupBoxDice.TabStop = false;
            this.groupBoxDice.Text = "Dice";
            // 
            // pictureBoxDie2
            // 
            this.pictureBoxDie2.Image = global::Dice_Simulator.Properties.Resources.Die1;
            this.pictureBoxDie2.Location = new System.Drawing.Point(150, 25);
            this.pictureBoxDie2.Name = "pictureBoxDie2";
            this.pictureBoxDie2.Size = new System.Drawing.Size(144, 136);
            this.pictureBoxDie2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxDie2.TabIndex = 1;
            this.pictureBoxDie2.TabStop = false;
            // 
            // pictureBoxDie1
            // 
            this.pictureBoxDie1.Image = global::Dice_Simulator.Properties.Resources.Die1;
            this.pictureBoxDie1.Location = new System.Drawing.Point(6, 25);
            this.pictureBoxDie1.Name = "pictureBoxDie1";
            this.pictureBoxDie1.Size = new System.Drawing.Size(138, 136);
            this.pictureBoxDie1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxDie1.TabIndex = 0;
            this.pictureBoxDie1.TabStop = false;
            // 
            // Form1
            // 
            this.AcceptButton = this.buttonRoll;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.buttonExit;
            this.ClientSize = new System.Drawing.Size(324, 276);
            this.Controls.Add(this.groupBoxDice);
            this.Controls.Add(this.buttonRoll);
            this.Controls.Add(this.buttonExit);
            this.Name = "Form1";
            this.Text = "Dice Simulator";
            this.groupBoxDice.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDie2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDie1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Button buttonRoll;
        private System.Windows.Forms.GroupBox groupBoxDice;
        private System.Windows.Forms.PictureBox pictureBoxDie2;
        private System.Windows.Forms.PictureBox pictureBoxDie1;
    }
}

