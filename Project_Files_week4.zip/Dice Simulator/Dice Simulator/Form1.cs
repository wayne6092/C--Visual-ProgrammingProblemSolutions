﻿using Dice_Simulator.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dice_Simulator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonRoll_Click(object sender, EventArgs e)
        {
            Random rand = new Random();
            int die1 = rand.Next(1, 7);
            int die2 = rand.Next(1, 7);
            try
            {
                //**SOLVED WITH INTELLISENSE**
                //I looked in the book in all chapters to find a way to accomplish
                //the assignment without making 12 pictureBoxes, I was able to 
                //make it work using pictureBox properties, and with Resources
                //file in the Solution Explorer, by implementing the using directive
                //on the applications properties makes this possible. 

                //The first switch statements shouldn't work on your computer,
                //but the Try except block should make the app run properly
                switch (die1)
                {
                    case 1:
                        pictureBoxDie1.Image = Resources.Die1;
                        pictureBoxDie1.ImageLocation =
                        "C:\\Users\\Wayne\\Desktop\\ITCS 1250\\Source_Code\\Gaddis Source_Code\\Student Sample Programs\\Chap05\\Die1.bmp";
                        break;
                    case 2:
                        pictureBoxDie1.Image = Resources.Die2;
                        pictureBoxDie1.ImageLocation =
                        "C:\\Users\\Wayne\\Desktop\\ITCS 1250\\Source_Code\\Gaddis Source_Code\\Student Sample Programs\\Chap05\\Die2.bmp";
                        break;
                    case 3:
                        pictureBoxDie1.Image = Resources.Die3;
                        pictureBoxDie1.ImageLocation =
                        "C:\\Users\\Wayne\\Desktop\\ITCS 1250\\Source_Code\\Gaddis Source_Code\\Student Sample Programs\\Chap05\\Die3.bmp";
                        break;
                    case 4:
                        pictureBoxDie1.Image = Resources.Die4;
                        pictureBoxDie1.ImageLocation =
                        "C:\\Users\\Wayne\\Desktop\\ITCS 1250\\Source_Code\\Gaddis Source_Code\\Student Sample Programs\\Chap05\\Die4.bmp";
                        break;
                    case 5:
                        pictureBoxDie1.Image = Resources.Die5;
                        pictureBoxDie1.ImageLocation =
                        "C:\\Users\\Wayne\\Desktop\\ITCS 1250\\Source_Code\\Gaddis Source_Code\\Student Sample Programs\\Chap05\\Die5.bmp";
                        break;
                    case 6:
                        pictureBoxDie1.Image = Resources.Die6;
                        pictureBoxDie1.ImageLocation =
                        "C:\\Users\\Wayne\\Desktop\\ITCS 1250\\Source_Code\\Gaddis Source_Code\\Student Sample Programs\\Chap05\\Die6.bmp";
                        break;
                }
            }
            catch(Exception ex)
            {
                switch (die1)
                {
                    case 1:
                        pictureBoxDie1.Image = Resources.Die1;
                        break;
                    case 2:
                        pictureBoxDie1.Image = Resources.Die2;
                        break;
                    case 3:
                        pictureBoxDie1.Image = Resources.Die3;
                        break;
                    case 4:
                        pictureBoxDie1.Image = Resources.Die4;
                        break;
                    case 5:
                        pictureBoxDie1.Image = Resources.Die5;
                        break;
                    case 6:
                        pictureBoxDie1.Image = Resources.Die6;
                        break;
                }
            }
            try
            {
                switch (die2)
                {
                    case 1:
                        pictureBoxDie2.ImageLocation =
                        "C:\\Users\\Wayne\\Desktop\\ITCS 1250\\Source_Code\\Gaddis Source_Code\\Student Sample Programs\\Chap05\\Die1.bmp";
                        break;
                    case 2:
                        pictureBoxDie2.ImageLocation =
                        "C:\\Users\\Wayne\\Desktop\\ITCS 1250\\Source_Code\\Gaddis Source_Code\\Student Sample Programs\\Chap05\\Die2.bmp";
                        break;
                    case 3:
                        pictureBoxDie2.ImageLocation =
                        "C:\\Users\\Wayne\\Desktop\\ITCS 1250\\Source_Code\\Gaddis Source_Code\\Student Sample Programs\\Chap05\\Die3.bmp";
                        break;
                    case 4:
                        pictureBoxDie2.ImageLocation =
                        "C:\\Users\\Wayne\\Desktop\\ITCS 1250\\Source_Code\\Gaddis Source_Code\\Student Sample Programs\\Chap05\\Die4.bmp";
                        break;
                    case 5:
                        pictureBoxDie2.ImageLocation =
                        "C:\\Users\\Wayne\\Desktop\\ITCS 1250\\Source_Code\\Gaddis Source_Code\\Student Sample Programs\\Chap05\\Die5.bmp";
                        break;
                    case 6:
                        pictureBoxDie2.ImageLocation =
                        "C:\\Users\\Wayne\\Desktop\\ITCS 1250\\Source_Code\\Gaddis Source_Code\\Student Sample Programs\\Chap05\\Die6.bmp";
                        break;
                }
            }
            catch(Exception ex)
            {
                switch (die2)
                {
                    case 1:
                        pictureBoxDie2.Image = Resources.Die1;
                        break;
                    case 2:
                        pictureBoxDie2.Image = Resources.Die2;
                        break;
                    case 3:
                        pictureBoxDie2.Image = Resources.Die3;
                        break;
                    case 4:
                        pictureBoxDie2.Image = Resources.Die4;
                        break;
                    case 5:
                        pictureBoxDie2.Image = Resources.Die5;
                        break;
                    case 6:
                        pictureBoxDie2.Image = Resources.Die6;
                        break;
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
