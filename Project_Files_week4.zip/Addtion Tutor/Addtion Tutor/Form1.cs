﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Addtion_Tutor
{
    public partial class Form1 : Form
    {
        private Random rand = new Random();

        private int number1;
        private int number2;
        private int result;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
            //Use load event to intitialize first random numbers to add
            number1 = rand.Next(100, 500);
            number2 = rand.Next(100, 500);

            labelTitleX.Text = number1.ToString();
            labelTitleY.Text = number2.ToString();
            
        }

        private void buttonCheckMath_Click(object sender, EventArgs e)
        {
            int answer;
            //Read answer
            if (int.TryParse(textBoxAnswer.Text, out answer) && answer > 0)
            {
                
                //Add random numbers together
                result = number1 + number2;

                //Determine if answer equals result
                if (answer != result)
                {
                    
                    MessageBox.Show("Sorry, the answer is wrong!");
                    
                    textBoxAnswer.Focus();
                }
                //If answer == result --> Display "Correct", randomize numbers again
                else
                {
                    MessageBox.Show("Congratulations! Your answer is correct!");
                    number1 = rand.Next(100, 500);
                    number2 = rand.Next(100, 500);
                    labelTitleX.Text = number1.ToString();
                    labelTitleY.Text = number2.ToString();
                }

                textBoxAnswer.Focus();
            }
            else
            {
                MessageBox.Show("Please enter a valid number.");
                textBoxAnswer.Focus();
            }
            
            
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonRandomize_Click(object sender, EventArgs e)
        {
            number1 = rand.Next(100, 500);
            number2 = rand.Next(100, 500);
            labelTitleX.Text = number1.ToString();
            labelTitleY.Text = number2.ToString();
            textBoxAnswer.Focus();
        }
    }
}
