﻿namespace Addtion_Tutor
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonCheckMath = new System.Windows.Forms.Button();
            this.buttonExit = new System.Windows.Forms.Button();
            this.labelTitleX = new System.Windows.Forms.Label();
            this.textBoxAnswer = new System.Windows.Forms.TextBox();
            this.labelTitleY = new System.Windows.Forms.Label();
            this.labelTitlePlus = new System.Windows.Forms.Label();
            this.labelTitleEquals = new System.Windows.Forms.Label();
            this.buttonRandomize = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonCheckMath
            // 
            this.buttonCheckMath.Location = new System.Drawing.Point(237, 62);
            this.buttonCheckMath.Name = "buttonCheckMath";
            this.buttonCheckMath.Size = new System.Drawing.Size(102, 61);
            this.buttonCheckMath.TabIndex = 1;
            this.buttonCheckMath.Text = "Check Math";
            this.buttonCheckMath.UseVisualStyleBackColor = true;
            this.buttonCheckMath.Click += new System.EventHandler(this.buttonCheckMath_Click);
            // 
            // buttonExit
            // 
            this.buttonExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonExit.Location = new System.Drawing.Point(5, 62);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(80, 61);
            this.buttonExit.TabIndex = 3;
            this.buttonExit.Text = "&Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // labelTitleX
            // 
            this.labelTitleX.AutoSize = true;
            this.labelTitleX.Location = new System.Drawing.Point(41, 18);
            this.labelTitleX.Name = "labelTitleX";
            this.labelTitleX.Size = new System.Drawing.Size(20, 20);
            this.labelTitleX.TabIndex = 4;
            this.labelTitleX.Text = "X";
            // 
            // textBoxAnswer
            // 
            this.textBoxAnswer.Location = new System.Drawing.Point(239, 15);
            this.textBoxAnswer.Name = "textBoxAnswer";
            this.textBoxAnswer.Size = new System.Drawing.Size(100, 26);
            this.textBoxAnswer.TabIndex = 0;
            // 
            // labelTitleY
            // 
            this.labelTitleY.AutoSize = true;
            this.labelTitleY.Location = new System.Drawing.Point(137, 18);
            this.labelTitleY.Name = "labelTitleY";
            this.labelTitleY.Size = new System.Drawing.Size(20, 20);
            this.labelTitleY.TabIndex = 6;
            this.labelTitleY.Text = "Y";
            // 
            // labelTitlePlus
            // 
            this.labelTitlePlus.AutoSize = true;
            this.labelTitlePlus.Location = new System.Drawing.Point(101, 18);
            this.labelTitlePlus.Name = "labelTitlePlus";
            this.labelTitlePlus.Size = new System.Drawing.Size(18, 20);
            this.labelTitlePlus.TabIndex = 5;
            this.labelTitlePlus.Text = "+";
            // 
            // labelTitleEquals
            // 
            this.labelTitleEquals.AutoSize = true;
            this.labelTitleEquals.Location = new System.Drawing.Point(189, 18);
            this.labelTitleEquals.Name = "labelTitleEquals";
            this.labelTitleEquals.Size = new System.Drawing.Size(18, 20);
            this.labelTitleEquals.TabIndex = 7;
            this.labelTitleEquals.Text = "=";
            // 
            // buttonRandomize
            // 
            this.buttonRandomize.Location = new System.Drawing.Point(109, 62);
            this.buttonRandomize.Name = "buttonRandomize";
            this.buttonRandomize.Size = new System.Drawing.Size(102, 61);
            this.buttonRandomize.TabIndex = 2;
            this.buttonRandomize.Text = "Randomize";
            this.buttonRandomize.UseVisualStyleBackColor = true;
            this.buttonRandomize.Click += new System.EventHandler(this.buttonRandomize_Click);
            // 
            // Form1
            // 
            this.AcceptButton = this.buttonCheckMath;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.buttonExit;
            this.ClientSize = new System.Drawing.Size(351, 143);
            this.Controls.Add(this.buttonRandomize);
            this.Controls.Add(this.labelTitleEquals);
            this.Controls.Add(this.labelTitlePlus);
            this.Controls.Add(this.labelTitleY);
            this.Controls.Add(this.textBoxAnswer);
            this.Controls.Add(this.labelTitleX);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.buttonCheckMath);
            this.Name = "Form1";
            this.Text = "Addition Tutor";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonCheckMath;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Label labelTitleX;
        private System.Windows.Forms.TextBox textBoxAnswer;
        private System.Windows.Forms.Label labelTitleY;
        private System.Windows.Forms.Label labelTitlePlus;
        private System.Windows.Forms.Label labelTitleEquals;
        private System.Windows.Forms.Button buttonRandomize;
    }
}

